// android/.../WidgetUpdateWorker.kt — Phase 13
// ══════════════════════════════════════════════════
// WorkManager Worker — يحدّث بيانات الـ widget في الـ background
// يشتغل كل 30 دقيقة حتى لو التطبيق مقفول
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import androidx.work.*
import java.util.concurrent.TimeUnit

class WidgetUpdateWorker(
    private val ctx: Context,
    params: WorkerParameters,
) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            // 1. Fetch fresh data from agent
            AiWidgetProvider.fetchAndStore(ctx)

            // 2. Push update to all widget instances
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(
                ComponentName(ctx, AiWidgetProvider::class.java)
            )
            for (id in ids) {
                AiWidgetProvider.updateWidget(ctx, mgr, id)
            }

            Result.success()
        } catch (e: Exception) {
            // Retry once after 5 minutes on failure
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "ai_widget_update"

        // ── Schedule periodic work ────────────────
        fun schedule(ctx: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED) // يشتغل حتى offline
                .build()

            val request = PeriodicWorkRequestBuilder<WidgetUpdateWorker>(
                30, TimeUnit.MINUTES,           // كل 30 دقيقة
                10, TimeUnit.MINUTES,           // flex window
            )
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.LINEAR,
                    5, TimeUnit.MINUTES,
                )
                .build()

            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request,
            )
        }

        // ── One-time immediate update ─────────────
        fun runNow(ctx: Context) {
            val request = OneTimeWorkRequestBuilder<WidgetUpdateWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(ctx).enqueue(request)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME)
        }
    }
}
