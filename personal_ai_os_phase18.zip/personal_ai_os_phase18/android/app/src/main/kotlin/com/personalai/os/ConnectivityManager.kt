// android/app/src/main/kotlin/com/personalai/os/ConnectivityManager.kt — Phase 11
// ══════════════════════════════════════════════════
// يراقب حالة الشبكة ويبعت للـ Flutter
// يستخدم NetworkCallback (API 21+) لمراقبة فورية
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

object NetworkMonitor {

    private val TAG = "NetworkMonitor"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var _isOnline: Boolean = false
    private var _callback: ConnectivityManager.NetworkCallback? = null
    private var _onlineCallback:  (() -> Unit)? = null
    private var _offlineCallback: (() -> Unit)? = null

    val isOnline: Boolean get() = _isOnline

    // ── Start monitoring ──────────────────────────
    fun start(context: Context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE)
                 as ConnectivityManager

        // Initial state
        _isOnline = checkCurrentConnectivity(cm)
        Log.d(TAG, "Initial state: ${if (_isOnline) "ONLINE" else "OFFLINE"}")

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()

        _callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                Log.d(TAG, "Network available")
                val wasOffline = !_isOnline
                _isOnline = true
                if (wasOffline) {
                    Log.d(TAG, "🌐 Back online!")
                    _onlineCallback?.invoke()
                }
            }

            override fun onLost(network: Network) {
                Log.d(TAG, "Network lost")
                val wasOnline = _isOnline
                _isOnline = false
                if (wasOnline) {
                    Log.d(TAG, "📴 Gone offline")
                    _offlineCallback?.invoke()
                }
            }

            override fun onCapabilitiesChanged(
                network: Network,
                caps: NetworkCapabilities,
            ) {
                val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                if (!validated && _isOnline) {
                    _isOnline = false
                    _offlineCallback?.invoke()
                } else if (validated && !_isOnline) {
                    _isOnline = true
                    _onlineCallback?.invoke()
                }
            }
        }

        cm.registerNetworkCallback(request, _callback!!)
        Log.d(TAG, "NetworkCallback registered")
    }

    fun stop(context: Context) {
        _callback?.let { cb ->
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE)
                     as ConnectivityManager
            try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {}
        }
        scope.cancel()
    }

    fun onOnline(fn: () -> Unit)  { _onlineCallback  = fn }
    fun onOffline(fn: () -> Unit) { _offlineCallback = fn }

    // ── Check current state ───────────────────────
    private fun checkCurrentConnectivity(cm: ConnectivityManager): Boolean {
        val network = cm.activeNetwork ?: return false
        val caps    = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ── Ping test (verifies real internet, not just local) ──
    fun pingTest(callback: (Boolean) -> Unit) {
        scope.launch {
            val result = try {
                val conn = URL("https://www.google.com").openConnection()
                           as HttpURLConnection
                conn.connectTimeout = 3000
                conn.readTimeout    = 3000
                conn.requestMethod  = "HEAD"
                conn.responseCode   in 200..399
            } catch (_: Exception) {
                false
            }
            withContext(Dispatchers.Main) { callback(result) }
        }
    }
}
