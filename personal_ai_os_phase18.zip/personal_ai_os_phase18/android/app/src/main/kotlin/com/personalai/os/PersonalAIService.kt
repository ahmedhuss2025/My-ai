// PersonalAIService.kt — Phase 6
// ══════════════════════════════════════════════════
// Foreground Service:
//   1. يحمّل Gemma في الخلفية
//   2. يشغّل HTTP server :8080
//   3. يراقب البطارية
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class PersonalAIService : Service() {

    private val TAG = "PersonalAIService"
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private lateinit var gemma: GemmaEngine
    private var gemmaLoaded = false

    // ── onCreate ──────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Service started")

        gemma = GemmaEngine(this)

        // بدأ الـ foreground notification
        startForeground(NOTIF_ID, buildNotification("🤖 جاري التحضير..."))

        // حمّل Gemma في الخلفية
        scope.launch { loadGemma() }

        // Monitor battery
        scope.launch { monitorLoop() }

        // Phase 9 — Habits tracking (every 60 min)
        scope.launch { habitsLoop() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        gemma.unload()
        HabitsTracker.cancel()
        Log.i(TAG, "Service stopped")
        super.onDestroy()
    }

    // ══════════════════════════════════════════════
    // GEMMA LOADING
    // ══════════════════════════════════════════════
    private suspend fun loadGemma() {
        updateNotification("⏳ Gemma بتتحمّل...")
        Log.i(TAG, "Loading Gemma from ${GemmaEngine.DEFAULT_MODEL_PATH}")

        val ok = gemma.load(GemmaEngine.DEFAULT_MODEL_PATH)
        gemmaLoaded = ok

        if (ok) {
            Log.i(TAG, "✅ Gemma ready — starting HTTP server")
            gemma.startServer()
            updateNotification("🧠 Gemma شغّال — يستمع على :${gemma.serverPort}")
        } else {
            Log.w(TAG, "⚠️ Gemma model not found — using smart fallback")
            // ابدأ server بالـ fallback بردو
            gemma.startServer()
            updateNotification("🤖 AI OS نشط (offline mode)")
        }
    }

    // ── Load on demand (من MainActivity) ─────────
    suspend fun reloadGemma(modelPath: String = GemmaEngine.DEFAULT_MODEL_PATH): Boolean {
        gemma.stopServer()
        val ok = gemma.load(modelPath)
        gemmaLoaded = ok
        if (ok) {
            gemma.startServer()
            updateNotification("🧠 Gemma شغّال ✅")
        }
        return ok
    }

    // ══════════════════════════════════════════════
    // MONITORING
    // ══════════════════════════════════════════════
    private suspend fun monitorLoop() {
        while (scope.isActive) {
            try {
                val battery = BatteryHelper.getLevel(this)
                if (battery in 15..20) {
                    sendAlert(
                        "🔋 البطارية $battery%",
                        "وصّل الشاحن — الـ Gemma محتاج طاقة"
                    )
                }
                delay(60_000L)
            } catch (e: Exception) {
                Log.e(TAG, "Monitor: ${e.message}")
                delay(30_000L)
            }
        }
    }

    // Phase 9 — Habits tracking loop
    private suspend fun habitsLoop() {
        // Wait 2 min after start before first check
        delay(120_000L)
        while (scope.isActive) {
            try {
                if (HabitsTracker.hasPermission(this)) {
                    HabitsTracker.trackAndSend(this)
                    Log.d(TAG, "📊 Habits tracked")
                }
                delay(60L * 60L * 1000L)   // every hour
            } catch (e: Exception) {
                Log.d(TAG, "Habits loop: ${e.message}")
                delay(5L * 60L * 1000L)    // retry in 5 min
            }
        }
    }

    // ══════════════════════════════════════════════
    // NOTIFICATIONS
    // ══════════════════════════════════════════════
    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("Personal AI OS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    packageManager.getLaunchIntentForPackage(packageName),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun sendAlert(title: String, body: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val n = NotificationCompat.Builder(this, CHANNEL_ALERTS)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), n)
    }

    companion object {
        const val NOTIF_ID       = 1
        const val CHANNEL_SERVICE = "ai_agent"
        const val CHANNEL_ALERTS  = "ai_alerts"
    }
}
