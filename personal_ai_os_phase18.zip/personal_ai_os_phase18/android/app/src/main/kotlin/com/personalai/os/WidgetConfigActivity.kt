// android/.../WidgetConfigActivity.kt — Phase 13
// ══════════════════════════════════════════════════
// Widget Configuration Activity
// بتظهر لما المستخدم يضيف الـ widget للأول مرة
// بتخليه يختار: الـ style، أي زر يظهر، اللغة
// ══════════════════════════════════════════════════
package com.personalai.os

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class WidgetConfigActivity : AppCompatActivity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set result CANCELLED by default (if user presses back)
        setResult(RESULT_CANCELED)

        // Get widget ID from intent
        widgetId = intent.extras
            ?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                     AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        // For now: auto-configure with defaults and finish
        // In production: show a proper config UI
        applyDefaultConfig()
        finishWithResult()
    }

    private fun applyDefaultConfig() {
        val prefs = getSharedPreferences("ai_widget_prefs", MODE_PRIVATE)
        prefs.edit()
            .putString("suggestion", "💡 مرحباً! اضغط للتحدث مع مساعدك الذكي")
            .putBoolean("online", false)
            .putInt("pending_count", 0)
            .apply()

        // Trigger initial data fetch
        WidgetUpdateWorker.runNow(this)
    }

    private fun finishWithResult() {
        val mgr = AppWidgetManager.getInstance(this)
        AiWidgetProvider.updateWidget(this, mgr, widgetId)

        val resultIntent = Intent().apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        }
        setResult(RESULT_OK, resultIntent)
        finish()
    }
}
