// BackupScheduler.kt — Phase 14 (upgraded from stub)
package com.personalai.os

import android.content.Context

object BackupScheduler {
    fun schedule(context: Context, password: String = "") {
        BackupWorker.schedule(context, password)
        android.util.Log.i("BackupScheduler", "✅ Weekly auto-backup scheduled")
    }

    fun runNow(context: Context) {
        BackupWorker.runNow(context, label = "manual")
    }

    fun cancel(context: Context) {
        BackupWorker.cancel(context)
    }
}
