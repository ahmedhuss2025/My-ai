// SmartOverlay.kt — Phase 7
// ══════════════════════════════════════════════════
// Overlay ذكي يظهر فوق أي app:
//   - يعرض suggestion من الـ agent
//   - قابل للإخفاء بضغطة
//   - يختفي تلقائياً بعد 8 ثواني
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.TranslateAnimation
import android.widget.*

object SmartOverlay {

    private var wm: WindowManager? = null
    private var root: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideRunnable: Runnable? = null

    private const val AUTO_HIDE_MS = 8000L

    // ── Show suggestion ───────────────────────────
    fun showSuggestion(context: Context, suggestion: String, appName: String) {
        // أخفي القديم الأول
        hide()

        wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // ── Build card view ───────────────────────
        val card = buildCard(context, suggestion, appName)
        root = card

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = 120
        }

        // Slide-in animation
        val anim = AnimationSet(true).apply {
            addAnimation(TranslateAnimation(0f, 0f, 200f, 0f).apply { duration = 250 })
            addAnimation(AlphaAnimation(0f, 1f).apply { duration = 250 })
        }
        card.startAnimation(anim)

        wm?.addView(card, params)

        // Auto-hide after 8s
        scheduleHide()
    }

    // ── Simple text update (from OverlayManager) ──
    fun showText(context: Context, text: String) {
        showSuggestion(context, text, "Personal AI")
    }

    fun hide() {
        hideRunnable?.let { handler.removeCallbacks(it) }
        root?.let { v ->
            val fadeOut = AlphaAnimation(1f, 0f).apply { duration = 200 }
            v.startAnimation(fadeOut)
            handler.postDelayed({
                try { wm?.removeView(v) } catch (_: Exception) {}
                root = null
            }, 210)
        }
    }

    private fun scheduleHide() {
        hideRunnable?.let { handler.removeCallbacks(it) }
        hideRunnable = Runnable { hide() }
        handler.postDelayed(hideRunnable!!, AUTO_HIDE_MS)
    }

    // ── Build the card UI ─────────────────────────
    private fun buildCard(context: Context, suggestion: String, appName: String): View {
        val dp = context.resources.displayMetrics.density

        // Outer container
        val outer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                (16 * dp).toInt(), (12 * dp).toInt(),
                (16 * dp).toInt(), (12 * dp).toInt()
            )
        }

        // Card background
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(240, 8, 13, 26))
            setPadding(
                (16 * dp).toInt(), (14 * dp).toInt(),
                (12 * dp).toInt(), (14 * dp).toInt()
            )
        }

        // Rounded corners (API 16+)
        val bg = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.argb(242, 8, 13, 26))
            cornerRadius = 16 * dp
            setStroke((1 * dp).toInt(), Color.argb(60, 0, 200, 255))
        }
        card.background = bg

        // 🤖 icon
        val icon = TextView(context).apply {
            text = "🤖"
            textSize = 20f
            setPadding(0, 0, (10 * dp).toInt(), 0)
        }

        // Text block
        val textBlock = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val appLabel = TextView(context).apply {
            text = appName
            textSize = 10f
            setTextColor(Color.argb(150, 0, 200, 255))
            setTypeface(typeface, Typeface.BOLD)
        }

        val suggText = TextView(context).apply {
            text = suggestion
            textSize = 13f
            setTextColor(Color.WHITE)
        }

        textBlock.addView(appLabel)
        textBlock.addView(suggText)

        // ✕ close button
        val closeBtn = TextView(context).apply {
            text = "✕"
            textSize = 14f
            setTextColor(Color.argb(150, 255, 255, 255))
            setPadding((10 * dp).toInt(), 0, 0, 0)
            setOnClickListener { hide() }
        }

        card.addView(icon)
        card.addView(textBlock)
        card.addView(closeBtn)
        outer.addView(card)

        return outer
    }
}
