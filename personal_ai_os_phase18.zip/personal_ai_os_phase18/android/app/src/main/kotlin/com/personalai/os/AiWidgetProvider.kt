// android/.../AiWidgetProvider.kt — Phase 13
// ══════════════════════════════════════════════════
// Android Home Screen Widget
//   • يعرض اقتراح proactive من الـ AI
//   • 3 أزرار: Chat | Voice | Meeting
//   • مؤشر الـ pending queue (offline)
//   • يُحدَّث كل 30 دقيقة + عند فتح التطبيق
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

// ── Intent actions ────────────────────────────────
private const val ACTION_OPEN_CHAT    = "com.personalai.os.WIDGET_CHAT"
private const val ACTION_OPEN_VOICE   = "com.personalai.os.WIDGET_VOICE"
private const val ACTION_OPEN_MEETING = "com.personalai.os.WIDGET_MEETING"
private const val ACTION_REFRESH      = "com.personalai.os.WIDGET_REFRESH"

private const val PREFS_NAME = "ai_widget_prefs"
private const val PREF_SUGGESTION  = "suggestion"
private const val PREF_ONLINE      = "online"
private const val PREF_PENDING     = "pending_count"
private const val PREF_LAST_UPDATE = "last_update"

class AiWidgetProvider : AppWidgetProvider() {

    // ── onUpdate: called on schedule + boot ──────
    override fun onUpdate(
        ctx: Context,
        mgr: AppWidgetManager,
        widgetIds: IntArray,
    ) {
        for (id in widgetIds) {
            updateWidget(ctx, mgr, id)
        }
        // Fetch fresh data in background
        thread(isDaemon = true) {
            fetchAndStore(ctx)
            for (id in widgetIds) {
                updateWidget(ctx, mgr, id)
            }
        }
    }

    // ── onReceive: handle button taps ────────────
    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_OPEN_CHAT    -> openApp(ctx, "chat")
            ACTION_OPEN_VOICE   -> openApp(ctx, "voice")
            ACTION_OPEN_MEETING -> openApp(ctx, "meeting")
            ACTION_REFRESH -> {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(ctx, AiWidgetProvider::class.java)
                )
                onUpdate(ctx, mgr, ids)
            }
        }
    }

    // ── Build RemoteViews ─────────────────────────
    companion object {

        fun updateWidget(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
            val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val views = RemoteViews(ctx.packageName, R.layout.widget_layout)

            // Time
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            views.setTextViewText(R.id.widget_time, time)

            // Online status
            val online = prefs.getBoolean(PREF_ONLINE, true)
            views.setTextViewText(R.id.widget_status, if (online) "●" else "○")
            views.setTextColor(
                R.id.widget_status,
                if (online) 0xFF00FF9D.toInt() else 0xFFEF5350.toInt()
            )

            // Suggestion text
            val suggestion = prefs.getString(PREF_SUGGESTION, "💡 اضغط للتحدث مع مساعدك...")
            views.setTextViewText(R.id.widget_suggestion, suggestion)

            // Pending queue badge
            val pending = prefs.getInt(PREF_PENDING, 0)
            if (pending > 0) {
                views.setViewVisibility(R.id.widget_queue, android.view.View.VISIBLE)
                views.setTextViewText(R.id.widget_queue, "🔄 $pending طلب في الانتظار")
            } else {
                views.setViewVisibility(R.id.widget_queue, android.view.View.GONE)
            }

            // ── Click intents ─────────────────────
            views.setOnClickPendingIntent(
                R.id.btn_chat,
                buildPendingIntent(ctx, ACTION_OPEN_CHAT, 1)
            )
            views.setOnClickPendingIntent(
                R.id.btn_voice,
                buildPendingIntent(ctx, ACTION_OPEN_VOICE, 2)
            )
            views.setOnClickPendingIntent(
                R.id.btn_meeting,
                buildPendingIntent(ctx, ACTION_OPEN_MEETING, 3)
            )
            // Tap on suggestion → open chat
            views.setOnClickPendingIntent(
                R.id.widget_suggestion,
                buildPendingIntent(ctx, ACTION_OPEN_CHAT, 4)
            )
            // Long tap root → refresh
            views.setOnClickPendingIntent(
                R.id.widget_root,
                buildPendingIntent(ctx, ACTION_REFRESH, 5)
            )

            mgr.updateAppWidget(widgetId, views)
        }

        // ── Fetch data from Python agent ──────────
        fun fetchAndStore(ctx: Context) {
            val prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            try {
                // 1. Proactive suggestion
                val suggestionUrl = URL("http://localhost:7070/proactive")
                val conn = suggestionUrl.openConnection() as HttpURLConnection
                conn.connectTimeout = 3000
                conn.readTimeout    = 3000
                conn.requestMethod  = "GET"

                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().readText()
                    val json = JSONObject(body)
                    val suggestions = json.optJSONArray("suggestions")
                    if (suggestions != null && suggestions.length() > 0) {
                        val first = suggestions.getJSONObject(0)
                        val text = "${first.optString("title")} — ${first.optString("body")}"
                        prefs.edit().putString(PREF_SUGGESTION, text).apply()
                    }
                }
                conn.disconnect()

                // 2. Sync status (online + pending)
                val syncUrl = URL("http://localhost:7070/sync/status")
                val conn2 = syncUrl.openConnection() as HttpURLConnection
                conn2.connectTimeout = 2000
                conn2.readTimeout    = 2000
                conn2.requestMethod  = "GET"

                if (conn2.responseCode == 200) {
                    val body = conn2.inputStream.bufferedReader().readText()
                    val json = JSONObject(body)
                    prefs.edit()
                        .putBoolean(PREF_ONLINE,  json.optBoolean("online", true))
                        .putInt(PREF_PENDING,     json.optInt("pending_count", 0))
                        .putString(PREF_LAST_UPDATE,
                            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
                        .apply()
                }
                conn2.disconnect()

            } catch (_: Exception) {
                // Agent not running — mark as offline
                prefs.edit().putBoolean(PREF_ONLINE, false).apply()
            }
        }

        // ── Deep link: open app at specific screen ─
        private fun openApp(ctx: Context, screen: String) {
            val intent = ctx.packageManager
                .getLaunchIntentForPackage(ctx.packageName)
                ?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("WIDGET_SCREEN", screen)
                } ?: return
            ctx.startActivity(intent)
        }

        private fun buildPendingIntent(ctx: Context, action: String, reqCode: Int): PendingIntent {
            val intent = Intent(ctx, AiWidgetProvider::class.java).apply {
                this.action = action
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            else PendingIntent.FLAG_UPDATE_CURRENT
            return PendingIntent.getBroadcast(ctx, reqCode, intent, flags)
        }
    }
}
