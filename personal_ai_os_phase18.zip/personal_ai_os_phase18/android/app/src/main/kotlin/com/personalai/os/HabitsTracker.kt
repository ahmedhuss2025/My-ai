// android/app/src/main/kotlin/com/personalai/os/HabitsTracker.kt — Phase 9
// ══════════════════════════════════════════════════
// يراقب استخدام الـ apps ويبعت للـ agent
// بيشغّل كل ساعة عبر WorkManager (أو timer)
//
// يجمع:
//   - أكتر apps استُخدمت
//   - الساعة الحالية (للـ activity pattern)
//   - لا يبعت محتوى الشاشة — privacy-first
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

object HabitsTracker {

    private val TAG = "HabitsTracker"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── تحقق من الـ permission ────────────────────
    fun hasPermission(context: Context): Boolean {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            now - 1000 * 60 * 60,
            now
        )
        return stats != null && stats.isNotEmpty()
    }

    // ── Collect + send ────────────────────────────
    fun trackAndSend(context: Context) {
        scope.launch {
            try {
                val apps = collectTopApps(context)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                sendToAgent(apps, hour)
            } catch (e: Exception) {
                Log.d(TAG, "Track error: ${e.message}")
            }
        }
    }

    // ── Collect top apps (last hour) ──────────────
    private fun collectTopApps(context: Context): List<AppUsage> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val oneHourAgo = now - 1000L * 60 * 60

        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            oneHourAgo,
            now
        ) ?: return emptyList()

        // Filter out system + ourselves
        val filtered = stats.filter { stat ->
            val pkg = stat.packageName
            stat.totalTimeInForeground > 0 &&
            !isSystemPackage(pkg) &&
            pkg != context.packageName
        }

        // Sort by usage time, take top 10
        return filtered
            .sortedByDescending { it.totalTimeInForeground }
            .take(10)
            .map { stat ->
                AppUsage(
                    packageName = stat.packageName,
                    appName     = getAppLabel(context, stat.packageName),
                    minutesUsed = (stat.totalTimeInForeground / 1000 / 60).toInt()
                )
            }
    }

    private fun getAppLabel(context: Context, packageName: String): String {
        return try {
            val pm   = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            packageName.split(".").last()
        }
    }

    private fun isSystemPackage(pkg: String): Boolean =
        pkg.startsWith("com.android.") ||
        pkg.startsWith("android.") ||
        pkg.startsWith("com.google.android.") ||
        pkg == "com.google.android.inputmethod.latin"

    // ── Send to Python agent ──────────────────────
    private suspend fun sendToAgent(apps: List<AppUsage>, hour: Int) {
        if (apps.isEmpty()) return

        val appsArr = JSONArray()
        apps.forEach { app ->
            appsArr.put(JSONObject().apply {
                put("package", app.packageName)
                put("name",    app.appName)
                put("minutes", app.minutesUsed)
            })
        }

        val payload = JSONObject().apply {
            put("apps", appsArr)
            put("hour", hour)
        }.toString()

        try {
            val url  = URL("http://localhost:7070/app_usage")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod  = "POST"
            conn.doOutput       = true
            conn.connectTimeout = 3000
            conn.readTimeout    = 5000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(payload.toByteArray()) }

            val code = conn.responseCode
            Log.d(TAG, "Sent usage data → $code (${apps.size} apps, hour=$hour)")
            conn.disconnect()
        } catch (e: Exception) {
            Log.d(TAG, "Agent unreachable: ${e.message}")
        }
    }

    fun cancel() = scope.cancel()
}

// ── Data class ────────────────────────────────────
data class AppUsage(
    val packageName: String,
    val appName:     String,
    val minutesUsed: Int,
)
