// android/.../NotificationReceiver.kt — Phase 16
// ══════════════════════════════════════════════════
// Handles notification action buttons:
//   ✅ Done   — marks reminder complete via /reminder/done
//   💤 Snooze — snooze via /reminder/snooze
//   ❌ Dismiss — dismisses without action
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class NotificationReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DONE    = "com.personalai.os.REMINDER_DONE"
        const val ACTION_SNOOZE  = "com.personalai.os.REMINDER_SNOOZE"
        const val ACTION_DISMISS = "com.personalai.os.REMINDER_DISMISS"
        const val EXTRA_RID      = "reminder_id"
        const val EXTRA_NOTIF_ID = "notif_id"
        const val EXTRA_MINUTES  = "snooze_minutes"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val rid     = intent.getStringExtra(EXTRA_RID)     ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, 0)

        // Cancel the notification
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager
        nm.cancel(notifId)

        when (intent.action) {
            ACTION_DONE    -> callAgent(ctx, "/reminder/done",
                                JSONObject().put("id", rid))
            ACTION_SNOOZE  -> {
                val minutes = intent.getIntExtra(EXTRA_MINUTES, 10)
                callAgent(ctx, "/reminder/snooze",
                    JSONObject().put("id", rid).put("minutes", minutes))
            }
            ACTION_DISMISS -> {
                // just dismiss — no API call needed
                android.util.Log.i("NotifReceiver", "Dismissed: $rid")
            }
        }
    }

    private fun callAgent(ctx: Context, endpoint: String, body: JSONObject) {
        thread(isDaemon = true) {
            try {
                val url  = URL("http://localhost:7070$endpoint")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod  = "POST"
                conn.doOutput       = true
                conn.connectTimeout = 3000
                conn.readTimeout    = 5000
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                OutputStreamWriter(conn.outputStream, "UTF-8").use {
                    it.write(body.toString())
                }
                conn.responseCode // triggers the call
                conn.disconnect()
                android.util.Log.i("NotifReceiver",
                    "✅ $endpoint called for ${body.optString("id")}")
            } catch (e: Exception) {
                android.util.Log.e("NotifReceiver", "API call failed: ${e.message}")
            }
        }
    }
}
