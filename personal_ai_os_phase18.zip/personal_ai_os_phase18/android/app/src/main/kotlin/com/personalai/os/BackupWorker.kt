// android/.../BackupWorker.kt — Phase 14
// ══════════════════════════════════════════════════
// WorkManager Worker — تشغيل الـ backup الأسبوعي
// يستدعي POST /backup/create على الـ Python agent
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import androidx.work.*
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class BackupWorker(
    ctx: Context,
    params: WorkerParameters,
) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val label    = inputData.getString("label") ?: "auto"
            val password = inputData.getString("password") ?: ""

            val url  = URL("http://localhost:7070/backup/create")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod  = "POST"
            conn.doOutput       = true
            conn.connectTimeout = 10_000
            conn.readTimeout    = 30_000
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

            val body = JSONObject().apply {
                put("label",          label)
                put("password",       password)
                put("include_images", false)
            }.toString()

            OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(body) }

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(resp)
                if (json.optBoolean("ok", false)) {
                    android.util.Log.i("BackupWorker",
                        "✅ Backup created: ${json.optString("filename")}")
                    conn.disconnect()
                    return Result.success()
                }
            }
            conn.disconnect()
            Result.retry()
        } catch (e: Exception) {
            android.util.Log.e("BackupWorker", "Backup failed: ${e.message}")
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "ai_weekly_backup"

        fun schedule(ctx: Context, password: String = "") {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .setRequiresBatteryNotLow(true)
                .build()

            val inputData = workDataOf(
                "label"    to "weekly_auto",
                "password" to password,
            )

            val request = PeriodicWorkRequestBuilder<BackupWorker>(
                7, TimeUnit.DAYS,    // أسبوعياً
                1, TimeUnit.HOURS,   // flex window
            )
                .setConstraints(constraints)
                .setInputData(inputData)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request,
            )

            android.util.Log.i("BackupWorker", "Weekly backup scheduled")
        }

        fun runNow(ctx: Context, label: String = "manual") {
            val request = OneTimeWorkRequestBuilder<BackupWorker>()
                .setInputData(workDataOf("label" to label))
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(ctx).enqueue(request)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME)
        }
    }
}
