// GemmaEngine.kt — Phase 6
// ══════════════════════════════════════════════════
// Gemma 2B-IT on-device via MediaPipe
// + HTTP server على :8080 للـ Python agent
//
// الموديل: /sdcard/models/gemma-2b-it-gpu-int4.bin
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.ServerSocket
import java.net.Socket

class GemmaEngine(private val context: Context) {

    private val TAG = "GemmaEngine"

    private var llm: LlmInference? = null
    private var _loaded = false
    val isLoaded get() = _loaded

    private var serverJob: Job? = null
    private val serverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    val serverPort = 8080

    companion object {
        const val DEFAULT_MODEL_PATH = "/sdcard/models/gemma-2b-it-gpu-int4.bin"
        const val MAX_TOKENS = 512
        const val TEMPERATURE = 0.3f
    }

    // ══════════════════════════════════════════════
    // LOAD
    // ══════════════════════════════════════════════
    suspend fun load(modelPath: String = DEFAULT_MODEL_PATH): Boolean =
        withContext(Dispatchers.IO) {
            val file = File(modelPath)
            if (!file.exists()) {
                Log.w(TAG, "Model not found: $modelPath")
                return@withContext false
            }
            try {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelPath)
                    .setMaxTokens(MAX_TOKENS)
                    .setTopK(40)
                    .setTemperature(TEMPERATURE)
                    .setRandomSeed(42)
                    .build()
                llm = LlmInference.createFromOptions(context, options)
                _loaded = true
                Log.i(TAG, "✅ Gemma loaded: $modelPath")
                true
            } catch (e: Exception) {
                Log.e(TAG, "Load failed: ${e.message}")
                _loaded = false
                false
            }
        }

    // ══════════════════════════════════════════════
    // GENERATE
    // ══════════════════════════════════════════════
    suspend fun generate(
        prompt: String,
        maxTokens: Int = MAX_TOKENS,
        temperature: Float = TEMPERATURE
    ): String = withContext(Dispatchers.IO) {
        if (!_loaded || llm == null) return@withContext smartFallback(prompt)
        try {
            llm!!.generateResponse(buildPrompt(prompt)).trim()
        } catch (e: Exception) {
            Log.e(TAG, "Generate error: ${e.message}")
            smartFallback(prompt)
        }
    }

    private fun buildPrompt(userText: String) = """<start_of_turn>system
أنت Personal AI OS — مساعد شخصي يعمل محلياً.
ردودك بالعربي. رد بـ JSON فقط:
  tool   → {"action":"tool","tool":"...","args":{...}}
  answer → {"action":"answer","text":"..."}
<end_of_turn>
<start_of_turn>user
$userText<end_of_turn>
<start_of_turn>model
"""

    // ══════════════════════════════════════════════
    // HTTP SERVER :8080 — Python agent يتكلمه
    // ══════════════════════════════════════════════
    fun startServer() {
        if (serverJob?.isActive == true) return
        serverJob = serverScope.launch {
            try {
                ServerSocket(serverPort).use { server ->
                    Log.i(TAG, "🌐 Gemma HTTP server :$serverPort")
                    while (isActive) {
                        try {
                            val client = server.accept()
                            launch { handleClient(client) }
                        } catch (e: Exception) {
                            if (isActive) Log.e(TAG, "Accept: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server: ${e.message}")
            }
        }
        Log.i(TAG, "HTTP server started on :$serverPort")
    }

    private suspend fun handleClient(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            socket.use {
                val reader = BufferedReader(InputStreamReader(it.getInputStream()))
                val writer = PrintWriter(it.getOutputStream(), true)

                val requestLine = reader.readLine() ?: return@use
                var contentLength = 0
                var line = reader.readLine()
                while (!line.isNullOrEmpty()) {
                    if (line.lowercase().startsWith("content-length:"))
                        contentLength = line.split(":")[1].trim().toIntOrNull() ?: 0
                    line = reader.readLine()
                }
                val path = requestLine.split(" ").getOrNull(1) ?: "/"

                when {
                    requestLine.startsWith("GET") && path == "/health" -> {
                        sendJson(writer, 200, """{"status":"ok","loaded":$_loaded}""")
                    }
                    requestLine.startsWith("POST") && path == "/generate" -> {
                        val chars = CharArray(contentLength)
                        reader.read(chars)
                        val json   = JSONObject(String(chars))
                        val prompt = json.optString("prompt", "")
                        val maxTok = json.optInt("max_tokens", MAX_TOKENS)
                        val temp   = json.optDouble("temperature", TEMPERATURE.toDouble()).toFloat()
                        val resp   = generate(prompt, maxTok, temp)
                        sendJson(writer, 200, JSONObject().apply {
                            put("text", resp); put("loaded", _loaded)
                        }.toString())
                    }
                    requestLine.startsWith("GET") && path == "/status" -> {
                        sendJson(writer, 200, JSONObject().apply {
                            put("loaded", _loaded)
                            put("model_exists", File(DEFAULT_MODEL_PATH).exists())
                            put("model_path", DEFAULT_MODEL_PATH)
                        }.toString())
                    }
                    else -> sendJson(writer, 404, """{"error":"not found"}""")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Client: ${e.message}")
        }
    }

    private fun sendJson(writer: PrintWriter, code: Int, body: String) {
        val status = if (code == 200) "OK" else "Not Found"
        writer.print("HTTP/1.1 $code $status\r\n")
        writer.print("Content-Type: application/json; charset=utf-8\r\n")
        writer.print("Content-Length: ${body.toByteArray().size}\r\n")
        writer.print("Access-Control-Allow-Origin: *\r\n")
        writer.print("\r\n")
        writer.print(body)
        writer.flush()
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
    }

    // ══════════════════════════════════════════════
    // SMART FALLBACK
    // ══════════════════════════════════════════════
    fun smartFallback(input: String): String {
        val t = input.lowercase()
        return when {
            t.contains("صباح")  -> """{"action":"answer","text":"☀️ صباح النور! إيه أول حاجة النهارده؟"}"""
            t.contains("مساء")  -> """{"action":"answer","text":"🌙 مساء الخير! إيه اللي عملته النهارده؟"}"""
            t.contains("ذكر") || t.contains("remind") ->
                """{"action":"tool","tool":"set_reminder","args":{"label":"تذكير","time":"09:00","pre_alert_minutes":10}}"""
            t.contains("ابحث") || t.contains("search") ->
                """{"action":"tool","tool":"search","args":{"query":"${input.take(100)}"}}"""
            t.contains("احسب") ->
                """{"action":"tool","tool":"calculate","args":{"expression":"${t.replace("احسب","").trim()}"}}"""
            t.contains("شكر")   -> """{"action":"answer","text":"💙 العفو دايماً!"}"""
            else                -> """{"action":"answer","text":"🤖 فاهمك — قولي أكتر وهساعدك."}"""
        }
    }

    // ══════════════════════════════════════════════
    // CLEANUP
    // ══════════════════════════════════════════════
    fun unload() {
        stopServer()
        try { llm?.close() } catch (_: Exception) {}
        llm = null
        _loaded = false
        Log.i(TAG, "Gemma unloaded")
    }
}
