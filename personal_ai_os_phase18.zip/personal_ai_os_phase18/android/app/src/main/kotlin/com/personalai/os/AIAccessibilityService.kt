// AIAccessibilityService.kt — Phase 7
// ══════════════════════════════════════════════════
// يقرأ الشاشة الحالية ويبعت context للـ agent
// يشتغل في الخلفية بدون ما المستخدم يحس
//
// ما بيعمله:
//   - يعرف المستخدم بيستخدم إيه app
//   - يشوف النص الظاهر على الشاشة
//   - يقترح actions ذكية عبر الـ Overlay
// ══════════════════════════════════════════════════
package com.personalai.os

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AIAccessibilityService : AccessibilityService() {

    private val TAG = "AIAccessibility"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Debounce — متبعتش للـ agent عند كل حدث
    private var lastSentApp    = ""
    private var lastSentTime   = 0L
    private val DEBOUNCE_MS    = 3000L   // 3 ثواني بين كل إرسال

    // ── Configure ─────────────────────────────────
    override fun onServiceConnected() {
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType     = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags            = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                               AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 500L
        }
        Log.i(TAG, "✅ Accessibility Service connected")
        ScreenContextStore.serviceConnected = true
    }

    override fun onInterrupt() {
        Log.w(TAG, "Service interrupted")
        ScreenContextStore.serviceConnected = false
    }

    override fun onDestroy() {
        scope.cancel()
        ScreenContextStore.serviceConnected = false
        super.onDestroy()
    }

    // ── Main event handler ────────────────────────
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return
        if (isSystemPackage(packageName)) return

        val now = System.currentTimeMillis()
        if (packageName == lastSentApp && now - lastSentTime < DEBOUNCE_MS) return

        lastSentApp  = packageName
        lastSentTime = now

        val appName  = getAppName(packageName)
        val nodeText = extractScreenText(rootInActiveWindow)

        val context = ScreenContext(
            packageName = packageName,
            appName     = appName,
            screenText  = nodeText.take(500),   // أول 500 حرف بس
            timestamp   = now,
        )

        // Store locally
        ScreenContextStore.current = context

        Log.d(TAG, "Screen: $appName | text: ${nodeText.take(60)}...")

        // Send to agent for smart suggestions
        scope.launch { sendToAgent(context) }
    }

    // ── Extract text from screen ──────────────────
    private fun extractScreenText(node: AccessibilityNodeInfo?): String {
        node ?: return ""
        val sb = StringBuilder()
        extractNode(node, sb, depth = 0)
        return sb.toString().trim()
    }

    private fun extractNode(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 8) return  // limit traversal depth

        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()

        if (!text.isNullOrBlank() && text.length > 1) {
            sb.append(text).append(" ")
        } else if (!desc.isNullOrBlank() && desc.length > 1) {
            sb.append(desc).append(" ")
        }

        for (i in 0 until node.childCount) {
            try {
                val child = node.getChild(i) ?: continue
                extractNode(child, sb, depth + 1)
                child.recycle()
            } catch (_: Exception) {}
        }
    }

    // ── Get human-readable app name ───────────────
    private fun getAppName(packageName: String): String {
        return try {
            val pm   = packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            packageName.split(".").last()
        }
    }

    // ── Filter system apps ────────────────────────
    private fun isSystemPackage(pkg: String): Boolean {
        return pkg.startsWith("com.android.") ||
               pkg.startsWith("android.") ||
               pkg == "com.personalai.os" ||   // نفسنا
               pkg == "com.google.android.inputmethod"
    }

    // ── Send context to Python agent ──────────────
    private suspend fun sendToAgent(ctx: ScreenContext) {
        try {
            val payload = JSONObject().apply {
                put("app_name",    ctx.appName)
                put("package",     ctx.packageName)
                put("screen_text", ctx.screenText)
            }.toString()

            val url  = URL("http://localhost:7070/screen_context")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod     = "POST"
            conn.doOutput          = true
            conn.connectTimeout    = 2000
            conn.readTimeout       = 5000
            conn.setRequestProperty("Content-Type", "application/json")

            conn.outputStream.use { it.write(payload.toByteArray()) }

            val code = conn.responseCode
            if (code == 200) {
                val resp = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(resp)
                val suggestion = json.optString("suggestion", "")
                if (suggestion.isNotEmpty()) {
                    // عرض الـ suggestion على الـ Overlay
                    withContext(Dispatchers.Main) {
                        SmartOverlay.showSuggestion(this@AIAccessibilityService, suggestion, ctx.appName)
                    }
                }
            }
            conn.disconnect()
        } catch (e: Exception) {
            Log.d(TAG, "Agent unreachable: ${e.message}")
        }
    }
}

// ── Screen Context Data ───────────────────────────
data class ScreenContext(
    val packageName: String,
    val appName:     String,
    val screenText:  String,
    val timestamp:   Long,
)

// ── Global store (MainActivity يقرأ منه) ─────────
object ScreenContextStore {
    @Volatile var current: ScreenContext? = null
    @Volatile var serviceConnected: Boolean = false
}
