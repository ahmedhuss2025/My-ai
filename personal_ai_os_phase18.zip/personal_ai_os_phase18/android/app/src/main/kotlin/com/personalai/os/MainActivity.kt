// android/app/src/main/kotlin/com/personalai/os/MainActivity.kt
// ══════════════════════════════════════════════════
// Personal AI OS — Android Bridge
// 3 Platform Channels:
//   1. personal_ai_os/gemma    → Gemma 3 LLM
//   2. personal_ai_os/system   → Background + Overlay
//   3. personal_ai_os/neural   → On-device inference
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import java.io.File

// ── Constants ─────────────────────────────────────
private const val CH_GEMMA  = "personal_ai_os/gemma"
private const val CH_SYSTEM = "personal_ai_os/system"
private const val CH_NEURAL = "personal_ai_os/neural"
private const val CH_SCREEN   = "personal_ai_os/screen"    // Phase 7
private const val CH_NETWORK  = "personal_ai_os/network"   // Phase 11
private const val OVERLAY_REQ = 1001

class MainActivity : FlutterActivity() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Engines (lazy — init on first use)
    private val gemma  by lazy { GemmaEngine(this) }
    private val neural by lazy { NeuralEngine() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannels()
    }

    override fun configureFlutterEngine(@NonNull engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        setupGemmaChannel(engine)
        setupSystemChannel(engine)
        setupNeuralChannel(engine)
        setupScreenChannel(engine)   // Phase 7
        setupNetworkChannel(engine)  // Phase 11
        setupWidgetChannel(engine)   // Phase 13
    }

    override fun onStart() {
        super.onStart()
        // Schedule widget background updates — Phase 13
        WidgetUpdateWorker.schedule(this)
        // Schedule weekly auto-backup — Phase 14
        BackupScheduler.schedule(this)
        // Handle deep link from widget tap
        handleWidgetDeeplink(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWidgetDeeplink(intent)
    }

    private fun handleWidgetDeeplink(intent: Intent?) {
        val screen = intent?.getStringExtra("WIDGET_SCREEN") ?: return
        // Send to Flutter via MethodChannel
        flutterEngine?.dartExecutor?.binaryMessenger?.let { messenger ->
            MethodChannel(messenger, "personal_ai_os/widget")
                .invokeMethod("openScreen", screen)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ══════════════════════════════════════════════
    // CHANNEL 1 — Gemma LLM
    // ══════════════════════════════════════════════
    private fun setupGemmaChannel(engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CH_GEMMA)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "loadGemma" -> {
                        val modelPath = call.argument<String>("modelPath")
                            ?: "/sdcard/models/gemma-2b-it-gpu-int4.bin"
                        scope.launch(Dispatchers.IO) {
                            val ok = gemma.load(modelPath)
                            withContext(Dispatchers.Main) {
                                if (ok) result.success("loaded")
                                else    result.error("LOAD_FAILED", "Model not found at $modelPath", null)
                            }
                        }
                    }

                    "generate" -> {
                        val prompt    = call.argument<String>("prompt") ?: ""
                        val maxTokens = call.argument<Int>("maxTokens") ?: 512
                        val temp      = call.argument<Double>("temperature") ?: 0.7

                        scope.launch(Dispatchers.IO) {
                            val text = gemma.generate(prompt, maxTokens, temp.toFloat())
                            withContext(Dispatchers.Main) {
                                result.success(text)
                            }
                        }
                    }

                    "isLoaded" -> result.success(gemma.isLoaded)

                    "unload"   -> { gemma.unload(); result.success(true) }

                    else -> result.notImplemented()
                }
            }
    }

    // ══════════════════════════════════════════════
    // CHANNEL 2 — System (BG Service + Overlay)
    // ══════════════════════════════════════════════
    private fun setupSystemChannel(engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CH_SYSTEM)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "startForegroundService" -> {
                        val intent = Intent(this, PersonalAIService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(intent)
                        } else {
                            startService(intent)
                        }
                        result.success(true)
                    }

                    "stopForegroundService" -> {
                        stopService(Intent(this, PersonalAIService::class.java))
                        result.success(true)
                    }

                    "requestOverlayPermission" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (!Settings.canDrawOverlays(this)) {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")
                                )
                                startActivityForResult(intent, OVERLAY_REQ)
                                result.success("requested")
                            } else {
                                result.success("granted")
                            }
                        } else {
                            result.success("granted") // < API 23 always allowed
                        }
                    }

                    "checkOverlayPermission" -> {
                        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            Settings.canDrawOverlays(this)
                        } else true
                        result.success(granted)
                    }

                    "showOverlay" -> {
                        val text = call.argument<String>("text") ?: ""
                        OverlayManager.show(this, text)
                        result.success(true)
                    }

                    "hideOverlay" -> {
                        OverlayManager.hide(this)
                        result.success(true)
                    }

                    "getBatteryLevel" -> {
                        result.success(BatteryHelper.getLevel(this))
                    }

                    "scheduleBackup" -> {
                        BackupScheduler.schedule(this)
                        result.success(true)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    // ══════════════════════════════════════════════
    // CHANNEL 3 — Neural Inference
    // ══════════════════════════════════════════════
    private fun setupNeuralChannel(engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CH_NEURAL)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "loadModel" -> {
                        val path = call.argument<String>("path") ?: ""
                        val ok = neural.loadFromAssets(assets, path)
                        result.success(ok)
                    }

                    "predict" -> {
                        val text      = call.argument<String>("text") ?: ""
                        val hour      = call.argument<Int>("hour") ?: 12
                        val battery   = call.argument<Int>("battery") ?: 80

                        scope.launch(Dispatchers.Default) {
                            val pred = neural.predict(text, hour, battery)
                            withContext(Dispatchers.Main) {
                                result.success(pred)
                            }
                        }
                    }

                    else -> result.notImplemented()
                }
            }
    }

    // ══════════════════════════════════════════════
    // CHANNEL 4 — Screen Intelligence (Phase 7)
    // ══════════════════════════════════════════════
    private fun setupScreenChannel(engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CH_SCREEN)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    // هل الـ Accessibility Service شغّال؟
                    "isAccessibilityEnabled" -> {
                        result.success(ScreenContextStore.serviceConnected)
                    }

                    // افتح إعدادات الـ Accessibility
                    "requestAccessibilityPermission" -> {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                        result.success("opened")
                    }

                    // جيب الـ screen context الحالي
                    "getScreenContext" -> {
                        val ctx = ScreenContextStore.current
                        if (ctx != null) {
                            result.success(mapOf(
                                "app_name"    to ctx.appName,
                                "package"     to ctx.packageName,
                                "screen_text" to ctx.screenText,
                            ))
                        } else {
                            result.success(null)
                        }
                    }

                    // عرض suggestion على الـ Overlay
                    "showSuggestion" -> {
                        val text    = call.argument<String>("text")    ?: ""
                        val appName = call.argument<String>("appName") ?: "AI"
                        SmartOverlay.showSuggestion(this, text, appName)
                        result.success(true)
                    }

                    // أخفي الـ overlay
                    "hideOverlay" -> {
                        SmartOverlay.hide()
                        result.success(true)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    // ── Notification Channels ────────────────────
    private fun createNotificationChannels() {
        // Phase 16: delegate to NotificationChannels object
        NotificationChannels.createAll(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            // Foreground service channel (keep existing)
            nm.createNotificationChannel(NotificationChannel(
                "ai_agent", "AI Agent",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Personal AI OS running in background"
                setShowBadge(false)
            })

            // Alert channel (for smart nudges)
            nm.createNotificationChannel(NotificationChannel(
                "ai_alerts", "AI Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Smart nudges and reminders"
            })
        }
    }

    // ── Phase 11: Network channel ─────────────────
    private fun setupNetworkChannel(engine: FlutterEngine) {
        // Start monitoring
        NetworkMonitor.start(this)

        MethodChannel(engine.dartExecutor.binaryMessenger, CH_NETWORK)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isOnline" -> result.success(NetworkMonitor.isOnline)

                    "pingTest" -> {
                        NetworkMonitor.pingTest { ok ->
                            result.success(ok)
                        }
                    }

                    else -> result.notImplemented()
                }
            }
    }

    // ── Phase 13: Widget Channel ──────────────────
    private fun setupWidgetChannel(engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, "personal_ai_os/widget")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "updateWidget" -> {
                        // Flutter asks widget to refresh
                        WidgetUpdateWorker.runNow(this)
                        result.success(true)
                    }
                    "getWidgetData" -> {
                        val prefs = getSharedPreferences("ai_widget_prefs", MODE_PRIVATE)
                        result.success(mapOf(
                            "suggestion"   to (prefs.getString("suggestion", "") ?: ""),
                            "online"       to prefs.getBoolean("online", false),
                            "pendingCount" to prefs.getInt("pending_count", 0),
                            "lastUpdate"   to (prefs.getString("last_update", "") ?: ""),
                        ))
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
