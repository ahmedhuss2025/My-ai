// android/.../BiometricManager.kt — Phase 17
// ══════════════════════════════════════════════════
// Biometric Authentication — Fingerprint / Face ID
// يستخدم BiometricPrompt API (Android 9+)
// ══════════════════════════════════════════════════
package com.personalai.os

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager as AndroidBioManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

object BiometricManager {

    // ── Check availability ────────────────────────
    fun isAvailable(ctx: Context): Boolean {
        val mgr = AndroidBioManager.from(ctx)
        val result = mgr.canAuthenticate(
            AndroidBioManager.Authenticators.BIOMETRIC_STRONG
        )
        return result == AndroidBioManager.BIOMETRIC_SUCCESS
    }

    fun getStatus(ctx: Context): String = when (
        AndroidBioManager.from(ctx).canAuthenticate(
            AndroidBioManager.Authenticators.BIOMETRIC_STRONG)
    ) {
        AndroidBioManager.BIOMETRIC_SUCCESS              -> "available"
        AndroidBioManager.BIOMETRIC_ERROR_NO_HARDWARE    -> "no_hardware"
        AndroidBioManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "hw_unavailable"
        AndroidBioManager.BIOMETRIC_ERROR_NONE_ENROLLED  -> "not_enrolled"
        else                                             -> "unknown"
    }

    // ── Show biometric prompt ─────────────────────
    fun authenticate(
        activity:  FragmentActivity,
        onSuccess: () -> Unit,
        onFailed:  () -> Unit,
        onError:   (String) -> Unit,
    ) {
        val executor = ContextCompat.getMainExecutor(activity)

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(
                result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                android.util.Log.i("BiometricMgr", "✅ Auth succeeded")
                // Tell Python agent to unlock
                notifyAgent()
                onSuccess()
            }
            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                android.util.Log.w("BiometricMgr", "Auth failed")
                onFailed()
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                super.onAuthenticationError(code, msg)
                android.util.Log.e("BiometricMgr", "Auth error $code: $msg")
                onError(msg.toString())
            }
        }

        val prompt   = BiometricPrompt(activity, executor, callback)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("قفل المساعد الذكي")
            .setSubtitle("استخدم بصمتك للفتح")
            .setNegativeButtonText("استخدم PIN")
            .setAllowedAuthenticators(AndroidBioManager.Authenticators.BIOMETRIC_STRONG)
            .build()

        prompt.authenticate(promptInfo)
    }

    // ── Tell Python agent: biometric unlocked ─────
    private fun notifyAgent() {
        thread(isDaemon = true) {
            try {
                val url  = URL("http://localhost:7070/security/biometric_unlock")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod  = "POST"
                conn.doOutput       = true
                conn.connectTimeout = 3000
                conn.readTimeout    = 5000
                conn.setRequestProperty("Content-Type", "application/json")
                OutputStreamWriter(conn.outputStream).use { it.write("{}") }
                conn.responseCode
                conn.disconnect()
            } catch (e: Exception) {
                android.util.Log.e("BiometricMgr", "Agent notify failed: ${e.message}")
            }
        }
    }
}
