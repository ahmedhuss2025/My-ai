// android/.../LockScreenWidget.kt — Phase 13
// ══════════════════════════════════════════════════
// Lock Screen Quick Actions
//   • يعرض اقتراح AI على شاشة القفل
//   • زر تسجيل صوتي سريع (بدون unlock)
//   • يستخدم widgetCategory="keyguard" من الـ widget_info.xml
//   • يتعامل مع KeyguardManager لإدارة الـ lock state
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.KeyguardManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

// ══════════════════════════════════════════════════
object LockScreenWidget {

    // ── Check if device is locked ─────────────────
    fun isLocked(ctx: Context): Boolean {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    // ── Build lock screen RemoteViews ─────────────
    fun buildViews(ctx: Context): RemoteViews {
        val prefs = ctx.getSharedPreferences("ai_widget_prefs", Context.MODE_PRIVATE)
        val views = RemoteViews(ctx.packageName, R.layout.widget_layout)

        // Lock screen: show time prominently
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        views.setTextViewText(R.id.widget_time, time)

        // Show suggestion
        val suggestion = prefs.getString("suggestion", "💡 اضغط للتحدث...")
        views.setTextViewText(R.id.widget_suggestion, "🔒 $suggestion")

        // Online status
        val online = prefs.getBoolean("online", false)
        views.setTextColor(
            R.id.widget_status,
            if (online) 0xFF00FF9D.toInt() else 0xFFEF5350.toInt()
        )

        // Lock screen buttons — unlock first, then open
        views.setOnClickPendingIntent(
            R.id.btn_voice,
            buildDismissAndOpenIntent(ctx, "voice", 10)
        )
        views.setOnClickPendingIntent(
            R.id.btn_chat,
            buildDismissAndOpenIntent(ctx, "chat", 11)
        )
        views.setOnClickPendingIntent(
            R.id.btn_meeting,
            buildDismissAndOpenIntent(ctx, "meeting", 12)
        )

        return views
    }

    // ── Update all instances on lock screen ───────
    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        if (!isLocked(ctx)) return
        val views = buildViews(ctx)
        for (id in ids) {
            mgr.updateAppWidget(id, views)
        }
    }

    // ── Intent that dismisses keyguard + opens app ─
    private fun buildDismissAndOpenIntent(
        ctx: Context, screen: String, reqCode: Int,
    ): PendingIntent {
        val intent = ctx.packageManager
            .getLaunchIntentForPackage(ctx.packageName)
            ?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("WIDGET_SCREEN", screen)
                // FLAG_DISMISS_KEYGUARD allows opening from lock screen
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT)
                }
            } ?: Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("WIDGET_SCREEN", screen)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        return PendingIntent.getActivity(ctx, reqCode, intent, flags)
    }
}
