// android/.../NotificationChannels.kt — Phase 16
// ══════════════════════════════════════════════════
// Android Notification Channels (required Android 8+)
// يُنشئ channels للأنواع المختلفة من التنبيهات
// ══════════════════════════════════════════════════
package com.personalai.os

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build

object NotificationChannels {

    // ── Channel IDs ──────────────────────────────
    const val CH_REMINDERS = "ai_reminders"
    const val CH_HABITS    = "ai_habits"
    const val CH_MEETINGS  = "ai_meetings"
    const val CH_ALERTS    = "ai_smart_alerts"
    const val CH_SYSTEM    = "ai_system"

    // ── Create all channels ──────────────────────
    fun createAll(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager

        nm.createNotificationChannels(listOf(
            makeChannel(
                id          = CH_REMINDERS,
                name        = "التذكيرات",
                desc        = "تذكيرات مجدولة ومخصصة",
                importance  = NotificationManager.IMPORTANCE_HIGH,
                lights      = true,
                lightColor  = Color.CYAN,
                vibrate     = true,
                vibPattern  = longArrayOf(0, 200, 100, 200),
            ),
            makeChannel(
                id          = CH_HABITS,
                name        = "العادات اليومية",
                desc        = "تنبيهات لمتابعة عاداتك",
                importance  = NotificationManager.IMPORTANCE_DEFAULT,
                lights      = true,
                lightColor  = Color.GREEN,
            ),
            makeChannel(
                id          = CH_MEETINGS,
                name        = "الاجتماعات",
                desc        = "تنبيهات قبل بداية الاجتماعات",
                importance  = NotificationManager.IMPORTANCE_HIGH,
                lights      = true,
                lightColor  = Color.YELLOW,
                vibrate     = true,
                vibPattern  = longArrayOf(0, 300, 200, 300, 200, 300),
            ),
            makeChannel(
                id          = CH_ALERTS,
                name        = "التنبيهات الذكية",
                desc        = "اقتراحات واقتناصات من المساعد الذكي",
                importance  = NotificationManager.IMPORTANCE_LOW,
            ),
            makeChannel(
                id          = CH_SYSTEM,
                name        = "النظام",
                desc        = "تنبيهات النظام والحالة",
                importance  = NotificationManager.IMPORTANCE_MIN,
            ),
        ))
    }

    // ── Build notification ────────────────────────
    fun build(
        ctx:       Context,
        channelId: String,
        title:     String,
        body:      String,
        priority:  String = "normal",
        actionTag: String = "",
    ): android.app.Notification {
        val importance = when (priority) {
            "urgent" -> android.app.Notification.PRIORITY_MAX
            "high"   -> android.app.Notification.PRIORITY_HIGH
            "low"    -> android.app.Notification.PRIORITY_LOW
            else     -> android.app.Notification.PRIORITY_DEFAULT
        }

        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            ?.apply { putExtra("NOTIF_ACTION", actionTag) }

        val pi = android.app.PendingIntent.getActivity(
            ctx, actionTag.hashCode(), intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                android.app.PendingIntent.FLAG_MUTABLE
            else android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            android.app.Notification.Builder(ctx, channelId)
        else
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(ctx)

        return builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(android.app.Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(importance)
            .build()
    }

    // ── Send immediately ──────────────────────────
    fun send(
        ctx:       Context,
        notifId:   Int,
        channelId: String,
        title:     String,
        body:      String,
        priority:  String = "normal",
        action:    String = "",
    ) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager
        val notif = build(ctx, channelId, title, body, priority, action)
        nm.notify(notifId, notif)
    }

    // ── Helpers ───────────────────────────────────
    private fun makeChannel(
        id:         String,
        name:       String,
        desc:       String,
        importance: Int,
        lights:     Boolean  = false,
        lightColor: Int      = Color.WHITE,
        vibrate:    Boolean  = false,
        vibPattern: LongArray= longArrayOf(0, 250),
    ): NotificationChannel {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
            throw UnsupportedOperationException()
        return NotificationChannel(id, name, importance).apply {
            description              = desc
            enableLights(lights)
            if (lights) this.lightColor = lightColor
            enableVibration(vibrate)
            if (vibrate) vibrationPattern = vibPattern
        }
    }
}
