# 🚀 خطوات الصبح — Personal AI OS

## الوقت: 30-45 دقيقة

---

## STEP 1 — تثبيت Flutter (10 دق، مرة واحدة)

```
1. روح: https://flutter.dev/docs/get-started/install/windows
2. نزّل Flutter SDK (zip) → فك في C:\flutter\
3. Android Studio → Settings → Plugins → "Flutter" → Install → Restart
4. Terminal → flutter doctor
```

---

## STEP 2 — فتح المشروع (2 دق)

```
File → Open → اختار مجلد: personal_ai_os
```

### إضافة فونت Tajawal (اختياري)
```
https://fonts.google.com/specimen/Tajawal → Download
→ حط TTF files في: assets/fonts/
```
> لو مش عايز الفونت — شيل الـ `fonts:` section من pubspec.yaml

---

## STEP 3 — تشغيل (3 دق)

```bash
# في Terminal داخل Android Studio:
flutter pub get
flutter run
```

---

## STEP 4 — Gemma (في الخلفية أثناء شغلك)

```bash
# نزّل الموديل من Hugging Face:
# https://huggingface.co/google/gemma-2b-it

# بعد التحميل، حطه في الفون:
adb push gemma-2b-it-gpu-int4.bin /sdcard/models/
```

---

## 📁 Structure

```
lib/
├── main.dart                  ← Entry point
├── models/app_state.dart      ← Global state
├── screens/
│   ├── onboarding_screen.dart ← 4 slides
│   ├── main_shell.dart        ← Bottom nav
│   ├── chat_screen.dart       ← Chat UI
│   ├── dashboard_screen.dart  ← Dashboard
│   └── settings_screen.dart  ← Settings
├── services/ai_service.dart   ← Smart responses
└── widgets/
    ├── chat_bubble.dart
    ├── neural_bar.dart
    └── thinking_dots.dart

android/app/src/main/kotlin/com/personalai/os/
├── MainActivity.kt     ← 3 Platform Channels
├── GemmaEngine.kt      ← LLM wrapper
├── NeuralEngine.kt     ← On-device inference
├── PersonalAIService.kt← Foreground service
├── OverlayManager.kt   ← System overlay
├── BootReceiver.kt     ← Auto-start on boot
├── BatteryHelper.kt    ← Battery monitoring
└── BackupScheduler.kt  ← Weekly backup
```

---

## 🔜 Phase 4 (بعدين)
- Gemma integrated (بعد تحميل الموديل)
- LoRA fine-tuning على بيانات المستخدم
- Screen intelligence (قراءة الشاشة)
- Smart overlay suggestions
