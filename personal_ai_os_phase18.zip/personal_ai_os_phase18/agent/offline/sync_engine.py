# agent/offline/sync_engine.py — Phase 11
# ══════════════════════════════════════════════════
# يراقب الـ connectivity ويفرّغ الـ queue لما يرجع الإنترنت
# يشتغل كـ background daemon thread
#
# ملاحظة مهمة لـ sandbox:
# _check_connectivity() بيرجّع False دايماً في الـ sandbox
# لأن مفيش internet access — وده متوقع وصح
# في production: بيرجّع True لما يكون في إنترنت
# ══════════════════════════════════════════════════
import json
import time
import threading
import datetime
from typing import Callable, Optional, Dict

from . import offline_queue as oq
from . import local_cache   as lc

# ── Check intervals ───────────────────────────────
_INTERVAL_ONLINE  = 30    # check كل 30 ثانية لما online
_INTERVAL_OFFLINE = 10    # check كل 10 ثواني لما offline
_PROCESS_INTERVAL = 5     # process queue كل 5 ثواني


class SyncEngine:
    """
    يدير connectivity state ويشغّل الـ queue:
      ■ يفحص الـ connectivity بشكل دوري
      ■ لو رجع الإنترنت → يفرّغ الـ queue
      ■ يوفر callbacks للـ server عشان يعرف الحالة
      ■ لا يعتمد على HTTP حقيقي في الـ check
        (يستخدم socket بس — أسرع وأخف)
    """

    def __init__(self):
        self._online:  bool = False
        self._running: bool = False
        self._thread:  Optional[threading.Thread] = None
        self._lock     = threading.Lock()

        # Callbacks
        self._on_online:  Optional[Callable[[], None]] = None
        self._on_offline: Optional[Callable[[], None]] = None
        self._on_synced:  Optional[Callable[[int], None]] = None

        # HTTP sender — injected by server.py
        self._http_send: Optional[Callable] = None

        # Stats
        self.synced_total: int = 0
        self.last_sync:    str = ""
        self.last_check:   str = ""

    # ── Injection ─────────────────────────────────
    def set_http_sender(self, fn: Callable):
        self._http_send = fn

    def on_online(self,  fn: Callable): self._on_online  = fn
    def on_offline(self, fn: Callable): self._on_offline = fn
    def on_synced(self,  fn: Callable): self._on_synced  = fn

    # ── State ─────────────────────────────────────
    @property
    def is_online(self) -> bool:
        return self._online

    def get_status(self) -> Dict:
        return {
            "online":        self._online,
            "pending_count": oq.get_pending_count(),
            "synced_total":  self.synced_total,
            "last_sync":     self.last_sync,
            "last_check":    self.last_check,
            "queue_stats":   oq.get_stats(),
            "cache_stats":   lc.get_stats(),
        }

    # ── Start / Stop ──────────────────────────────
    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name="SyncEngine"
        )
        self._thread.start()
        print("📶 SyncEngine started")

    def stop(self):
        self._running = False
        print("📶 SyncEngine stopped")

    # ── Main loop ─────────────────────────────────
    def _loop(self):
        last_conn_check  = 0.0
        last_queue_proc  = 0.0

        while self._running:
            now = time.time()
            interval = _INTERVAL_ONLINE if self._online else _INTERVAL_OFFLINE

            # ── Connectivity check ────────────────
            if now - last_conn_check >= interval:
                was_online    = self._online
                self._online  = self._check_connectivity()
                self.last_check = _now()
                last_conn_check = now

                if self._online and not was_online:
                    print("🌐 Back online — processing queue")
                    if self._on_online:
                        try:
                            self._on_online()
                        except Exception:
                            pass

                elif not self._online and was_online:
                    print("📴 Gone offline")
                    if self._on_offline:
                        try:
                            self._on_offline()
                        except Exception:
                            pass

            # ── Process queue when online ─────────
            if self._online and now - last_queue_proc >= _PROCESS_INTERVAL:
                self._process_queue()
                last_queue_proc = now

            # ── Hourly cache cleanup ──────────────
            if int(now) % 3600 < 2:
                lc.purge_expired()
                oq.clear_old_done(hours=12)

            time.sleep(1)

    # ── Connectivity check (socket, no HTTP) ──────
    def _check_connectivity(self) -> bool:
        """
        يجرّب يفتح socket لـ DNS servers المعروفة
        بدون HTTP — أسرع وأخف
        ملاحظة: في الـ sandbox بيرجّع False دايماً
        """
        import socket
        hosts = [
            ("8.8.8.8", 53),    # Google DNS
            ("1.1.1.1", 53),    # Cloudflare DNS
            ("208.67.222.222", 53),  # OpenDNS
        ]
        for host, port in hosts:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect((host, port))
                sock.close()
                return True
            except (socket.timeout, socket.error, OSError):
                continue
        return False

    # ── Process queue ─────────────────────────────
    def _process_queue(self):
        if not self._http_send:
            return
        items = oq.dequeue(limit=5)
        if not items:
            return

        synced = 0
        for item in items:
            try:
                oq.mark_retrying(item["id"])
                payload  = json.loads(item["payload"])
                endpoint = item["endpoint"]

                result = self._http_send(endpoint, payload)
                if result is not None:
                    oq.mark_success(item["id"], json.dumps(result)[:300])
                    synced += 1
                    print(f"  ✅ Synced [{endpoint}]")
                else:
                    oq.mark_failed(item["id"], "null response")
            except Exception as e:
                oq.mark_failed(item["id"], str(e)[:200])
                print(f"  ❌ Sync failed [{item.get('endpoint')}]: {e}")

        if synced > 0:
            self.synced_total += synced
            self.last_sync     = _now()
            if self._on_synced:
                try:
                    self._on_synced(synced)
                except Exception:
                    pass


# ── Global singleton ──────────────────────────────
_engine = SyncEngine()


def get_engine() -> SyncEngine:
    return _engine


def start():
    _engine.start()


def stop():
    _engine.stop()


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
