# agent/offline/local_cache.py — Phase 11
# ══════════════════════════════════════════════════
# Cache للـ responses — يتجنب repeated server calls
# TTL مختلف لكل نوع endpoint
# لا cache للـ /chat conversations — دايماً جديد
# ══════════════════════════════════════════════════
import sqlite3
import json
import hashlib
import datetime
from pathlib import Path
from typing import Optional, Dict

CACHE_DB = Path("offline/data/cache.db")

# TTL بالثواني لكل نوع
_TTL = {
    "chat":         0,       # no-cache — كل رسالة فريدة
    "search":       3600,    # ساعة
    "stats":        300,     # 5 دقائق
    "insights":     1800,    # 30 دقيقة
    "profile":      600,     # 10 دقائق
    "get_time":     30,      # 30 ثانية بس
    "list_reminders": 60,    # دقيقة
    "default":      600,     # 10 دقائق
}


def _get_conn() -> sqlite3.Connection:
    CACHE_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(CACHE_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _init():
    with _get_conn() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                key        TEXT PRIMARY KEY,
                endpoint   TEXT NOT NULL,
                response   TEXT NOT NULL,
                hits       INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )
        """)
        db.execute(
            "CREATE INDEX IF NOT EXISTS idx_cache_exp ON cache(expires_at)"
        )


_init()


def _ttl_for(endpoint: str) -> int:
    for k, v in _TTL.items():
        if k in endpoint:
            return v
    return _TTL["default"]


def _make_key(endpoint: str, payload: dict) -> str:
    raw = f"{endpoint}::{json.dumps(payload, sort_keys=True, ensure_ascii=False)}"
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


# ══════════════════════════════════════════════════
def get(endpoint: str, payload: dict) -> Optional[Dict]:
    """يرجّع cached response أو None لو miss/expired"""
    ttl = _ttl_for(endpoint)
    if ttl == 0:
        return None

    key = _make_key(endpoint, payload)
    now = _now()
    with _get_conn() as db:
        row = db.execute(
            "SELECT response FROM cache WHERE key=? AND expires_at>?",
            (key, now)
        ).fetchone()
        if row:
            db.execute(
                "UPDATE cache SET hits=hits+1 WHERE key=?", (key,)
            )
            try:
                return json.loads(row["response"])
            except Exception:
                pass
    return None


def set(endpoint: str, payload: dict, response: dict) -> bool:
    """يحفظ في الـ cache — يرجّع False لو no-cache"""
    ttl = _ttl_for(endpoint)
    if ttl == 0:
        return False

    key        = _make_key(endpoint, payload)
    now        = _now()
    expires_at = (
        datetime.datetime.now() + datetime.timedelta(seconds=ttl)
    ).strftime("%Y-%m-%d %H:%M:%S")

    try:
        with _get_conn() as db:
            db.execute(
                """INSERT OR REPLACE INTO cache
                   (key, endpoint, response, hits, created_at, expires_at)
                   VALUES (?,?,?,0,?,?)""",
                (key, endpoint,
                 json.dumps(response, ensure_ascii=False),
                 now, expires_at)
            )
        return True
    except Exception:
        return False


def invalidate(endpoint: str = None):
    """يمسح cache لـ endpoint معين أو كل الـ cache"""
    with _get_conn() as db:
        if endpoint:
            db.execute(
                "DELETE FROM cache WHERE endpoint LIKE ?", (f"%{endpoint}%",)
            )
        else:
            db.execute("DELETE FROM cache")


def purge_expired() -> int:
    """يحذف expired entries — يرجّع عدد المحذوف"""
    with _get_conn() as db:
        n = db.execute(
            "DELETE FROM cache WHERE expires_at<=?", (_now(),)
        ).rowcount
    return n


def get_stats() -> Dict:
    now = _now()
    with _get_conn() as db:
        row = db.execute(
            """SELECT
               COUNT(*)                                      AS total,
               SUM(hits)                                     AS total_hits,
               SUM(CASE WHEN expires_at>? THEN 1 ELSE 0 END) AS valid,
               SUM(CASE WHEN expires_at<=? THEN 1 ELSE 0 END) AS expired
               FROM cache""",
            (now, now)
        ).fetchone()
    return dict(row) if row else {}


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
