# agent/offline/offline_queue.py — Phase 11
# ══════════════════════════════════════════════════
# Queue للـ requests اللي فشلت لما يكون offline
# يُخزَّن في SQLite — persistent across restarts
# يدعم priorities + exponential backoff
# ══════════════════════════════════════════════════
import sqlite3
import json
import uuid
import datetime
from pathlib import Path
from typing import List, Dict, Optional

QUEUE_DB = Path("offline/data/queue.db")

# ── Status constants ──────────────────────────────
STATUS_PENDING  = 0
STATUS_RETRYING = 1
STATUS_DONE     = 2
STATUS_FAILED   = 3

# ── Priority constants ────────────────────────────
PRIORITY_HIGH   = 1   # تذكيرات، ملاحظات مهمة
PRIORITY_NORMAL = 2   # محادثات عادية
PRIORITY_LOW    = 3   # analytics، sync خلفية


# ══════════════════════════════════════════════════
def _get_conn() -> sqlite3.Connection:
    QUEUE_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(QUEUE_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _get_conn() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS queue (
                id           TEXT PRIMARY KEY,
                endpoint     TEXT NOT NULL,
                payload      TEXT NOT NULL,
                priority     INTEGER DEFAULT 2,
                status       INTEGER DEFAULT 0,
                attempts     INTEGER DEFAULT 0,
                max_attempts INTEGER DEFAULT 3,
                created_at   TEXT NOT NULL,
                updated_at   TEXT NOT NULL,
                next_retry   TEXT,
                result       TEXT,
                error        TEXT
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_queue_status
            ON queue(status, priority, next_retry)
        """)


init_db()


# ══════════════════════════════════════════════════
# ENQUEUE
# ══════════════════════════════════════════════════
def enqueue(
    endpoint:     str,
    payload:      dict,
    priority:     int = PRIORITY_NORMAL,
    max_attempts: int = 3,
) -> str:
    """يضيف request للـ queue — يرجّع id"""
    item_id = str(uuid.uuid4())[:12]
    now = _now()
    with _get_conn() as db:
        db.execute(
            """INSERT INTO queue
               (id, endpoint, payload, priority, status,
                attempts, max_attempts, created_at, updated_at)
               VALUES (?,?,?,?,?,0,?,?,?)""",
            (item_id,
             endpoint,
             json.dumps(payload, ensure_ascii=False),
             priority,
             STATUS_PENDING,
             max_attempts,
             now, now)
        )
    return item_id


# ══════════════════════════════════════════════════
# DEQUEUE — يجيب items جاهزة للتنفيذ
# ══════════════════════════════════════════════════
def dequeue(limit: int = 5) -> List[Dict]:
    """يرجّع items بـ PENDING/RETRYING وحان وقتها"""
    now = _now()
    with _get_conn() as db:
        rows = db.execute(
            """SELECT * FROM queue
               WHERE status IN (0, 1)
                 AND (next_retry IS NULL OR next_retry <= ?)
                 AND attempts < max_attempts
               ORDER BY priority ASC, created_at ASC
               LIMIT ?""",
            (now, limit)
        ).fetchall()
    return [dict(r) for r in rows]


# ══════════════════════════════════════════════════
# STATUS UPDATES
# ══════════════════════════════════════════════════
def mark_retrying(item_id: str):
    with _get_conn() as db:
        db.execute(
            "UPDATE queue SET status=?, updated_at=? WHERE id=?",
            (STATUS_RETRYING, _now(), item_id)
        )


def mark_success(item_id: str, result: str = ""):
    with _get_conn() as db:
        db.execute(
            "UPDATE queue SET status=?, result=?, updated_at=? WHERE id=?",
            (STATUS_DONE, result[:500], _now(), item_id)
        )


def mark_failed(item_id: str, error: str = ""):
    """Exponential backoff: 60s → 300s → 900s"""
    with _get_conn() as db:
        row = db.execute(
            "SELECT attempts, max_attempts FROM queue WHERE id=?",
            (item_id,)
        ).fetchone()
        if not row:
            return

        attempts     = row["attempts"] + 1   # نزود الـ attempts
        max_attempts = row["max_attempts"]
        backoff_secs = min(60 * (2 ** (attempts - 1)), 3600)
        next_retry   = (
            datetime.datetime.now() + datetime.timedelta(seconds=backoff_secs)
        ).strftime("%Y-%m-%d %H:%M:%S")

        if attempts >= max_attempts:
            new_status = STATUS_FAILED
            next_retry = None
        else:
            new_status = STATUS_RETRYING

        db.execute(
            """UPDATE queue SET
               status=?, attempts=?, error=?,
               next_retry=?, updated_at=?
               WHERE id=?""",
            (new_status, attempts, error[:300], next_retry, _now(), item_id)
        )


def reset_failed():
    """يعيد FAILED items لـ PENDING للمحاولة مرة تانية"""
    with _get_conn() as db:
        db.execute(
            """UPDATE queue SET
               status=?, attempts=0, next_retry=NULL, updated_at=?
               WHERE status=?""",
            (STATUS_PENDING, _now(), STATUS_FAILED)
        )


# ══════════════════════════════════════════════════
# QUERY
# ══════════════════════════════════════════════════
def get_stats() -> Dict:
    with _get_conn() as db:
        rows = db.execute(
            "SELECT status, COUNT(*) as cnt FROM queue GROUP BY status"
        ).fetchall()
    counts = {r["status"]: r["cnt"] for r in rows}
    return {
        "pending":  counts.get(STATUS_PENDING,  0),
        "retrying": counts.get(STATUS_RETRYING, 0),
        "done":     counts.get(STATUS_DONE,     0),
        "failed":   counts.get(STATUS_FAILED,   0),
        "total":    sum(counts.values()),
    }


def get_pending_count() -> int:
    with _get_conn() as db:
        row = db.execute(
            "SELECT COUNT(*) FROM queue WHERE status IN (0, 1)"
        ).fetchone()
    return row[0] if row else 0


def get_recent(limit: int = 20) -> List[Dict]:
    with _get_conn() as db:
        rows = db.execute(
            """SELECT id, endpoint, priority, status, attempts,
                      created_at, updated_at, error
               FROM queue
               ORDER BY created_at DESC
               LIMIT ?""",
            (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


def clear_old_done(hours: int = 24):
    cutoff = (
        datetime.datetime.now() - datetime.timedelta(hours=hours)
    ).strftime("%Y-%m-%d %H:%M:%S")
    with _get_conn() as db:
        db.execute(
            "DELETE FROM queue WHERE status=? AND updated_at<?",
            (STATUS_DONE, cutoff)
        )


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
