# agent/security/app_lock.py — Phase 17
# ══════════════════════════════════════════════════
# App Lock State Machine
# يدير حالة القفل: locked / unlocked / setup_needed
# auto-lock بعد timeout
# ══════════════════════════════════════════════════
import json
import time
import datetime
from pathlib import Path
from typing import Dict, Optional
from . import encryption_engine as enc

CONFIG_PATH   = Path('security/data/lock_config.json')
DEFAULT_TIMEOUT = 5   # minutes

# ── Lock states ───────────────────────────────────
STATE_UNLOCKED     = 'unlocked'
STATE_LOCKED       = 'locked'
STATE_SETUP_NEEDED = 'setup_needed'


class AppLockService:
    def __init__(self):
        self._state       = STATE_SETUP_NEEDED
        self._unlock_ts:  Optional[float] = None
        self._active_key: Optional[bytes] = None
        self._config      = self._load_config()
        self._init_state()

    # ── Init ──────────────────────────────────────
    def _init_state(self):
        if enc.has_pin():
            self._state = STATE_LOCKED
        else:
            self._state = STATE_SETUP_NEEDED

    # ── Public API ────────────────────────────────
    def get_status(self) -> Dict:
        self._check_timeout()
        return {
            'state':           self._state,
            'has_pin':         enc.has_pin(),
            'lock_enabled':    self._config.get('lock_enabled', False),
            'timeout_minutes': self._config.get('timeout_minutes', DEFAULT_TIMEOUT),
            'biometric_enabled': self._config.get('biometric_enabled', False),
            'unlocked_at':     datetime.datetime.fromtimestamp(
                self._unlock_ts).isoformat() if self._unlock_ts else None,
        }

    def setup_pin(self, pin: str) -> Dict:
        if len(pin) < 4:
            return {'ok': False, 'error': 'PIN يجب أن يكون 4 أرقام على الأقل'}
        enc.init_db()
        ok = enc.setup_pin(pin)
        if ok:
            self._state = STATE_LOCKED
            cfg = self._config
            cfg['lock_enabled'] = True
            self._save_config(cfg)
        return {'ok': ok}

    def unlock(self, pin: str) -> Dict:
        ok, key = enc.verify_pin(pin)
        if ok:
            self._state       = STATE_UNLOCKED
            self._unlock_ts   = time.time()
            self._active_key  = key
            return {'ok': True}
        # Count failures
        stats = enc.get_security_stats()
        return {
            'ok':     False,
            'error':  'PIN غير صحيح',
            'attempts': stats.get('failed_attempts', 0),
        }

    def lock(self) -> Dict:
        self._state      = STATE_LOCKED
        self._unlock_ts  = None
        self._active_key = None
        return {'ok': True}

    def unlock_biometric(self) -> Dict:
        """يُمرَّر من Android بعد نجاح البصمة"""
        if not self._config.get('biometric_enabled'):
            return {'ok': False, 'error': 'Biometric not enabled'}
        # في الإنتاج: Android يبعت token تم التحقق منه
        # هنا نثق بالـ call لأنه من MainActivity
        self._state      = STATE_UNLOCKED
        self._unlock_ts  = time.time()
        return {'ok': True, 'method': 'biometric'}

    def configure(self, **kwargs) -> Dict:
        cfg = self._config
        if 'timeout_minutes' in kwargs:
            cfg['timeout_minutes'] = max(1, int(kwargs['timeout_minutes']))
        if 'biometric_enabled' in kwargs:
            cfg['biometric_enabled'] = bool(kwargs['biometric_enabled'])
        if 'lock_enabled' in kwargs:
            cfg['lock_enabled'] = bool(kwargs['lock_enabled'])
            if not cfg['lock_enabled']:
                self._state = STATE_UNLOCKED
        self._config = cfg
        self._save_config(cfg)
        return {'ok': True, 'config': cfg}

    def change_pin(self, old_pin: str, new_pin: str) -> Dict:
        ok, _ = enc.verify_pin(old_pin)
        if not ok:
            return {'ok': False, 'error': 'PIN الحالي غير صحيح'}
        if len(new_pin) < 4:
            return {'ok': False, 'error': 'PIN الجديد يجب أن يكون 4 أرقام'}
        enc.setup_pin(new_pin)
        return {'ok': True}

    @property
    def active_key(self) -> Optional[bytes]:
        self._check_timeout()
        return self._active_key if self._state == STATE_UNLOCKED else None

    # ── Auto-lock ─────────────────────────────────
    def _check_timeout(self):
        if self._state != STATE_UNLOCKED: return
        if not self._unlock_ts: return
        if not self._config.get('lock_enabled'): return
        timeout = self._config.get('timeout_minutes', DEFAULT_TIMEOUT) * 60
        if time.time() - self._unlock_ts > timeout:
            self.lock()

    def keep_alive(self):
        """يحدّث آخر نشاط لمنع auto-lock"""
        if self._state == STATE_UNLOCKED:
            self._unlock_ts = time.time()

    # ── Config persistence ────────────────────────
    def _load_config(self) -> Dict:
        if CONFIG_PATH.exists():
            try:
                return json.loads(CONFIG_PATH.read_text('utf-8'))
            except Exception:
                pass
        return {
            'lock_enabled':      False,
            'timeout_minutes':   DEFAULT_TIMEOUT,
            'biometric_enabled': False,
        }

    def _save_config(self, cfg: Dict):
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding='utf-8')


# ── Singleton ─────────────────────────────────────
_lock_svc = AppLockService()

def get_service() -> AppLockService:
    return _lock_svc
