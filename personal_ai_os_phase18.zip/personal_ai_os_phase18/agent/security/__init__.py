# agent/security/__init__.py — Phase 17
from . import encryption_engine
from . import app_lock

try:
    encryption_engine.init_db()
except Exception:
    pass
