# agent/security/encryption_engine.py — Phase 17
# ══════════════════════════════════════════════════
# Encryption Engine
# تشفير المحادثات والبيانات الحساسة
#
# AES-256-GCM لكل رسالة
# PBKDF2-SHA256 لاشتقاق المفتاح من PIN
# كل رسالة لها nonce فريد
# ══════════════════════════════════════════════════
import os
import json
import base64
import hashlib
import secrets
import sqlite3
import datetime
from pathlib import Path
from typing import Optional, Dict, List, Tuple

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

DB_PATH   = Path('security/data/keys.db')
DATA_DIR  = Path('security/data')


# ══════════════════════════════════════════════════
# Key Management
# ══════════════════════════════════════════════════
def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS master_key (
            id         INTEGER PRIMARY KEY CHECK (id=1),
            salt       TEXT NOT NULL,
            key_check  TEXT NOT NULL,   -- HMAC of known value to verify PIN
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS encrypted_messages (
            id         TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            nonce      TEXT NOT NULL,   -- base64
            ciphertext TEXT NOT NULL,   -- base64
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS security_events (
            id         TEXT PRIMARY KEY,
            event      TEXT NOT NULL,   -- unlock/lock/failed_attempt/pin_change
            ts         TEXT NOT NULL,
            extra      TEXT DEFAULT ''
        );
    ''')
    conn.commit()
    conn.close()


def setup_pin(pin: str) -> bool:
    """يُنشئ master key من PIN"""
    salt      = secrets.token_bytes(32)
    key       = _derive_key(pin, salt)
    key_check = _make_key_check(key)
    now       = datetime.datetime.now().isoformat()

    conn = sqlite3.connect(str(DB_PATH))
    conn.execute('DELETE FROM master_key')
    conn.execute(
        'INSERT INTO master_key(id,salt,key_check,created_at,updated_at) VALUES(1,?,?,?,?)',
        (base64.b64encode(salt).decode(), key_check, now, now)
    )
    conn.commit(); conn.close()
    _log_event('pin_setup')
    return True


def verify_pin(pin: str) -> Tuple[bool, Optional[bytes]]:
    """يتحقق من PIN ويرجّع (ok, key)"""
    conn = sqlite3.connect(str(DB_PATH))
    row  = conn.execute('SELECT salt, key_check FROM master_key WHERE id=1').fetchone()
    conn.close()
    if not row:
        return False, None

    salt      = base64.b64decode(row[0])
    key       = _derive_key(pin, salt)
    expected  = row[1]
    check     = _make_key_check(key)

    if check == expected:
        _log_event('unlock')
        return True, key
    else:
        _log_event('failed_attempt')
        return False, None


def has_pin() -> bool:
    if not DB_PATH.exists(): return False
    conn = sqlite3.connect(str(DB_PATH))
    row  = conn.execute('SELECT COUNT(*) FROM master_key').fetchone()
    conn.close()
    return row[0] > 0


# ══════════════════════════════════════════════════
# Message Encryption
# ══════════════════════════════════════════════════
def encrypt_message(plaintext: str, key: bytes, msg_id: str,
                    session_id: str = 'default') -> str:
    """يشفّر رسالة ويحفظها في DB، يرجّع msg_id"""
    nonce      = secrets.token_bytes(12)
    aesgcm     = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
    now        = datetime.datetime.now().isoformat()

    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        'INSERT OR REPLACE INTO encrypted_messages(id,session_id,nonce,ciphertext,created_at) VALUES(?,?,?,?,?)',
        (msg_id, session_id,
         base64.b64encode(nonce).decode(),
         base64.b64encode(ciphertext).decode(),
         now)
    )
    conn.commit(); conn.close()
    return msg_id


def decrypt_message(msg_id: str, key: bytes) -> Optional[str]:
    """يفك تشفير رسالة بـ ID"""
    conn = sqlite3.connect(str(DB_PATH))
    row  = conn.execute(
        'SELECT nonce, ciphertext FROM encrypted_messages WHERE id=?', (msg_id,)
    ).fetchone()
    conn.close()
    if not row: return None
    try:
        nonce      = base64.b64decode(row[0])
        ciphertext = base64.b64decode(row[1])
        aesgcm     = AESGCM(key)
        return aesgcm.decrypt(nonce, ciphertext, None).decode('utf-8')
    except Exception:
        return None


def encrypt_text(plaintext: str, key: bytes) -> str:
    """يشفّر نص ويرجّعه base64 (بدون DB)"""
    nonce      = secrets.token_bytes(12)
    aesgcm     = AESGCM(key)
    ct         = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
    return base64.b64encode(nonce + ct).decode()


def decrypt_text(ciphertext_b64: str, key: bytes) -> Optional[str]:
    """يفك تشفير نص من base64"""
    try:
        raw        = base64.b64decode(ciphertext_b64)
        nonce, ct  = raw[:12], raw[12:]
        aesgcm     = AESGCM(key)
        return aesgcm.decrypt(nonce, ct, None).decode('utf-8')
    except Exception:
        return None


# ══════════════════════════════════════════════════
# Security Events
# ══════════════════════════════════════════════════
def get_security_log(limit: int = 50) -> List[Dict]:
    if not DB_PATH.exists(): return []
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        'SELECT * FROM security_events ORDER BY ts DESC LIMIT ?', (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_security_stats() -> Dict:
    if not DB_PATH.exists():
        return {'has_pin': False, 'events': 0, 'failed_attempts': 0}
    conn = sqlite3.connect(str(DB_PATH))
    total   = conn.execute('SELECT COUNT(*) FROM security_events').fetchone()[0]
    failed  = conn.execute(
        "SELECT COUNT(*) FROM security_events WHERE event='failed_attempt'"
    ).fetchone()[0]
    enc_msgs= conn.execute('SELECT COUNT(*) FROM encrypted_messages').fetchone()[0]
    conn.close()
    return {
        'has_pin':         has_pin(),
        'events':          total,
        'failed_attempts': failed,
        'encrypted_msgs':  enc_msgs,
    }


# ══════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════
def _derive_key(pin: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                     salt=salt, iterations=100_000)
    return kdf.derive(pin.encode('utf-8'))


def _make_key_check(key: bytes) -> str:
    import hmac as _hmac
    return _hmac.new(key, b'personal_ai_os_key_check',
                     'sha256').hexdigest()


def _log_event(event: str, extra: str = ''):
    if not DB_PATH.exists(): return
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        'INSERT INTO security_events(id,event,ts,extra) VALUES(?,?,?,?)',
        (secrets.token_hex(4), event,
         datetime.datetime.now().isoformat(), extra)
    )
    conn.commit(); conn.close()
