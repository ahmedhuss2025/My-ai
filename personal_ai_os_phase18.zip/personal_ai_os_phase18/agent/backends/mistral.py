# agent/backends/mistral.py — Phase 18
# ══════════════════════════════════════════════════
# Mistral 7B-Instruct Backend
# يشتغل عبر llama.cpp server (OpenAI-compatible API)
#
# تشغيل:
#   ./llama-server -m mistral-7b-instruct-v0.3.Q4_K_M.gguf \
#     --host 0.0.0.0 --port 8081 --n-gpu-layers 0
#
# أسرع من Gemma على العربي + أقوى في reasoning
# ══════════════════════════════════════════════════
import json
import re
import uuid
import time
import urllib.request
from typing import Dict, List
from .base import LLMBackend, LLMResponse, ToolCall


class MistralBackend(LLMBackend):
    """
    Mistral 7B-Instruct via llama.cpp
    يدعم:
      • llama.cpp /v1/chat/completions (OpenAI format)
      • أو /completion (raw format fallback)
    """
    SERVER_URL    = "http://localhost:8081"
    CHAT_ENDPOINT = "/v1/chat/completions"
    HEALTH_EP     = "/health"
    MODEL_NAME    = "mistral-7b-instruct"

    MAX_TOKENS    = 1024
    TEMPERATURE   = 0.7
    CHECK_TTL     = 20.0   # إعادة فحص كل 20 ثانية

    def __init__(self, server_url: str = None):
        self._base        = (server_url or self.SERVER_URL).rstrip('/')
        self._server_ok   = False
        self._last_check  = 0.0

    @property
    def name(self) -> str:
        return "Mistral 7B (On-Device)" if self._server_ok else "Mistral (Offline)"

    def is_available(self) -> bool:
        return True   # دايماً متاح (fallback mode لو الـ server مش شغال)

    # ── Health check ─────────────────────────────
    def _server_reachable(self) -> bool:
        now = time.time()
        if now - self._last_check < self.CHECK_TTL:
            return self._server_ok
        self._last_check = now
        try:
            with urllib.request.urlopen(
                self._base + self.HEALTH_EP, timeout=2
            ) as r:
                data = json.loads(r.read())
                self._server_ok = data.get('status') in ('ok', 'loading model')
        except Exception:
            self._server_ok = False
        status = "✅ متاح" if self._server_ok else "❌ غير متاح"
        print(f"🤖 Mistral 7B: {status}")
        return self._server_ok

    def reset_cache(self):
        self._last_check = 0.0

    # ── Main complete ─────────────────────────────
    def complete(self, system: str, messages: List[Dict],
                 tools: List[Dict]) -> LLMResponse:
        if self._server_reachable():
            return self._call_openai_compat(system, messages, tools)
        else:
            return self._smart_fallback(messages)

    # ── OpenAI-compatible call ─────────────────────
    def _call_openai_compat(self, system: str, messages: List[Dict],
                             tools: List[Dict]) -> LLMResponse:
        msgs = [{"role": "system", "content": self._build_system(system, tools)}]
        for m in messages:
            role    = m.get('role', 'user')
            content = m.get('content', '')
            if isinstance(content, list):
                content = ' '.join(
                    c.get('text','') for c in content if isinstance(c, dict))
            if content:
                msgs.append({"role": role, "content": str(content)})

        payload = json.dumps({
            "model":       self.MODEL_NAME,
            "messages":    msgs,
            "max_tokens":  self.MAX_TOKENS,
            "temperature": self.TEMPERATURE,
            "stream":      False,
        }).encode('utf-8')

        try:
            req = urllib.request.Request(
                self._base + self.CHAT_ENDPOINT,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as r:
                data  = json.loads(r.read())
                text  = data['choices'][0]['message']['content']
                return self._parse_response(text)
        except Exception as e:
            print(f"[Mistral] server error: {e}")
            return self._smart_fallback(messages)

    # ── System prompt with tool injection ────────
    def _build_system(self, system: str, tools: List[Dict]) -> str:
        if not tools:
            return system
        tool_desc = "\n".join(
            f"- {t['name']}: {t.get('description','')}" for t in tools)
        return (
            f"{system}\n\n"
            f"الأدوات المتاحة:\n{tool_desc}\n\n"
            f"لاستخدام أداة، رد بالشكل:\n"
            f"[TOOL: اسم_الأداة] {{\"param\": \"value\"}} [/TOOL]\n"
            f"وإلا رد مباشرة بالعربي."
        )

    # ── Parse response (tool or text) ────────────
    def _parse_response(self, text: str) -> LLMResponse:
        tool_pattern = r'\[TOOL:\s*(\w+)\]\s*(\{.*?\})\s*\[/TOOL\]'
        matches = re.findall(tool_pattern, text, re.DOTALL)
        if matches:
            calls = []
            for name, args_str in matches:
                try:
                    args = json.loads(args_str)
                except Exception:
                    args = {"raw": args_str}
                calls.append(ToolCall(
                    id=f"mistral_{uuid.uuid4().hex[:8]}",
                    name=name, args=args))
            return LLMResponse(done=False, tool_calls=calls)
        clean = re.sub(r'\[TOOL:.*?\[/TOOL\]', '', text, flags=re.DOTALL).strip()
        return LLMResponse(done=True, text=clean or text.strip())

    # ── Smart fallback (no server) ────────────────
    def _smart_fallback(self, messages: List[Dict]) -> LLMResponse:
        """رد ذكي بدون server — يحلل الطلب ويستجيب"""
        import datetime
        last = ""
        for m in reversed(messages):
            c = m.get('content', '')
            if isinstance(c, list):
                c = ' '.join(x.get('text','') for x in c if isinstance(x, dict))
            if m.get('role') == 'user' and c:
                last = c.lower(); break

        now = datetime.datetime.now()

        # Pattern matching للردود السريعة
        if any(w in last for w in ['وقت','ساعة','الان','الآن','كم الساعة']):
            return LLMResponse(done=True,
                text=f"الوقت الحالي: {now.strftime('%I:%M %p')} — "
                     f"{now.strftime('%A، %d %B %Y')}")

        if any(w in last for w in ['مرحبا','هلو','أهلا','السلام']):
            return LLMResponse(done=True,
                text="مرحباً! أنا مساعدك الذكي. "
                     "حالياً في وضع offline — يمكنني مساعدتك في الأسئلة الأساسية.")

        if any(w in last for w in ['شكرا','شكراً','ممتاز','عظيم']):
            return LLMResponse(done=True, text="بكل سرور! هل تحتاج شيئاً آخر؟")

        return LLMResponse(done=True,
            text=f"⚡ وضع offline — Mistral 7B غير متاح حالياً.\n"
                 f"سأعالج طلبك عند استعادة الاتصال.\n"
                 f"للردود الفورية، فعّل الـ API الخارجي من الإعدادات.")
