# agent/backends/gemma.py
import json, re, uuid, datetime
from typing import Dict, List
from .base import LLMBackend, LLMResponse, ToolCall

class GemmaBackend(LLMBackend):
    def __init__(self, server_url="http://localhost:8080/generate"):
        self.url         = server_url
        self._server_ok  = False
        self._last_check = 0.0      # timestamp آخر فحص
        self._check_ttl  = 15.0     # إعادة الفحص كل 15 ثانية

    @property
    def name(self):
        return "Gemma 2B-IT (On-Device)" if self._server_ok else "Gemma (Smart Fallback)"

    def is_available(self): return True

    def _server_reachable(self) -> bool:
        import time, urllib.request
        now = time.time()
        # لو TTL انتهت أو أول مرة → إعادة الفحص
        if now - self._last_check > self._check_ttl:
            self._last_check = now
            health = self.url.replace("/generate", "/health")
            try:
                with urllib.request.urlopen(health, timeout=2) as r:
                    data = json.loads(r.read())
                    self._server_ok = data.get("status") == "ok"
            except:
                self._server_ok = False
            if self._server_ok:
                print("🧠 Gemma on-device متاح على :8080")
            else:
                print("📱 Gemma غير متاح — smart fallback")
        return self._server_ok

    def reset_cache(self):
        """استدعيه لو الفون اتوصّل حديثاً"""
        self._last_check = 0.0

    def complete(self, system, messages, tools) -> LLMResponse:
        if self._server_reachable():
            raw = self._call_server(self._build_prompt(system, messages))
        else:
            raw = self._fallback(messages)
        return self._parse(raw)

    def _build_prompt(self, system, messages):
        import tools as t_mod
        history, last_user = "", ""
        for m in messages[-8:]:
            role = m.get("role",""); c = m.get("content","")
            if isinstance(c, list):
                c = " | ".join(x.get("content","") for x in c if isinstance(x,dict))
            if role == "user" and c:
                last_user = c; history += f"<start_of_turn>user\n{c}<end_of_turn>\n"
            elif role == "assistant" and c:
                history += f"<start_of_turn>model\n{c}<end_of_turn>\n"
        return (
            f"<start_of_turn>system\n{system}\n\n"
            f'ردودك JSON فقط:\n'
            f'  tool   → {{"action":"tool","tool":"...","args":{{...}},"thought":"..."}}\n'
            f'  answer → {{"action":"answer","text":"..."}}\n\n'
            f"Tools:\n{t_mod.schemas_for_gemma()}\n<end_of_turn>\n"
            f"{history}<start_of_turn>model\n"
        )

    def _call_server(self, prompt):
        import urllib.request
        data = json.dumps({"prompt":prompt,"max_tokens":512,"temperature":0.25}).encode()
        req = urllib.request.Request(self.url, data=data, headers={"Content-Type":"application/json"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                resp = json.loads(r.read())
                return resp.get("text", resp.get("response",""))
        except: return self._fallback([])

    def _parse(self, raw) -> LLMResponse:
        # strip markdown fences
        clean = re.sub(r"```(?:json)?|```","",raw).strip()
        # try direct JSON parse (fallback returns valid JSON)
        try:
            data = json.loads(clean)
        except json.JSONDecodeError:
            # messy LLM output — grab last full JSON object
            m = re.search(r"\{.*\}", clean, re.DOTALL)
            if not m: return LLMResponse(done=True, text=raw.strip())
            try:    data = json.loads(m.group())
            except: return LLMResponse(done=True, text=raw.strip())

        if data.get("action") == "tool":
            return LLMResponse(
                done=False,
                tool_calls=[ToolCall(
                    id=f"g_{uuid.uuid4().hex[:8]}",
                    name=data.get("tool",""),
                    args=data.get("args",{}),
                )],
                raw=data,
            )
        text = data.get("text", data.get("answer", str(data)))
        return LLMResponse(done=True, text=text, raw=data)

    def _fallback(self, messages):
        # لو في tool_result في آخر messages → ارجّع answer بالنتيجة
        for m in reversed(messages):
            c = m.get("content","")
            if m.get("role") == "user" and isinstance(c, list):
                for block in c:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        result_text = block.get("content","")
                        return json.dumps({
                            "action": "answer",
                            "text": result_text,
                        }, ensure_ascii=False)

        user_text = ""
        for m in reversed(messages):
            c = m.get("content","")
            if m.get("role") == "user" and isinstance(c,str) and c:
                user_text = c; break
        t = user_text.lower()

        if any(w in t for w in ["ابحث","دور","سعر","طقس","weather","search","أخبار"]):
            q = re.sub(r"ابحث\s*(عن)?|دور\s*(على)?|search\s*(for)?","",t).strip()
            return json.dumps({"action":"tool","tool":"search","args":{"query":q or user_text},"thought":"المستخدم عايز معلومة"}, ensure_ascii=False)

        if any(w in t for w in ["ذكرني","تذكير","remind","موعد","اجتماع"]):
            mx = re.search(r"(\d{1,2})[\s:]?(\d{2})?\s*(ص|م|am|pm)?", t)
            time_str = "09:00"
            if mx:
                h,mn = int(mx.group(1)), int(mx.group(2) or 0)
                if (mx.group(3) or "").lower() in ("م","pm") and h<12: h+=12
                time_str = f"{h:02d}:{mn:02d}"
            label = re.sub(r"ذكرني|تذكير|remind|الساعة[\s\d:صم]+|بـ|ب ","",user_text).strip() or "تذكير"
            return json.dumps({"action":"tool","tool":"set_reminder","args":{"time":time_str,"label":label,"pre_alert_minutes":10},"thought":f"هعمل تذكير الساعة {time_str}"}, ensure_ascii=False)

        if any(w in t for w in ["احسب","calculate"]) or (
            any(op in user_text for op in ["*","+","÷","×"]) and any(c.isdigit() for c in user_text)
        ):
            expr = re.sub(r"[^\d+\-*/().×÷ ]","",user_text).replace("×","*").replace("÷","/").strip()
            return json.dumps({"action":"tool","tool":"calculate","args":{"expression":expr or "1+1"},"thought":"هحسب"}, ensure_ascii=False)

        if any(w in t for w in ["احفظ","سجّل","note","ملاحظة"]):
            content = re.sub(r"احفظ|سجّل|note|ملاحظة|:","",user_text).strip()
            return json.dumps({"action":"tool","tool":"save_note","args":{"title":"ملاحظة","content":content or user_text},"thought":"هحفظ ملاحظة"}, ensure_ascii=False)

        if any(w in t for w in ["إحصائيات","stats","تقرير","إنتاجية"]):
            period = "week" if "أسبوع" in t else ("month" if "شهر" in t else "today")
            return json.dumps({"action":"tool","tool":"get_stats","args":{"period":period},"thought":"المستخدم عايز إحصائياته"}, ensure_ascii=False)

        if any(w in t for w in ["الوقت","كم الساعة","الساعة كام"]):
            return json.dumps({"action":"tool","tool":"get_time","args":{},"thought":"محتاج الوقت"}, ensure_ascii=False)

        if any(w in t for w in ["تذكيراتي","اعرض التذكيرات"]):
            return json.dumps({"action":"tool","tool":"list_reminders","args":{},"thought":"المستخدم عايز تذكيراته"}, ensure_ascii=False)

        now = datetime.datetime.now()
        if any(w in t for w in ["صباح","morning"]): text=f"☀️ صباح النور! الساعة {now.strftime('%H:%M')} — إيه أول حاجة النهارده؟"
        elif any(w in t for w in ["مساء","evening"]): text="🌙 مساء الخير! إيه اللي تعمله الليلة؟"
        elif any(w in t for w in ["شكراً","شكرا","thanks"]): text="💙 العفو دايماً!"
        elif any(w in t for w in ["أهلا","مرحبا","hello","hi"]): text="👋 أهلاً! إيه اللي تحتاجه؟"
        else: text="🤖 قولي أكتر وهساعدك."
        return json.dumps({"action":"answer","text":text}, ensure_ascii=False)
