# agent/backends/base.py
# ══════════════════════════════════════════════════
# LLM Backend Interface
# كل backend (Claude / Gemma) لازم يطبّق ده
# ══════════════════════════════════════════════════
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class ToolCall:
    """طلب tool من الـ LLM"""
    id:    str
    name:  str
    args:  Dict[str, Any]


@dataclass
class LLMResponse:
    """
    رد الـ LLM — نوعين بس:
      done=False → عايز يستدعي tool
      done=True  → انتهى، عنده إجابة
    """
    done:       bool
    text:       str = ""          # لما done=True
    tool_calls: List[ToolCall] = None   # لما done=False
    raw:        Any = None        # الرد الخام للـ debugging


class LLMBackend(ABC):
    """
    Interface مشترك — بدّل Claude بـ Gemma بسطر واحد:
      backend = ClaudeBackend()
      backend = GemmaBackend()
      # الـ agent مش بيتغير
    """

    @abstractmethod
    def complete(
        self,
        system:   str,
        messages: List[Dict],
        tools:    List[Dict],
    ) -> LLMResponse:
        """
        ابعت للـ LLM وارجّع LLMResponse
        """
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """هل الـ backend جاهز؟"""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """اسم الـ backend للـ logging"""
        ...
