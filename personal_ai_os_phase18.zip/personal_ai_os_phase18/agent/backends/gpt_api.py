# agent/backends/gpt_api.py — Phase 18
# ══════════════════════════════════════════════════
# OpenAI GPT-4o Backend — Emergency fallback
# يُستخدم فقط لو Mistral فشل + Claude فشل
# ══════════════════════════════════════════════════
import json
import os
import urllib.request
from typing import Dict, List
from .base import LLMBackend, LLMResponse, ToolCall


class GPTBackend(LLMBackend):
    API_URL    = "https://api.openai.com/v1/chat/completions"
    MODEL      = "gpt-4o"
    MAX_TOKENS = 1024

    def __init__(self, api_key: str = None):
        self._key = api_key or os.environ.get("OPENAI_API_KEY", "")

    @property
    def name(self) -> str: return "GPT-4o (OpenAI API)"

    def is_available(self) -> bool: return bool(self._key)

    def complete(self, system: str, messages: List[Dict],
                 tools: List[Dict]) -> LLMResponse:
        msgs = [{"role": "system", "content": system}]
        for m in messages:
            role    = m.get('role', 'user')
            content = m.get('content', '')
            if isinstance(content, list):
                content = ' '.join(
                    c.get('text','') for c in content if isinstance(c, dict))
            if content:
                msgs.append({"role": role, "content": str(content)})

        body = {
            "model":       self.MODEL,
            "messages":    msgs,
            "max_tokens":  self.MAX_TOKENS,
        }
        # OpenAI tools format
        if tools:
            body["tools"] = [
                {"type": "function",
                 "function": {
                     "name":        t["name"],
                     "description": t.get("description",""),
                     "parameters":  t.get("input_schema", {}),
                 }} for t in tools
            ]
            body["tool_choice"] = "auto"

        payload = json.dumps(body).encode('utf-8')
        req = urllib.request.Request(
            self.API_URL, data=payload,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {self._key}",
            }, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                data    = json.loads(r.read())
                choice  = data['choices'][0]
                msg     = choice['message']

                if choice.get('finish_reason') == 'tool_calls' and msg.get('tool_calls'):
                    calls = [
                        ToolCall(
                            id   = tc['id'],
                            name = tc['function']['name'],
                            args = json.loads(tc['function']['arguments'] or '{}'),
                        ) for tc in msg['tool_calls']
                    ]
                    return LLMResponse(done=False, tool_calls=calls)

                return LLMResponse(done=True,
                    text=msg.get('content', ''))
        except Exception as e:
            return LLMResponse(done=True,
                text=f"⚠️ GPT-4o غير متاح: {e}")
