# agent/backends/claude.py
import os
from typing import Dict, List
from .base import LLMBackend, LLMResponse, ToolCall

class ClaudeBackend(LLMBackend):
    MODEL = "claude-sonnet-4-5-20250929"

    def __init__(self, api_key: str = None):
        self._key = api_key or os.environ.get("ANTHROPIC_API_KEY","")
        self._client = None

    @property
    def name(self): return "Claude (Anthropic API)"

    def is_available(self): return bool(self._key)

    def _client_get(self):
        if not self._client:
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=self._key)
            except ImportError:
                raise RuntimeError("pip install anthropic")
        return self._client

    def complete(self, system, messages, tools) -> LLMResponse:
        r = self._client_get().messages.create(
            model=self.MODEL, max_tokens=1024,
            system=system, tools=tools, messages=messages,
        )
        if r.stop_reason == "tool_use":
            calls = [
                ToolCall(id=b.id, name=b.name, args=b.input)
                for b in r.content if b.type == "tool_use"
            ]
            return LLMResponse(done=False, tool_calls=calls, raw=r)
        text = "".join(b.text for b in r.content if hasattr(b,"text"))
        return LLMResponse(done=True, text=text, raw=r)
