# agent/backends/router.py — Phase 18
# ══════════════════════════════════════════════════
# Smart Backend Router
# الأولوية:
#   1. Mistral 7B (on-device)  ← primary
#   2. Claude API              ← emergency (لو Mistral فشل)
#   3. GPT-4o                  ← emergency (لو Claude فشل)
#
# يسجّل كل call في audit log
# ══════════════════════════════════════════════════
import time
import datetime
from typing import Dict, List, Optional
from .base   import LLMBackend, LLMResponse
from .mistral import MistralBackend
from .claude  import ClaudeBackend
from .gpt_api import GPTBackend


class BackendRouter(LLMBackend):
    """
    يختار أفضل backend متاح تلقائياً
    ويسجّل كل قرار في الـ audit
    """

    def __init__(self,
                 mistral_url:  str  = None,
                 claude_key:   str  = None,
                 gpt_key:      str  = None,
                 prefer_cloud: bool = False):
        self._mistral      = MistralBackend(mistral_url)
        self._claude       = ClaudeBackend(claude_key)
        self._gpt          = GPTBackend(gpt_key)
        self._prefer_cloud = prefer_cloud   # لو True: يجرب Claude أولاً

        self._last_backend = "none"
        self._stats        = {"mistral": 0, "claude": 0, "gpt": 0, "errors": 0}
        self._audit_cb     = None   # callback لـ audit_log

    @property
    def name(self) -> str:
        return f"Router → {self._last_backend}"

    def is_available(self) -> bool:
        return True  # دايماً في fallback

    def set_audit_callback(self, cb):
        """اربط الـ router بـ audit engine"""
        self._audit_cb = cb

    def set_keys(self, claude_key: str = None, gpt_key: str = None,
                 mistral_url: str = None):
        """تحديث الـ keys من الـ settings"""
        if claude_key:
            self._claude._key = claude_key
            self._claude._client = None
        if gpt_key:
            self._gpt._key = gpt_key
        if mistral_url:
            self._mistral._base = mistral_url.rstrip('/')
            self._mistral.reset_cache()

    def set_prefer_cloud(self, v: bool):
        self._prefer_cloud = v

    # ── Routing logic ─────────────────────────────
    def complete(self, system: str, messages: List[Dict],
                 tools: List[Dict]) -> LLMResponse:
        start = time.time()
        result, backend_used = self._try_backends(system, messages, tools)
        elapsed = round(time.time() - start, 2)

        self._last_backend = backend_used
        self._stats[backend_used.split('/')[0]] = \
            self._stats.get(backend_used.split('/')[0], 0) + 1

        self._log_audit(backend_used, elapsed, result)
        return result

    def _try_backends(self, system, messages, tools):
        """يجرب الـ backends بالترتيب"""
        order = self._get_order()
        last_err = None

        for (key, backend) in order:
            if not backend.is_available():
                continue
            try:
                result = backend.complete(system, messages, tools)
                return result, key
            except Exception as e:
                last_err = e
                self._stats["errors"] += 1
                print(f"[Router] {key} failed: {e} → trying next")
                continue

        # All failed
        return LLMResponse(done=True,
            text="⚠️ كل الـ backends غير متاحة. تحقق من الاتصال والإعدادات."), "none"

    def _get_order(self):
        """ترتيب الأولوية حسب الإعدادات"""
        if self._prefer_cloud:
            return [
                ("claude", self._claude),
                ("mistral", self._mistral),
                ("gpt",    self._gpt),
            ]
        # Default: Mistral first
        order = [("mistral", self._mistral)]
        if self._claude.is_available():
            order.append(("claude", self._claude))
        if self._gpt.is_available():
            order.append(("gpt", self._gpt))
        return order

    # ── Audit logging ─────────────────────────────
    def _log_audit(self, backend: str, elapsed: float, result: LLMResponse):
        if self._audit_cb:
            try:
                self._audit_cb({
                    "type":    "llm_call",
                    "backend": backend,
                    "elapsed": elapsed,
                    "done":    result.done,
                    "has_tools": not result.done,
                })
            except Exception:
                pass

    # ── Status for UI ─────────────────────────────
    def get_status(self) -> Dict:
        return {
            "current_backend": self._last_backend,
            "prefer_cloud":    self._prefer_cloud,
            "mistral_online":  self._mistral._server_ok,
            "claude_ready":    self._claude.is_available(),
            "gpt_ready":       self._gpt.is_available(),
            "stats":           self._stats,
        }
