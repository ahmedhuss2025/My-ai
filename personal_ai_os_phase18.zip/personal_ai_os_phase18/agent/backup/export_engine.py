# agent/backup/export_engine.py — Phase 14
# ══════════════════════════════════════════════════
# Export Engine
# يصدّر البيانات بصيغ مختلفة:
#   JSON  ← كل البيانات الخام
#   CSV   ← conversations + meetings
#   PDF   ← تقرير منظّم (ReportLab أو HTML fallback)
#   ZIP   ← كل الصيغ معاً
# ══════════════════════════════════════════════════
import os
import io
import csv
import json
import gzip
import base64
import sqlite3
import zipfile
import datetime
from pathlib import Path
from typing import Dict, List, Optional

EXPORT_DIR = Path('backup/exports')

# ── DB paths ─────────────────────────────────────
DB_MAIN     = Path('lora/data/personal_ai.db')
DB_MEETINGS = Path('creative/data/meetings.db')


# ══════════════════════════════════════════════════
# JSON EXPORT
# ══════════════════════════════════════════════════
def export_json(include_images: bool = False) -> Dict:
    """يصدّر كل البيانات JSON واحدة"""
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts       = datetime.datetime.now()
    filename = f'export_{ts.strftime("%Y%m%d_%H%M%S")}.json'
    path     = EXPORT_DIR / filename

    data = {
        'exported_at': ts.isoformat(),
        'version':     '1.0',
        'app':         'Personal AI OS',
        'data': {
            'conversations': _load_conversations(),
            'reminders':     _load_reminders(),
            'notes':         _load_notes(),
            'meetings':      _load_meetings(),
            'profile':       _load_profile(),
        }
    }

    if include_images:
        data['data']['images'] = _load_images_b64()

    json_str = json.dumps(data, ensure_ascii=False, indent=2)
    path.write_text(json_str, encoding='utf-8')

    return {
        'ok':       True,
        'format':   'json',
        'filename': filename,
        'path':     str(path),
        'size_kb':  round(path.stat().st_size / 1024, 1),
        'records': {
            'conversations': len(data['data']['conversations']),
            'reminders':     len(data['data']['reminders']),
            'notes':         len(data['data']['notes']),
            'meetings':      len(data['data']['meetings']),
        },
    }


# ══════════════════════════════════════════════════
# CSV EXPORT
# ══════════════════════════════════════════════════
def export_csv() -> Dict:
    """يصدّر conversations + meetings كـ CSV"""
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now()

    # ZIP with multiple CSVs
    zip_name = f'export_csv_{ts.strftime("%Y%m%d_%H%M%S")}.zip'
    zip_path = EXPORT_DIR / zip_name
    counts   = {}

    with zipfile.ZipFile(str(zip_path), 'w', zipfile.ZIP_DEFLATED) as zf:

        # Conversations CSV
        conversations = _load_conversations()
        if conversations:
            buf = io.StringIO()
            w   = csv.DictWriter(buf, fieldnames=['id','role','content','ts'])
            w.writeheader()
            w.writerows(conversations)
            zf.writestr('conversations.csv', buf.getvalue())
            counts['conversations'] = len(conversations)

        # Meetings CSV
        meetings = _load_meetings()
        if meetings:
            buf = io.StringIO()
            fields = ['id','title','attendees','summary','duration_s','created_at']
            w = csv.DictWriter(buf, fieldnames=fields, extrasaction='ignore')
            w.writeheader()
            for m in meetings:
                m['attendees'] = ', '.join(m.get('attendees', []))
            w.writerows(meetings)
            zf.writestr('meetings.csv', buf.getvalue())
            counts['meetings'] = len(meetings)

        # Reminders CSV
        reminders = _load_reminders()
        if reminders:
            buf = io.StringIO()
            w   = csv.DictWriter(buf, fieldnames=['id','label','time','done'])
            w.writeheader()
            w.writerows(reminders)
            zf.writestr('reminders.csv', buf.getvalue())
            counts['reminders'] = len(reminders)

    return {
        'ok':       True,
        'format':   'csv',
        'filename': zip_name,
        'path':     str(zip_path),
        'size_kb':  round(zip_path.stat().st_size / 1024, 1),
        'records':  counts,
    }


# ══════════════════════════════════════════════════
# PDF / HTML REPORT
# ══════════════════════════════════════════════════
def export_report(lang: str = 'ar') -> Dict:
    """
    يصدّر تقرير HTML منسّق (قابل للطباعة كـ PDF)
    يعمل بدون ReportLab — HTML فقط
    """
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts       = datetime.datetime.now()
    filename = f'report_{ts.strftime("%Y%m%d_%H%M%S")}.html'
    path     = EXPORT_DIR / filename

    conversations = _load_conversations()
    meetings      = _load_meetings()
    reminders     = _load_reminders()
    notes         = _load_notes()
    profile       = _load_profile()

    html = _build_html_report(
        ts, conversations, meetings, reminders, notes, profile, lang
    )
    path.write_text(html, encoding='utf-8')

    return {
        'ok':       True,
        'format':   'html',
        'filename': filename,
        'path':     str(path),
        'size_kb':  round(path.stat().st_size / 1024, 1),
        'records': {
            'conversations': len(conversations),
            'meetings':      len(meetings),
            'reminders':     len(reminders),
        },
    }


# ══════════════════════════════════════════════════
# FULL ZIP (all formats)
# ══════════════════════════════════════════════════
def export_all() -> Dict:
    """يصدّر ZIP يحتوي JSON + CSV + HTML"""
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts       = datetime.datetime.now()
    filename = f'full_export_{ts.strftime("%Y%m%d_%H%M%S")}.zip'
    path     = EXPORT_DIR / filename

    j = export_json()
    c = export_csv()
    r = export_report()

    with zipfile.ZipFile(str(path), 'w', zipfile.ZIP_DEFLATED) as zf:
        for src_path, arc_name in [
            (j['path'], 'data.json'),
            (c['path'], 'data_csv.zip'),
            (r['path'], 'report.html'),
        ]:
            p = Path(src_path)
            if p.exists():
                zf.write(str(p), arc_name)

    return {
        'ok':       True,
        'format':   'zip_all',
        'filename': filename,
        'path':     str(path),
        'size_kb':  round(path.stat().st_size / 1024, 1),
        'includes': ['json', 'csv', 'html'],
    }


# ══════════════════════════════════════════════════
# DATA LOADERS
# ══════════════════════════════════════════════════
def _db_rows(db_path: Path, query: str, params=()) -> List[Dict]:
    if not db_path.exists():
        return []
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        rows = conn.execute(query, params).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def _load_conversations() -> List[Dict]:
    return _db_rows(DB_MAIN,
        'SELECT id, role, content, created_at as ts FROM messages ORDER BY created_at DESC LIMIT 500')


def _load_reminders() -> List[Dict]:
    return _db_rows(DB_MAIN,
        'SELECT id, label, time, done FROM reminders ORDER BY time')


def _load_notes() -> List[Dict]:
    return _db_rows(DB_MAIN,
        'SELECT id, title, content, tags, created_at FROM notes ORDER BY created_at DESC LIMIT 200')


def _load_meetings() -> List[Dict]:
    rows = _db_rows(DB_MEETINGS,
        'SELECT id, title, attendees, summary, action_items, duration_s, created_at FROM meetings ORDER BY created_at DESC')
    for r in rows:
        for k in ('attendees', 'action_items'):
            try:
                r[k] = json.loads(r[k] or '[]')
            except Exception:
                r[k] = []
    return rows


def _load_profile() -> Dict:
    p = Path('ambient/data/user_profile.json')
    if p.exists():
        try:
            return json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {}


def _load_images_b64() -> List[Dict]:
    img_dir = Path('creative/output/images')
    if not img_dir.exists():
        return []
    result = []
    for img in list(img_dir.glob('*.png'))[:20]:
        import base64 as b64
        result.append({
            'filename': img.name,
            'data':     b64.b64encode(img.read_bytes()).decode(),
        })
    return result


# ══════════════════════════════════════════════════
# HTML REPORT BUILDER
# ══════════════════════════════════════════════════
def _build_html_report(ts, conversations, meetings, reminders,
                        notes, profile, lang) -> str:
    dir_attr = 'rtl' if lang == 'ar' else 'ltr'
    title    = 'تقرير Personal AI OS' if lang == 'ar' else 'Personal AI OS Report'

    def section(heading, content):
        return f'''
        <div class="section">
            <h2>{heading}</h2>
            {content}
        </div>'''

    # Profile section
    name     = profile.get('name', 'المستخدم')
    top_apps = profile.get('top_apps', [])
    profile_html = f'''
        <p><strong>الاسم:</strong> {name}</p>
        <p><strong>أكثر التطبيقات استخداماً:</strong>
           {', '.join(a.get('name','') for a in top_apps[:5])}</p>
    '''

    # Meetings section
    meetings_rows = ''.join(
        f'<tr><td>{m.get("title","")}</td>'
        f'<td>{", ".join(m.get("attendees",[]))}</td>'
        f'<td>{m.get("duration_s",0)//60}د</td>'
        f'<td>{m.get("summary","")[:100]}</td>'
        f'<td>{m.get("created_at","")[:10]}</td></tr>'
        for m in meetings[:50]
    )
    meetings_html = f'''
        <table>
            <tr><th>العنوان</th><th>الحاضرون</th>
                <th>المدة</th><th>الملخص</th><th>التاريخ</th></tr>
            {meetings_rows or '<tr><td colspan="5">لا توجد اجتماعات</td></tr>'}
        </table>'''

    # Conversations section
    conv_rows = ''.join(
        f'<tr><td class="role-{c.get("role","")}">{c.get("role","")}</td>'
        f'<td>{str(c.get("content",""))[:200]}</td>'
        f'<td>{str(c.get("ts",""))[:16]}</td></tr>'
        for c in conversations[:100]
    )
    conv_html = f'''
        <table>
            <tr><th>الدور</th><th>الرسالة</th><th>التوقيت</th></tr>
            {conv_rows or '<tr><td colspan="3">لا توجد محادثات</td></tr>'}
        </table>'''

    # Reminders section
    rem_rows = ''.join(
        f'<tr><td>{r.get("label","")}</td>'
        f'<td>{r.get("time","")}</td>'
        f'<td>{"✅" if r.get("done") else "⏳"}</td></tr>'
        for r in reminders[:50]
    )
    rem_html = f'''
        <table>
            <tr><th>التذكير</th><th>الوقت</th><th>الحالة</th></tr>
            {rem_rows or '<tr><td colspan="3">لا توجد تذكيرات</td></tr>'}
        </table>'''

    return f'''<!DOCTYPE html>
<html lang="{lang}" dir="{dir_attr}">
<head>
<meta charset="UTF-8">
<title>{title}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
    background: #0a1020;
    color: #e0e0e0;
    direction: {dir_attr};
    padding: 20px;
  }}
  h1 {{ color: #00FF9D; font-size: 24px; margin-bottom: 8px; }}
  h2 {{ color: #00CC7A; font-size: 16px; margin-bottom: 12px; border-bottom: 1px solid #1a3a2a; padding-bottom: 6px; }}
  .header {{ margin-bottom: 30px; }}
  .header .meta {{ color: #888; font-size: 12px; }}
  .stats {{ display: flex; gap: 16px; margin-bottom: 30px; flex-wrap: wrap; }}
  .stat-card {{
    background: #0d1a2a; border: 1px solid #1a3a5a;
    border-radius: 12px; padding: 14px 20px; min-width: 120px;
  }}
  .stat-card .num {{ font-size: 28px; font-weight: bold; color: #00FF9D; }}
  .stat-card .lbl {{ font-size: 12px; color: #888; margin-top: 4px; }}
  .section {{ margin-bottom: 32px; background: #0d1a2a; border-radius: 14px; padding: 20px; border: 1px solid #1a3040; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
  th {{ background: #0a2030; color: #00CC7A; padding: 8px; text-align: right; }}
  td {{ padding: 7px 8px; border-bottom: 1px solid #1a2535; vertical-align: top; max-width: 300px; overflow-wrap: break-word; }}
  .role-user {{ color: #4a9eff; font-weight: bold; }}
  .role-assistant {{ color: #00FF9D; font-weight: bold; }}
  @media print {{ body {{ background: white; color: black; }} .section {{ border: 1px solid #ccc; }} h1,h2 {{ color: #005500; }} }}
</style>
</head>
<body>

<div class="header">
  <h1>🤖 {title}</h1>
  <div class="meta">صُدِّر في {ts.strftime('%Y-%m-%d %H:%M:%S')}</div>
</div>

<div class="stats">
  <div class="stat-card"><div class="num">{len(conversations)}</div><div class="lbl">محادثة</div></div>
  <div class="stat-card"><div class="num">{len(meetings)}</div><div class="lbl">اجتماع</div></div>
  <div class="stat-card"><div class="num">{len(reminders)}</div><div class="lbl">تذكير</div></div>
  <div class="stat-card"><div class="num">{len(notes)}</div><div class="lbl">ملاحظة</div></div>
</div>

{section('👤 الملف الشخصي', profile_html)}
{section('🎙️ الاجتماعات', meetings_html)}
{section('💬 آخر المحادثات', conv_html)}
{section('🔔 التذكيرات', rem_html)}

</body>
</html>'''
