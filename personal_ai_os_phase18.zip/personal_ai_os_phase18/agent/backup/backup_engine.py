# agent/backup/backup_engine.py — Phase 14
# ══════════════════════════════════════════════════
# Backup Engine
#
# يجمع كل بيانات التطبيق في ملف واحد مشفّر (.paib)
# paib = Personal AI Backup
#
# Format:
#   [4 bytes magic] [4 bytes version] [32 bytes salt]
#   [12 bytes nonce] [N bytes AES-GCM encrypted ZIP]
#
# محتوى الـ ZIP:
#   manifest.json    ← metadata + checksums
#   databases/*.db   ← كل الـ SQLite DBs
#   profiles/*.json  ← user profile + settings
#   memories/*.json  ← exported memories
#   images/*.png     ← الصور المولّدة (اختياري)
# ══════════════════════════════════════════════════
import os
import io
import json
import gzip
import shutil
import hashlib
import secrets
import zipfile
import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    _CRYPTO = True
except ImportError:
    _CRYPTO = False

MAGIC   = b'PAIB'
VERSION = b'\x00\x01\x00\x00'   # 1.0.0

# ── Data sources ──────────────────────────────────
DATA_SOURCES = {
    'databases': {
        'personal_ai.db':  'lora/data/personal_ai.db',
        'meetings.db':     'creative/data/meetings.db',
        'queue.db':        'offline/data/queue.db',
        'cache.db':        'offline/data/cache.db',
    },
    'profiles': {
        'user_profile.json': 'ambient/data/user_profile.json',
    },
}

BACKUP_DIR = Path('backup/data')


# ══════════════════════════════════════════════════
def create_backup(
    password: str = '',
    include_images: bool = False,
    label: str = '',
) -> Dict:
    """
    ينشئ backup ويرجّع:
    { ok, path, filename, size_kb, files_count,
      encrypted, ts, checksum }
    """
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts        = datetime.datetime.now()
    ts_str    = ts.strftime('%Y%m%d_%H%M%S')
    label_str = f'_{label}' if label else ''
    filename  = f'backup_{ts_str}{label_str}.paib'
    out_path  = BACKUP_DIR / filename

    # 1. Collect files
    collected, manifest = _collect_files(include_images)
    manifest['created_at']     = ts.isoformat()
    manifest['label']          = label
    manifest['include_images'] = include_images
    manifest['version']        = '1.0'

    # 2. Build in-memory ZIP
    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('manifest.json',
                    json.dumps(manifest, ensure_ascii=False, indent=2))
        for arc_name, data in collected:
            zf.writestr(arc_name, data)

    zip_bytes = zip_buf.getvalue()

    # 3. Encrypt (or plain if no password)
    encrypted = bool(password and _CRYPTO)
    if encrypted:
        file_bytes = _encrypt(zip_bytes, password)
    else:
        # still wrap with magic + version for format consistency
        file_bytes = MAGIC + VERSION + b'\x00' * 44 + zip_bytes

    # 4. Write file
    out_path.write_bytes(file_bytes)

    checksum = hashlib.sha256(file_bytes).hexdigest()[:16]
    size_kb  = round(len(file_bytes) / 1024, 1)

    return {
        'ok':          True,
        'path':        str(out_path),
        'filename':    filename,
        'size_kb':     size_kb,
        'files_count': len(collected),
        'encrypted':   encrypted,
        'ts':          ts.isoformat(),
        'checksum':    checksum,
        'manifest':    manifest,
    }


def list_backups() -> List[Dict]:
    """يرجّع كل الـ backups مرتّبة من الأحدث للأقدم"""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    result = []
    for p in sorted(BACKUP_DIR.glob('*.paib'),
                    key=lambda x: x.stat().st_mtime, reverse=True):
        stat = p.stat()
        result.append({
            'filename':   p.name,
            'path':       str(p),
            'size_kb':    round(stat.st_size / 1024, 1),
            'ts':         datetime.datetime.fromtimestamp(
                              stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
            'encrypted':  _is_encrypted(p),
        })
    return result


def delete_backup(filename: str) -> bool:
    path = BACKUP_DIR / filename
    if path.exists() and path.suffix == '.paib':
        path.unlink()
        return True
    return False


def get_stats() -> Dict:
    backups = list_backups()
    total_kb = sum(b['size_kb'] for b in backups)
    return {
        'count':       len(backups),
        'total_size_kb': round(total_kb, 1),
        'latest':      backups[0]['ts'] if backups else None,
        'oldest':      backups[-1]['ts'] if backups else None,
    }


# ══════════════════════════════════════════════════
# INTERNAL
# ══════════════════════════════════════════════════
def _collect_files(include_images: bool) -> Tuple[List, Dict]:
    """يجمع الملفات ويبني الـ manifest"""
    collected = []
    manifest  = {'files': {}}

    for category, files in DATA_SOURCES.items():
        for arc_name, rel_path in files.items():
            p = Path(rel_path)
            if p.exists():
                data = p.read_bytes()
                arc  = f'{category}/{arc_name}'
                collected.append((arc, data))
                manifest['files'][arc] = {
                    'size':     len(data),
                    'sha256':   hashlib.sha256(data).hexdigest()[:16],
                    'source':   rel_path,
                }

    # Images (optional)
    if include_images:
        img_dir = Path('creative/output/images')
        if img_dir.exists():
            for img in list(img_dir.glob('*.png'))[:50]:
                data = img.read_bytes()
                arc  = f'images/{img.name}'
                collected.append((arc, data))
                manifest['files'][arc] = {
                    'size':   len(data),
                    'sha256': hashlib.sha256(data).hexdigest()[:16],
                }

    return collected, manifest


def _encrypt(data: bytes, password: str) -> bytes:
    """AES-256-GCM encryption with PBKDF2 key derivation"""
    salt  = secrets.token_bytes(32)
    nonce = secrets.token_bytes(12)

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100_000,
    )
    key        = kdf.derive(password.encode('utf-8'))
    aesgcm     = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, data, None)

    return MAGIC + VERSION + salt + nonce + ciphertext


def _decrypt(data: bytes, password: str) -> bytes:
    """Decrypt AES-256-GCM"""
    if data[:4] != MAGIC:
        raise ValueError('Invalid backup file format')
    salt  = data[8:40]
    nonce = data[40:52]
    ct    = data[52:]

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100_000,
    )
    key    = kdf.derive(password.encode('utf-8'))
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ct, None)


def _is_encrypted(path: Path) -> bool:
    try:
        header = path.read_bytes()[:52]
        return header[:4] == MAGIC and header[8:12] != b'\x00\x00\x00\x00'
    except Exception:
        return False


# expose for restore_engine
decrypt_backup  = _decrypt
get_zip_plain   = lambda data: data[52:]   # unencrypted format
