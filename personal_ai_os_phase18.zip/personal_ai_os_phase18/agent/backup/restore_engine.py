# agent/backup/restore_engine.py — Phase 14
# ══════════════════════════════════════════════════
# Restore Engine
# يفك ضغط الـ backup ويتحقق من الـ integrity
# ثم يستعيد الملفات في أماكنها الصح
# ══════════════════════════════════════════════════
import io
import json
import shutil
import hashlib
import zipfile
import datetime
from pathlib import Path
from typing import Dict, List

from . import backup_engine as be

# Mapping: arc path → restore destination
RESTORE_MAP = {
    'databases/personal_ai.db': 'lora/data/personal_ai.db',
    'databases/meetings.db':    'creative/data/meetings.db',
    'databases/queue.db':       'offline/data/queue.db',
    'databases/cache.db':       'offline/data/cache.db',
    'profiles/user_profile.json': 'ambient/data/user_profile.json',
}


# ══════════════════════════════════════════════════
def validate(filename: str, password: str = '') -> Dict:
    """
    يتحقق من صحة الـ backup بدون استعادة
    يرجّع: { ok, encrypted, files, manifest, errors }
    """
    path = be.BACKUP_DIR / filename
    if not path.exists():
        return {'ok': False, 'errors': ['File not found']}

    raw = path.read_bytes()
    errors = []

    # 1. Magic check
    if raw[:4] != be.MAGIC:
        errors.append('Invalid file format (bad magic)')
        return {'ok': False, 'errors': errors}

    # 2. Decrypt if needed
    encrypted = be._is_encrypted(path)
    try:
        if encrypted:
            if not password:
                return {'ok': False, 'encrypted': True,
                        'errors': ['Password required']}
            zip_bytes = be._decrypt(raw, password)
        else:
            zip_bytes = be.get_zip_plain(raw)
    except Exception as e:
        return {'ok': False, 'errors': [f'Decryption failed: {e}']}

    # 3. Open ZIP
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except Exception as e:
        return {'ok': False, 'errors': [f'ZIP corrupt: {e}']}

    # 4. Read manifest
    try:
        manifest = json.loads(zf.read('manifest.json'))
    except Exception:
        return {'ok': False, 'errors': ['manifest.json missing or corrupt']}

    # 5. Verify checksums
    files_info = manifest.get('files', {})
    for arc_name, info in files_info.items():
        try:
            data     = zf.read(arc_name)
            checksum = hashlib.sha256(data).hexdigest()[:16]
            if checksum != info.get('sha256', checksum):
                errors.append(f'Checksum mismatch: {arc_name}')
        except KeyError:
            errors.append(f'Missing file in archive: {arc_name}')

    return {
        'ok':        len(errors) == 0,
        'encrypted': encrypted,
        'files':     list(files_info.keys()),
        'manifest':  manifest,
        'errors':    errors,
    }


def restore(
    filename: str,
    password: str = '',
    dry_run:  bool = False,
) -> Dict:
    """
    يستعيد backup كامل
    dry_run=True → يتحقق بس بدون كتابة
    """
    # Validate first
    val = validate(filename, password)
    if not val['ok']:
        return {'ok': False, 'errors': val.get('errors', [])}

    path      = be.BACKUP_DIR / filename
    raw       = path.read_bytes()
    encrypted = val['encrypted']

    try:
        if encrypted:
            zip_bytes = be._decrypt(raw, password)
        else:
            zip_bytes = be.get_zip_plain(raw)
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except Exception as e:
        return {'ok': False, 'errors': [str(e)]}

    restored = []
    skipped  = []
    errors   = []

    for arc_name in zf.namelist():
        if arc_name == 'manifest.json':
            continue

        dest = RESTORE_MAP.get(arc_name)
        if not dest:
            skipped.append(arc_name)
            continue

        dest_path = Path(dest)

        if dry_run:
            restored.append({'file': arc_name, 'dest': dest, 'dry_run': True})
            continue

        try:
            # Backup existing file first
            if dest_path.exists():
                bak = dest_path.with_suffix(dest_path.suffix + '.bak')
                shutil.copy2(str(dest_path), str(bak))

            # Write restored file
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(zf.read(arc_name))
            restored.append({'file': arc_name, 'dest': dest})
        except Exception as e:
            errors.append(f'{arc_name}: {e}')

    return {
        'ok':       len(errors) == 0,
        'restored': restored,
        'skipped':  skipped,
        'errors':   errors,
        'dry_run':  dry_run,
        'ts':       datetime.datetime.now().isoformat(),
    }
