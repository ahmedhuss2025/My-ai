# agent/creative/proactive_engine.py — Phase 12
# ══════════════════════════════════════════════════
# Proactive AI — يقترح بمبادرته بناءً على:
#   - الوقت + عادات المستخدم (من ambient)
#   - reminders القادمة
#   - أنماط الاستخدام
# ══════════════════════════════════════════════════
import datetime
import sqlite3
import json
from pathlib import Path
from typing import List, Dict, Optional


# ── Suggestion types ──────────────────────────────
class Suggestion:
    def __init__(self, type_: str, title: str, body: str,
                 action: str = "", priority: int = 2):
        self.type     = type_    # "reminder" | "habit" | "summary" | "tip"
        self.title    = title
        self.body     = body
        self.action   = action   # deeplink / command
        self.priority = priority # 1=high, 2=normal, 3=low
        self.ts       = datetime.datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "type":     self.type,
            "title":    self.title,
            "body":     self.body,
            "action":   self.action,
            "priority": self.priority,
            "ts":       self.ts,
        }


# ══════════════════════════════════════════════════
class ProactiveEngine:

    def __init__(self, db_path: str = "lora/data/personal_ai.db"):
        self._db = db_path
        self._profile_path = Path("ambient/data/user_profile.json")

    # ── Main entry ────────────────────────────────
    def get_suggestions(self, limit: int = 5) -> List[Dict]:
        now  = datetime.datetime.now()
        hour = now.hour
        sug: List[Suggestion] = []

        profile = self._load_profile()
        sug += self._time_based(hour, profile)
        sug += self._reminder_based(now)
        sug += self._habit_based(now, profile)
        sug += self._meeting_based(now)

        # Sort by priority then deduplicate
        sug.sort(key=lambda s: s.priority)
        seen = set()
        unique = []
        for s in sug:
            k = s.type + s.title[:20]
            if k not in seen:
                seen.add(k)
                unique.append(s)

        return [s.to_dict() for s in unique[:limit]]

    # ── Time-based suggestions ────────────────────
    def _time_based(self, hour: int, profile: dict) -> List[Suggestion]:
        out = []
        wake = profile.get("sleep", {}).get("usual_wake_hour", 7)
        sleep = profile.get("sleep", {}).get("usual_sleep_hour", 23)

        # صباح
        if wake <= hour <= wake + 1:
            out.append(Suggestion(
                "habit", "🌅 صباح الخير!",
                "إيه أهم حاجة تعملها النهارده؟",
                action="open_chat", priority=1,
            ))

        # قبل النوم
        if sleep - 1 <= hour <= sleep:
            out.append(Suggestion(
                "summary", "🌙 ملخص يومك",
                "عايز أعمل تقرير سريع لإنجازاتك النهارده؟",
                action="daily_summary", priority=1,
            ))

        # منتصف النهار
        if 12 <= hour <= 13:
            out.append(Suggestion(
                "tip", "☕ استراحة الغداء",
                "تقدر تسجّل ملاحظة أو اجتماع دلوقتي",
                action="open_meeting", priority=3,
            ))

        return out

    # ── Reminder-based ────────────────────────────
    def _reminder_based(self, now: datetime.datetime) -> List[Suggestion]:
        out = []
        try:
            conn = sqlite3.connect(self._db)
            conn.row_factory = sqlite3.Row
            upcoming = conn.execute("""
                SELECT label, time FROM reminders
                WHERE done = 0
                ORDER BY time ASC
                LIMIT 3
            """).fetchall()
            conn.close()

            for r in upcoming:
                label = r["label"] or "تذكير"
                out.append(Suggestion(
                    "reminder", f"🔔 {label}",
                    f"عندك تذكير: {label} في {r['time']}",
                    action=f"reminder:{r['time']}", priority=1,
                ))
        except Exception:
            pass
        return out

    # ── Habit-based ───────────────────────────────
    def _habit_based(self, now: datetime.datetime,
                     profile: dict) -> List[Suggestion]:
        out = []
        top_apps = profile.get("top_apps", [])
        topics   = profile.get("conversation", {}).get("favorite_topics", [])
        peak     = profile.get("peak_hours", {}).get("most_active", [])
        hour     = now.hour

        # لو دلوقتي وقت ذروة النشاط
        if hour in [int(h.split(":")[0]) for h in peak if ":" in str(h)][:3]:
            out.append(Suggestion(
                "habit", "⚡ وقت ذروتك!",
                "دي أكتر ساعاتك إنتاجية — عايز تبدأ بإيه؟",
                action="open_chat", priority=2,
            ))

        # اقتراح بناءً على التوبيكات
        if "بحث" in topics:
            out.append(Suggestion(
                "tip", "🔍 بحث سريع",
                "عايز تبحث عن حاجة؟ اكتب سؤالك",
                action="open_chat?intent=search", priority=3,
            ))

        return out

    # ── Meeting-based ─────────────────────────────
    def _meeting_based(self, now: datetime.datetime) -> List[Suggestion]:
        out = []
        meetings_db = Path("creative/data/meetings.db")
        if not meetings_db.exists():
            return out
        try:
            conn = sqlite3.connect(str(meetings_db))
            conn.row_factory = sqlite3.Row
            recent = conn.execute("""
                SELECT title, created_at FROM meetings
                WHERE summary IS NULL OR summary = ''
                ORDER BY created_at DESC
                LIMIT 1
            """).fetchone()
            conn.close()
            if recent:
                out.append(Suggestion(
                    "summary", "📝 اجتماع غير ملخّص",
                    f"عندك اجتماع '{recent['title']}' لسه مش ملخّص — عايز ألخّصه؟",
                    action=f"summarize_meeting", priority=2,
                ))
        except Exception:
            pass
        return out

    # ── Helpers ───────────────────────────────────
    def _load_profile(self) -> dict:
        try:
            if self._profile_path.exists():
                return json.loads(self._profile_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        return {}


# ── Singleton ─────────────────────────────────────
_engine = ProactiveEngine()


def get_suggestions(limit: int = 5) -> List[Dict]:
    return _engine.get_suggestions(limit)
