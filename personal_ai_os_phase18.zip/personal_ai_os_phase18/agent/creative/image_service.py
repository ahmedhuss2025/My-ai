# agent/creative/image_service.py — Phase 12
# ══════════════════════════════════════════════════
# توليد وتعديل الصور
#
# Backends (بالترتيب):
#   1. DALL-E 3  (لو عنده OPENAI_API_KEY)
#   2. Stable Diffusion API  (لو عنده SD_API_URL)
#   3. Placeholder stub      (sandbox / offline)
#
# التعديلات المدعومة (PIL محلي):
#   resize, crop, rotate, brightness,
#   contrast, grayscale, blur, caption
# ══════════════════════════════════════════════════
import os
import base64
import json
import uuid
import io
import datetime
from pathlib import Path
from typing import Optional, Dict, Tuple

OUTPUT_DIR = Path("creative/output/images")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── Provider detection ────────────────────────────
_OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")
_SD_URL     = os.getenv("SD_API_URL", "")     # e.g. http://localhost:7860
_HAS_PIL    = False

try:
    from PIL import Image, ImageFilter, ImageEnhance, ImageDraw, ImageFont
    _HAS_PIL = True
except ImportError:
    pass


# ══════════════════════════════════════════════════
# GENERATE
# ══════════════════════════════════════════════════
def generate(
    prompt:    str,
    style:     str  = "realistic",   # realistic|cartoon|sketch|watercolor
    size:      str  = "1024x1024",
    negative:  str  = "",
) -> Dict:
    """
    يولّد صورة من نص — يرجّع:
    { ok, image_id, path, base64, provider, prompt, ts }
    """
    image_id = str(uuid.uuid4())[:10]
    ts       = _now()

    # ── 1. DALL-E 3 ───────────────────────────────
    if _OPENAI_KEY:
        result = _dalle_generate(prompt, size, image_id, ts)
        if result:
            return result

    # ── 2. Stable Diffusion ───────────────────────
    if _SD_URL:
        result = _sd_generate(prompt, negative, size, image_id, ts)
        if result:
            return result

    # ── 3. PIL placeholder (sandbox/offline) ──────
    return _placeholder_generate(prompt, style, size, image_id, ts)


def _dalle_generate(prompt, size, image_id, ts) -> Optional[Dict]:
    try:
        import urllib.request, json as _json
        payload = json.dumps({
            "model":   "dall-e-3",
            "prompt":  prompt,
            "n":       1,
            "size":    size,
            "quality": "standard",
        }).encode()
        req = urllib.request.Request(
            "https://api.openai.com/v1/images/generations",
            data=payload,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {_OPENAI_KEY}",
            },
            method="POST",
        )
        resp = urllib.request.urlopen(req, timeout=30)
        data = _json.loads(resp.read())
        url  = data["data"][0]["url"]

        # Download image
        img_resp = urllib.request.urlopen(url, timeout=15)
        img_bytes = img_resp.read()
        path = OUTPUT_DIR / f"{image_id}.png"
        path.write_bytes(img_bytes)

        return _build_result(image_id, path, img_bytes, "dall-e-3", prompt, ts)
    except Exception as e:
        print(f"DALL-E failed: {e}")
        return None


def _sd_generate(prompt, negative, size, image_id, ts) -> Optional[Dict]:
    """Stable Diffusion AUTOMATIC1111 API"""
    try:
        import urllib.request, json as _json
        w, h = map(int, size.split("x"))
        payload = json.dumps({
            "prompt":          prompt,
            "negative_prompt": negative,
            "width":           min(w, 768),
            "height":          min(h, 768),
            "steps":           20,
            "cfg_scale":       7,
        }).encode()
        req = urllib.request.Request(
            f"{_SD_URL}/sdapi/v1/txt2img",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        resp = urllib.request.urlopen(req, timeout=60)
        data = _json.loads(resp.read())
        img_b64 = data["images"][0]
        img_bytes = base64.b64decode(img_b64)

        path = OUTPUT_DIR / f"{image_id}.png"
        path.write_bytes(img_bytes)
        return _build_result(image_id, path, img_bytes, "stable-diffusion", prompt, ts)
    except Exception as e:
        print(f"SD failed: {e}")
        return None


def _placeholder_generate(prompt, style, size, image_id, ts) -> Dict:
    """يولّد صورة placeholder بـ PIL لو مفيش API"""
    w_str, h_str = size.split("x") if "x" in size else ("512", "512")
    w, h = int(w_str), int(h_str)

    # Colors per style
    bg_colors = {
        "realistic":   (30,  30,  50),
        "cartoon":     (255, 200, 50),
        "sketch":      (240, 240, 240),
        "watercolor":  (180, 220, 255),
    }
    bg = bg_colors.get(style, (30, 30, 50))
    path = OUTPUT_DIR / f"{image_id}.png"

    if _HAS_PIL:
        img  = Image.new("RGB", (w, h), color=bg)
        draw = ImageDraw.Draw(img)
        # Draw simple geometric shapes as placeholder art
        cx, cy = w // 2, h // 2
        draw.ellipse([cx-80, cy-80, cx+80, cy+80],
                     outline=(255, 255, 255, 180), width=3)
        draw.rectangle([cx-40, cy-40, cx+40, cy+40],
                       outline=(200, 200, 255, 180), width=2)
        # Prompt text
        draw.text((20, 20), f"🎨 {prompt[:60]}", fill=(255, 255, 255))
        draw.text((20, h-40), f"Style: {style} | {ts[:10]}", fill=(180, 180, 180))
        img.save(str(path), "PNG")
        with open(path, "rb") as f:
            img_bytes = f.read()
    else:
        # Minimal 1×1 white PNG
        img_bytes = (
            b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01'
            b'\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00'
            b'\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18'
            b'\xd8N\x00\x00\x00\x00IEND\xaeB`\x82'
        )
        path.write_bytes(img_bytes)

    return _build_result(image_id, path, img_bytes, "placeholder", prompt, ts)


# ══════════════════════════════════════════════════
# EDIT
# ══════════════════════════════════════════════════
def edit(
    image_path: str,
    operation:  str,
    params:     dict = None,
) -> Dict:
    """
    يعدّل صورة موجودة
    operations: resize|crop|rotate|brightness|contrast|grayscale|blur|caption
    """
    params = params or {}
    if not _HAS_PIL:
        return {"ok": False, "error": "PIL not installed — pip install Pillow"}

    src = Path(image_path)
    if not src.exists():
        # Try under OUTPUT_DIR
        src = OUTPUT_DIR / src.name
    if not src.exists():
        return {"ok": False, "error": f"image not found: {image_path}"}

    try:
        img = Image.open(str(src)).convert("RGB")
        op  = operation.lower()

        if op == "resize":
            w = int(params.get("width",  512))
            h = int(params.get("height", 512))
            img = img.resize((w, h), Image.LANCZOS)

        elif op == "crop":
            left   = int(params.get("left",   0))
            top    = int(params.get("top",    0))
            right  = int(params.get("right",  img.width))
            bottom = int(params.get("bottom", img.height))
            img = img.crop((left, top, right, bottom))

        elif op == "rotate":
            angle = float(params.get("angle", 90))
            img   = img.rotate(angle, expand=True)

        elif op == "brightness":
            factor = float(params.get("factor", 1.2))
            img    = ImageEnhance.Brightness(img).enhance(factor)

        elif op == "contrast":
            factor = float(params.get("factor", 1.5))
            img    = ImageEnhance.Contrast(img).enhance(factor)

        elif op == "grayscale":
            img = img.convert("L").convert("RGB")

        elif op == "blur":
            radius = float(params.get("radius", 2.0))
            img    = img.filter(ImageFilter.GaussianBlur(radius))

        elif op == "caption":
            text   = params.get("text", "")
            draw   = ImageDraw.Draw(img)
            x = int(params.get("x", 10))
            y = int(params.get("y", img.height - 40))
            draw.rectangle([x - 4, y - 4, x + len(text)*9, y + 24],
                           fill=(0, 0, 0, 180))
            draw.text((x, y), text, fill=(255, 255, 255))

        else:
            return {"ok": False, "error": f"unknown operation: {op}"}

        # Save edited
        new_id   = str(uuid.uuid4())[:10]
        new_path = OUTPUT_DIR / f"{new_id}_edited.png"
        img.save(str(new_path), "PNG")

        buf = io.BytesIO()
        img.save(buf, "PNG")
        img_bytes = buf.getvalue()

        return _build_result(new_id, new_path, img_bytes,
                             "edit", f"{op} on {src.name}", _now())

    except Exception as e:
        return {"ok": False, "error": str(e)}


# ══════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════
def _build_result(image_id, path, img_bytes, provider, prompt, ts) -> Dict:
    b64 = base64.b64encode(img_bytes).decode()
    return {
        "ok":        True,
        "image_id":  image_id,
        "path":      str(path),
        "filename":  path.name,
        "base64":    b64,
        "size_kb":   round(len(img_bytes) / 1024, 1),
        "provider":  provider,
        "prompt":    prompt,
        "ts":        ts,
    }


def list_images(limit: int = 20) -> list:
    files = sorted(OUTPUT_DIR.glob("*.png"), key=lambda p: p.stat().st_mtime,
                   reverse=True)
    return [
        {"filename": p.name, "size_kb": round(p.stat().st_size / 1024, 1),
         "ts": datetime.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")}
        for p in files[:limit]
    ]


def get_image_b64(filename: str) -> Optional[str]:
    path = OUTPUT_DIR / filename
    if path.exists():
        return base64.b64encode(path.read_bytes()).decode()
    return None


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
