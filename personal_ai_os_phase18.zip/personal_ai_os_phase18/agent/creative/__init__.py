# agent/creative/__init__.py — Phase 12
from . import nlp_engine          # NEW: TF-IDF + TextRank + Regex
from . import proactive_engine
from . import image_service
from . import meeting_recorder
from . import meeting_summarizer   # UPGRADED: NLP-first pipeline
