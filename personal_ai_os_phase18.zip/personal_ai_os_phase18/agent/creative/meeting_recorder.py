# agent/creative/meeting_recorder.py — Phase 12
# ══════════════════════════════════════════════════
# تسجيل الاجتماعات وحفظ النصوص
# الـ recording نفسه بيحصل في Flutter (mic)
# هنا بنستقبل الـ transcript ونحفظه + نلخّصه
# ══════════════════════════════════════════════════
import sqlite3
import json
import uuid
import datetime
from pathlib import Path
from typing import List, Dict, Optional

MEETINGS_DB = Path("creative/data/meetings.db")


# ══════════════════════════════════════════════════
def _conn() -> sqlite3.Connection:
    MEETINGS_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(MEETINGS_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _conn() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS meetings (
                id          TEXT PRIMARY KEY,
                title       TEXT NOT NULL,
                attendees   TEXT DEFAULT '[]',
                language    TEXT DEFAULT 'ar',
                transcript  TEXT DEFAULT '',
                summary     TEXT DEFAULT '',
                action_items TEXT DEFAULT '[]',
                keywords    TEXT DEFAULT '[]',
                duration_s  INTEGER DEFAULT 0,
                audio_path  TEXT DEFAULT '',
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_meetings_date
            ON meetings(created_at DESC)
        """)


init_db()


# ══════════════════════════════════════════════════
# CRUD
# ══════════════════════════════════════════════════
def create_meeting(
    title:      str,
    attendees:  List[str] = None,
    language:   str = "ar",
) -> str:
    """يبدأ اجتماع جديد — يرجّع الـ id"""
    m_id = str(uuid.uuid4())[:12]
    now  = _now()
    with _conn() as db:
        db.execute(
            """INSERT INTO meetings
               (id, title, attendees, language, created_at, updated_at)
               VALUES (?,?,?,?,?,?)""",
            (m_id, title,
             json.dumps(attendees or [], ensure_ascii=False),
             language, now, now)
        )
    return m_id


def save_transcript(meeting_id: str, transcript: str,
                    duration_s: int = 0) -> bool:
    """يحفظ الـ transcript من Flutter STT"""
    try:
        with _conn() as db:
            db.execute(
                """UPDATE meetings SET
                   transcript=?, duration_s=?, updated_at=?
                   WHERE id=?""",
                (transcript, duration_s, _now(), meeting_id)
            )
        return True
    except Exception:
        return False


def save_summary(meeting_id: str, summary: str,
                 action_items: List[str] = None,
                 keywords: List[str] = None) -> bool:
    """يحفظ الـ summary + action items بعد التلخيص"""
    try:
        with _conn() as db:
            db.execute(
                """UPDATE meetings SET
                   summary=?, action_items=?, keywords=?, updated_at=?
                   WHERE id=?""",
                (summary,
                 json.dumps(action_items or [], ensure_ascii=False),
                 json.dumps(keywords     or [], ensure_ascii=False),
                 _now(), meeting_id)
            )
        return True
    except Exception:
        return False


def get_meeting(meeting_id: str) -> Optional[Dict]:
    with _conn() as db:
        row = db.execute(
            "SELECT * FROM meetings WHERE id=?", (meeting_id,)
        ).fetchone()
    if not row:
        return None
    return _row_to_dict(row)


def list_meetings(limit: int = 20) -> List[Dict]:
    with _conn() as db:
        rows = db.execute(
            """SELECT * FROM meetings
               ORDER BY created_at DESC LIMIT ?""",
            (limit,)
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


def delete_meeting(meeting_id: str) -> bool:
    try:
        with _conn() as db:
            db.execute("DELETE FROM meetings WHERE id=?", (meeting_id,))
        return True
    except Exception:
        return False


def get_stats() -> Dict:
    with _conn() as db:
        row = db.execute("""
            SELECT
                COUNT(*)                                           AS total,
                SUM(CASE WHEN summary != '' THEN 1 ELSE 0 END)    AS summarized,
                SUM(duration_s)                                    AS total_duration_s,
                AVG(duration_s)                                    AS avg_duration_s
            FROM meetings
        """).fetchone()
    d = dict(row) if row else {}
    d["total_duration_min"] = round((d.get("total_duration_s") or 0) / 60, 1)
    d["avg_duration_min"]   = round((d.get("avg_duration_s")   or 0) / 60, 1)
    return d


# ══════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════
def _row_to_dict(row: sqlite3.Row) -> Dict:
    d = dict(row)
    for key in ("attendees", "action_items", "keywords"):
        try:
            d[key] = json.loads(d.get(key) or "[]")
        except Exception:
            d[key] = []
    return d


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
