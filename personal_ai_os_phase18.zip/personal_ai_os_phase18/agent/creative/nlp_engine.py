# agent/creative/nlp_engine.py — Phase 12 Upgrade
# ══════════════════════════════════════════════════
# NLP محلي 100% بدون LLM — أسرع وأخف
#
# Algorithms:
#   keywords   → TF-IDF (sklearn) + Arabic stop words
#   summary    → TextRank (graph-based extractive)
#   actions    → Regex pattern matching + Arabic verb detection
#   sentiment  → Lexicon-based (Arabic sentiment words)
#   language   → Character frequency detection
#
# لا يحتاج: YAKE / spaCy / NLTK / internet
# يحتاج فقط: sklearn + numpy (موجودين)
# ══════════════════════════════════════════════════
import re
import math
import heapq
from collections import Counter, defaultdict
from typing import List, Dict, Tuple, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ══════════════════════════════════════════════════
# Arabic Stop Words (شاملة)
# ══════════════════════════════════════════════════
_AR_STOPWORDS = {
    # نزيل التشكيل عشان sklearn tokenizer يتعامل معاهم صح
    "في","من","على","الى","عن","مع","هذا","هذه","هذان","هؤلاء",
    "التي","الذي","الذين","اللاتي","اللواتي","ما","ان","لا","لم",
    "لن","قد","كان","يكون","كانت","تكون","هو","هي","هم","هن",
    "انا","نحن","انت","انتم","انتن","ان","او","ام","لكن","بل",
    "حتى","منذ","خلال","بعد","قبل","بين","فوق","تحت","امام","خلف",
    "كل","بعض","اي","اية","ذلك","تلك","هناك","هنا","حيث","كيف",
    "متى","اين","لماذا","لان","لكي","كي","اذا","لو","عندما",
    "حين","بينما","رغم","وفق","وفقا","ايضا","جدا","فقط","حتى",
    "اكثر","اقل","جميع","مختلف","ذات","ذو","اثناء","وراء","اسفل",
    "يجب","يمكن","ينبغي","لابد","سوف","سيتم","قام","تم","يتم",
    "به","بها","بهم","له","لها","لهم","منه","منها","منهم","عليه",
    "عليها","عليهم","اليه","اليها","فيه","فيها","فيهم",
    # English
    "the","a","an","in","on","at","of","to","and","or","but",
    "is","are","was","were","be","been","have","has","had",
    "will","would","could","should","may","might","shall",
    "this","that","these","those","i","we","you","he","she","they",
    "it","my","our","your","his","her","their","its",
    "for","with","from","by","about","as","into","through",
    "during","before","after","above","below","between",
}

# Action verb patterns (Arabic)
_ACTION_PATTERNS_AR = [
    r"(?:سيقوم|سوف يقوم|هيعمل|هنعمل|سنقوم)\s+(?:\w+\s+){0,3}(?:ب|بـ)?(.{10,80})",
    r"(?:يجب|لازم|ضروري|مهم)\s+(?:أن\s+)?(.{10,80})",
    r"(?:قرر|اتفقنا|تم الاتفاق)\s+(?:على\s+)?(.{10,80})",
    r"(?:المطلوب|المهمة|المهام)\s*[:\-]\s*(.{10,80})",
    r"(?:action|todo|task|مهمة|نشاط)\s*[:\-#]\s*(.{10,80})",
    r"(?:بكرة|الأسبوع الجاي|قبل نهاية|في أقرب وقت)\s+(.{10,60})",
    r"(?:سيتولى|ستتولى|مسؤول عن|مسؤولة عن)\s+(.{10,80})",
    r"\[\s*(?:TODO|Action|مهمة)\s*\]\s*(.{10,80})",
]

# Sentiment lexicons
_POSITIVE_WORDS = {
    "ممتاز","رائع","جيد","أحسن","نجح","نجاح","تقدم","إيجابي","مبهر",
    "فعّال","قوي","محترف","ناجح","مثالي","مميز","excellent","great",
    "good","success","positive","amazing","wonderful","fantastic",
    "accomplished","achieved","improved","growth","profit","gain",
}
_NEGATIVE_WORDS = {
    "سيء","فشل","مشكلة","خطأ","صعب","تأخر","خسارة","سلبي","ضعيف",
    "رديء","إخفاق","عائق","عقبة","مخيب","bad","fail","problem",
    "error","issue","difficult","delay","loss","negative","weak",
    "poor","failure","obstacle","challenge","concern","risk",
}


# ══════════════════════════════════════════════════
# KEYWORDS — TF-IDF
# ══════════════════════════════════════════════════
def extract_keywords(text: str, top_n: int = 8) -> List[str]:
    """
    TF-IDF على مستوى الكلمات مع Arabic stop words
    يتعامل مع النصوص القصيرة بـ frequency fallback
    """
    # Clean text
    clean = re.sub(r"[^\u0600-\u06FFa-zA-Z\s]", " ", text)
    tokens = clean.split()
    tokens = [t for t in tokens if len(t) > 3 and t.lower() not in _AR_STOPWORDS]

    if len(tokens) < 5:
        # Very short text — just return unique words
        freq = Counter(tokens)
        return [w for w, _ in freq.most_common(top_n)]

    # For longer text — use TF-IDF on sentences
    sentences = _split_sentences(text)
    if len(sentences) < 2:
        # Single sentence — use frequency
        freq = Counter(tokens)
        return [w for w, _ in freq.most_common(top_n)]

    try:
        vectorizer = TfidfVectorizer(
            stop_words=list(_AR_STOPWORDS),
            max_features=200,
            ngram_range=(1, 2),   # unigrams + bigrams
            min_df=1,
        )
        tfidf = vectorizer.fit_transform(sentences)
        feature_names = vectorizer.get_feature_names_out()
        # Mean TF-IDF score across sentences
        scores = np.asarray(tfidf.mean(axis=0)).flatten()
        top_indices = scores.argsort()[::-1][:top_n * 2]
        keywords = []
        for idx in top_indices:
            word = feature_names[idx]
            if len(word) > 3 and word not in _AR_STOPWORDS:
                keywords.append(word)
            if len(keywords) >= top_n:
                break
        return keywords if keywords else _freq_keywords(tokens, top_n)
    except Exception:
        return _freq_keywords(tokens, top_n)


def _freq_keywords(tokens: List[str], top_n: int) -> List[str]:
    freq = Counter(t.lower() for t in tokens if t not in _AR_STOPWORDS)
    return [w for w, _ in freq.most_common(top_n)]


# ══════════════════════════════════════════════════
# SUMMARY — TextRank (Graph-based Extractive)
# ══════════════════════════════════════════════════
def extractive_summary(text: str, num_sentences: int = 3) -> str:
    """
    TextRank: يبني graph من الجمل ويرتّبها بالـ cosine similarity
    أفضل من "أول 3 جمل" — يختار أكثر الجمل أهمية فعلاً
    """
    sentences = _split_sentences(text)
    if len(sentences) <= num_sentences:
        return " ".join(sentences)

    try:
        # Build TF-IDF matrix
        vectorizer = TfidfVectorizer(
            stop_words=list(_AR_STOPWORDS),
            min_df=1,
        )
        tfidf_matrix = vectorizer.fit_transform(sentences)

        # Similarity matrix
        sim_matrix = cosine_similarity(tfidf_matrix)
        np.fill_diagonal(sim_matrix, 0)

        # TextRank power iteration
        scores = _power_iteration(sim_matrix, damping=0.85, max_iter=100)

        # Get top sentences in original order
        top_indices = sorted(
            heapq.nlargest(num_sentences, range(len(scores)), key=lambda i: scores[i])
        )
        return " ".join(sentences[i] for i in top_indices)

    except Exception:
        # Fallback: first N sentences
        return " ".join(sentences[:num_sentences])


def _power_iteration(
    matrix: np.ndarray, damping: float = 0.85, max_iter: int = 100
) -> np.ndarray:
    """PageRank / TextRank power iteration"""
    n = matrix.shape[0]
    # Normalize rows
    row_sums = matrix.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    matrix = matrix / row_sums

    scores = np.ones(n) / n
    for _ in range(max_iter):
        new_scores = (1 - damping) / n + damping * matrix.T @ scores
        if np.allclose(scores, new_scores, atol=1e-6):
            break
        scores = new_scores
    return scores


# ══════════════════════════════════════════════════
# ACTION ITEMS — Regex + verb detection
# ══════════════════════════════════════════════════
def extract_action_items(text: str) -> List[str]:
    """
    يستخرج action items بـ:
    1. Regex على Arabic action verbs
    2. Pattern matching للـ future tense
    3. Bullet points / numbered lists
    """
    items = []
    seen  = set()

    # 1. Regex patterns
    for pattern in _ACTION_PATTERNS_AR:
        for m in re.finditer(pattern, text, re.IGNORECASE | re.UNICODE):
            raw  = m.group(1).strip()
            item = re.sub(r"[.،,;؛]+$", "", raw).strip()
            if len(item) > 8 and _normalize(item) not in seen:
                seen.add(_normalize(item))
                items.append(item)

    # 2. Bullet points / numbered lists
    bullet_pattern = r"(?:^|\n)\s*(?:[•\-\*]|\d+[.\)])\s+(.{10,120})"
    for m in re.finditer(bullet_pattern, text, re.MULTILINE):
        item = m.group(1).strip()
        if _normalize(item) not in seen:
            seen.add(_normalize(item))
            items.append(item)

    # 3. Future tense Arabic sentences
    future_pattern = r"(?:س|سوف\s+)[يت]\w{2,}\s+(?:\w+\s+){0,5}(.{10,80})"
    for m in re.finditer(future_pattern, text):
        sentence = m.group(0).strip()
        item     = re.sub(r"[.،,;؛]+$", "", sentence).strip()
        if len(item) > 10 and _normalize(item) not in seen:
            seen.add(_normalize(item))
            items.append(item)

    return items[:10]


# ══════════════════════════════════════════════════
# SENTIMENT — Lexicon-based
# ══════════════════════════════════════════════════
def analyze_sentiment(text: str) -> Dict:
    """
    يحلّل sentiment بدون LLM
    يرجّع: { score: -1..1, label: positive/negative/neutral, pos_count, neg_count }
    """
    # Normalize Arabic: strip diacritics + hamza variants
    normalized = _strip_diacritics(text.lower())
    tokens = set(re.findall(r"[\u0600-\u06FFa-zA-Z]+", normalized))

    # Normalize lexicons too
    pos_norm = {_strip_diacritics(w) for w in _POSITIVE_WORDS}
    neg_norm = {_strip_diacritics(w) for w in _NEGATIVE_WORDS}

    pos = len(tokens & pos_norm)
    neg = len(tokens & neg_norm)
    total = pos + neg

    if total == 0:
        score, label = 0.0, "neutral"
    else:
        score = (pos - neg) / total
        if score > 0.2:
            label = "positive"
        elif score < -0.2:
            label = "negative"
        else:
            label = "neutral"

    return {
        "score":     round(score, 3),
        "label":     label,
        "pos_count": pos,
        "neg_count": neg,
        "emoji":     "😊" if label == "positive" else ("😟" if label == "negative" else "😐"),
    }


# ══════════════════════════════════════════════════
# LANGUAGE DETECTION
# ══════════════════════════════════════════════════
def detect_language(text: str) -> str:
    """يكتشف اللغة بناءً على نسبة الحروف"""
    arabic_chars  = len(re.findall(r"[\u0600-\u06FF]", text))
    english_chars = len(re.findall(r"[a-zA-Z]", text))
    total = arabic_chars + english_chars
    if total == 0:
        return "unknown"
    ar_ratio = arabic_chars / total
    en_ratio = english_chars / total
    if ar_ratio > 0.7:
        return "ar"
    if en_ratio > 0.7:
        return "en"
    return "mixed"   # كلاهما موجود بنسب متقاربة


# ══════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════
def _strip_diacritics(text: str) -> str:
    """يزيل التشكيل والهمزات لتوحيد المقارنة"""
    # Arabic diacritics (U+064B – U+065F)
    text = re.sub(r"[\u064B-\u065F\u0670]", "", text)
    # Normalize alef variants → ا
    text = re.sub(r"[أإآ]", "ا", text)
    # Normalize teh marbuta → ه
    text = re.sub(r"ة", "ه", text)
    # Normalize waw variants
    text = re.sub(r"ؤ", "و", text)
    # Normalize yeh variants
    text = re.sub(r"[يى]", "ي", text)
    return text


# ══════════════════════════════════════════════════
# FULL ANALYSIS — يجمع كل الـ algorithms
# ══════════════════════════════════════════════════
def analyze(text: str, summary_sentences: int = 3,
            keyword_count: int = 8) -> Dict:
    """
    Entry point — يشغّل كل الـ NLP pipeline:
    keywords + extractive_summary + action_items + sentiment + language
    """
    if not text or len(text.strip()) < 20:
        return {
            "summary":      text.strip() if text else "",
            "keywords":     [],
            "action_items": [],
            "sentiment":    {"score": 0, "label": "neutral", "emoji": "😐"},
            "language":     "unknown",
            "method":       "nlp_local",
        }

    return {
        "summary":      extractive_summary(text, summary_sentences),
        "keywords":     extract_keywords(text, keyword_count),
        "action_items": extract_action_items(text),
        "sentiment":    analyze_sentiment(text),
        "language":     detect_language(text),
        "method":       "nlp_local",
    }


# ══════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════
def _split_sentences(text: str) -> List[str]:
    """يقسم النص لجمل — يدعم العربي والإنجليزي"""
    parts = re.split(r"(?<=[.!؟\n])\s+|(?<=\n)", text)
    sentences = [p.strip() for p in parts if len(p.strip()) > 10]
    return sentences if sentences else [text.strip()]


def _normalize(text: str) -> str:
    """normalizes for deduplication"""
    return re.sub(r"\s+", " ", text.lower().strip())[:50]
