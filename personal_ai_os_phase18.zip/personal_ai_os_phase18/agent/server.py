# agent/server.py
# ══════════════════════════════════════════════════
# HTTP Server — Flutter بتكلمه
# يستمع على localhost:7070
# ══════════════════════════════════════════════════
#
# تشغيل:
#   python agent/server.py
#
# لما في ADB tunnel:
#   adb reverse tcp:7070 tcp:7070
#   → Flutter على الفون بتوصل للـ server على الـ PC
# ══════════════════════════════════════════════════

import json
import sys
import os
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

# Add parent dir to path
sys.path.insert(0, os.path.dirname(__file__))
from agent import make_agent, Agent
import tools as tools_mod
import notification_service as notif

# Phase 8 — LoRA
try:
    from lora import lora_status
    from lora.export_training_data import find_db, export as export_data
    _LORA_AVAILABLE = True
except ImportError:
    _LORA_AVAILABLE = False

# Phase 9 — Ambient Intelligence
try:
    from ambient import user_profile as profile_mod
    from ambient import ambient_engine as engine_mod
    _AMBIENT_AVAILABLE = True
except ImportError:
    _AMBIENT_AVAILABLE = False

# Phase 10 — Multi-Agent Orchestrator
try:
    from agents.orchestrator import Orchestrator
    _orchestrator = Orchestrator()
    _MULTI_AGENT = True
except Exception as _orch_err:
    _orchestrator = None
    _MULTI_AGENT  = False

# Phase 11 — Offline First + Sync
try:
    from offline import offline_queue as oq
    from offline import local_cache   as lc
    from offline import sync_engine   as se

    def _http_send_local(endpoint: str, payload: dict):
        """يبعت للـ endpoints الداخلية من الـ queue"""
        import json
        try:
            path = endpoint if endpoint.startswith("/") else f"/{endpoint}"
            url  = f"http://localhost:7070{path}"
            data = json.dumps(payload).encode()
            req  = __import__("urllib.request", fromlist=[""]).Request(
                url, data=data,
                headers={"Content-Type": "application/json"}, method="POST"
            )
            resp = __import__("urllib.request", fromlist=[""]).urlopen(req, timeout=5)
            return json.loads(resp.read())
        except Exception as e:
            return None

    se.get_engine().set_http_sender(_http_send_local)
    se.start()
    _OFFLINE_AVAILABLE = True
    print("📶 Offline/Sync engine started")
except Exception as _off_err:
    oq = lc = se = None
    _OFFLINE_AVAILABLE = False

# Phase 12 — Creative: Proactive + Image + Meetings
try:
    from creative import proactive_engine as proactive
    from creative import image_service    as img_svc
    from creative import meeting_recorder as meetings
    from creative import meeting_summarizer as summarizer
    _CREATIVE_AVAILABLE = True
    print("🎨 Creative module loaded")
except Exception as _cr_err:
    proactive = img_svc = meetings = summarizer = None
    _CREATIVE_AVAILABLE = False

# Phase 14 — Backup / Restore / Export
try:
    from backup import backup_engine  as bak
    from backup import restore_engine as rst
    from backup import export_engine  as exp
    _BACKUP_AVAILABLE = True
    print("💾 Backup module loaded")
except Exception as _bak_err:
    bak = rst = exp = None
    _BACKUP_AVAILABLE = False

# Phase 16 — Notifications / Reminders / Smart Alerts
try:
    from notifications import reminder_engine as rem_eng
    from notifications import smart_alerts    as sa_eng
    _NOTIF_AVAILABLE = True
    print("🔔 Notifications module loaded")
except Exception as _notif_err:
    rem_eng = sa_eng = None
    _NOTIF_AVAILABLE = False

# Phase 17 — Security + Analytics
try:
    from security import encryption_engine as enc_eng
    from security import app_lock
    _SECURITY_AVAILABLE = True
    print("🔐 Security module loaded")
except Exception as _sec_err:
    enc_eng = app_lock = None
    _SECURITY_AVAILABLE = False

try:
    from analytics import analytics_engine as anl
    from analytics import insights_builder as ins
    _ANALYTICS_AVAILABLE = True
    print("📊 Analytics module loaded")
except Exception as _anl_err:
    anl = ins = None
    _ANALYTICS_AVAILABLE = False

# Phase 18 — Smart Router + Audit + Settings
try:
    from backends.router  import BackendRouter
    from audit            import audit_engine as aud
    import agent_settings as agt_cfg
    _ROUTER    = BackendRouter()
    _ROUTER.set_audit_callback(aud.log_llm_call)
    _PHASE18   = True
    print("🚀 Phase 18: Router + Audit loaded")
except Exception as _p18_err:
    _ROUTER  = None
    aud      = None
    agt_cfg  = None
    _PHASE18 = False

# ── Global agent instance ─────────────────────────
_agent: Agent = None

def get_agent() -> Agent:
    global _agent
    if _agent is None:
        _agent = make_agent()   # auto: Claude API or Gemma fallback
    return _agent


# ══════════════════════════════════════════════════
# HTTP HANDLER
# ══════════════════════════════════════════════════
class AgentHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        # Custom log format
        print(f"[{self.command}] {self.path} → {args[1] if len(args) > 1 else '?'}")

    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get('Content-Length', 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode('utf-8'))

    # ── GET /health ───────────────────────────────
    def do_GET(self):
        if self.path == '/health':
            agent = get_agent()
            backend = agent.backend
            # إيه حالة Gemma on-device؟
            gemma_online = False
            if hasattr(backend, '_server_reachable'):
                gemma_online = backend._server_reachable()
            self._send_json({
                'status':        'ok',
                'backend':       backend.name,
                'version':       '5.0',
                'gemma_online':  gemma_online,
            })
        elif self.path == '/stats':
            self._send_json({
                'messages_today': 0,
                'tasks_done':     4,
                'tasks_total':    7,
                'streak_days':    5,
            })

        # ── GET /lora/status — Phase 8 ─────────────
        elif self.path == '/lora/status':
            if _LORA_AVAILABLE:
                self._send_json(lora_status.get())
            else:
                self._send_json({'state': 'unavailable', 'message': 'lora module not found'})

        # ── GET /profile — Phase 9 ──────────────────
        elif self.path == '/profile':
            if _AMBIENT_AVAILABLE:
                p = profile_mod.load()
                self._send_json(p)
            else:
                self._send_json({'error': 'ambient not available'}, 503)

        # ── GET /insights — Phase 9 ─────────────────
        elif self.path == '/insights':
            if _AMBIENT_AVAILABLE:
                cached = engine_mod.get_cached_insights()
                cards  = engine_mod.generate_insight_cards(cached)
                self._send_json({
                    'insights': cached,
                    'cards':    cards,
                    'profile':  profile_mod.to_agent_context(),
                })
            else:
                self._send_json({'error': 'ambient not available'}, 503)

        # ── GET /agents — Phase 10 ──────────────────
        elif self.path == '/agents':
            if _MULTI_AGENT:
                self._send_json({
                    'available': True,
                    'agents':    _orchestrator.list_agents(),
                })
            else:
                self._send_json({'available': False, 'agents': []})

        # ── GET /sync/status — Phase 11 ─────────────
        elif self.path == '/sync/status':
            if _OFFLINE_AVAILABLE:
                self._send_json(se.get_engine().get_status())
            else:
                self._send_json({'online': True, 'pending_count': 0,
                                 'error': 'offline module not loaded'})

        # ── GET /queue — Phase 11 ───────────────────
        elif self.path == '/queue':
            if _OFFLINE_AVAILABLE:
                self._send_json({
                    'stats': oq.get_stats(),
                    'items': oq.get_recent(limit=10),
                })
            else:
                self._send_json({'stats': {}, 'items': []})

        # ── GET /proactive — Phase 12 ────────────────
        elif self.path == '/proactive':
            if _CREATIVE_AVAILABLE:
                self._send_json({'suggestions': proactive.get_suggestions(5)})
            else:
                self._send_json({'suggestions': []})

        # ── GET /images — Phase 12 ───────────────────
        elif self.path == '/images':
            if _CREATIVE_AVAILABLE:
                self._send_json({'images': img_svc.list_images(30)})
            else:
                self._send_json({'images': []})

        # ── GET /meetings — Phase 12 ─────────────────
        elif self.path == '/meetings':
            if _CREATIVE_AVAILABLE:
                self._send_json({
                    'meetings': meetings.list_meetings(20),
                    'stats':    meetings.get_stats(),
                })
            else:
                self._send_json({'meetings': [], 'stats': {}})

        # ── GET /widget/data — Phase 13 ──────────────
        # بيجمع كل البيانات اللي الـ widget يحتاجها في call واحدة
        elif self.path == '/widget/data':
            import datetime
            data = {
                'time':       datetime.datetime.now().strftime('%H:%M'),
                'suggestion': '💡 مرحباً! اضغط للتحدث مع مساعدك',
                'online':     True,
                'pending':    0,
            }
            # Add proactive suggestion
            if _CREATIVE_AVAILABLE:
                try:
                    sug = proactive.get_suggestions(limit=1)
                    if sug:
                        s = sug[0]
                        data['suggestion'] = f"{s.get('title','')}: {s.get('body','')}"
                except Exception:
                    pass
            # Add offline queue status
            if _OFFLINE_AVAILABLE:
                try:
                    stats = oq.get_stats()
                    data['pending'] = stats.get('pending', 0) + stats.get('retrying', 0)
                    status = se.get_engine().get_status()
                    data['online']  = status.get('online', True)
                except Exception:
                    pass
            self._send_json(data)

        # ── GET /backups — Phase 14 ───────────────────
        elif self.path == '/backups':
            if _BACKUP_AVAILABLE:
                self._send_json({
                    'backups': bak.list_backups(),
                    'stats':   bak.get_stats(),
                })
            else:
                self._send_json({'backups': [], 'stats': {}})

        # ── GET /backup/stats — Phase 14 ─────────────
        elif self.path == '/backup/stats':
            if _BACKUP_AVAILABLE:
                self._send_json(bak.get_stats())
            else:
                self._send_json({'count': 0})

        # ── GET /theme — Phase 15 ────────────────────
        elif self.path == '/theme':
            import json as _json
            from pathlib import Path as _Path
            theme_file = _Path('data/theme_prefs.json')
            if theme_file.exists():
                try:
                    self._send_json(_json.loads(theme_file.read_text()))
                except Exception:
                    self._send_json({'theme': 'cyberpunk', 'mode': 'dark'})
            else:
                self._send_json({'theme': 'cyberpunk', 'mode': 'dark',
                                 'font_scale': 1.0, 'lang': 'ar'})

        # ── GET /reminders — Phase 16 ─────────────────
        elif self.path.startswith('/reminders'):
            if not _NOTIF_AVAILABLE:
                self._send_json({'reminders': [], 'stats': {}})
                return
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(self.path).query)
            include_done = qs.get('done', ['0'])[0] == '1'
            priority     = qs.get('priority', [None])[0]
            tag          = qs.get('tag', [None])[0]
            reminders    = rem_eng.list_reminders(
                include_done=include_done, priority=priority, tag=tag)
            self._send_json({
                'reminders': reminders,
                'stats':     rem_eng.get_stats(),
            })

        # ── GET /alerts — Phase 16 ────────────────────
        elif self.path == '/alerts':
            if not _NOTIF_AVAILABLE:
                self._send_json({'alerts': []})
                return
            alerts = sa_eng.get_pending(window_seconds=3600)
            self._send_json({'alerts': alerts, 'count': len(alerts)})

        # ── GET /security/status — Phase 17 ──────────
        elif self.path == '/security/status':
            if _SECURITY_AVAILABLE:
                svc = app_lock.get_service()
                self._send_json({
                    **svc.get_status(),
                    **enc_eng.get_security_stats(),
                })
            else:
                self._send_json({'state': 'unavailable', 'has_pin': False})

        # ── GET /security/log — Phase 17 ─────────────
        elif self.path == '/security/log':
            if _SECURITY_AVAILABLE:
                self._send_json({'events': enc_eng.get_security_log(limit=30)})
            else:
                self._send_json({'events': []})

        # ── GET /analytics/report — Phase 17 ─────────
        elif self.path == '/analytics/report':
            if _ANALYTICS_AVAILABLE:
                self._send_json(anl.get_full_report())
            else:
                self._send_json({'today': {}, 'week': [], 'totals': {}})

        # ── GET /analytics/insights — Phase 17 ───────
        elif self.path == '/analytics/insights':
            if _ANALYTICS_AVAILABLE:
                self._send_json({'insights': ins.build_insights()})
            else:
                self._send_json({'insights': []})

        # ── GET /agent/status — Phase 18 ─────────────
        elif self.path == '/agent/status':
            status = {}
            if _PHASE18 and _ROUTER:
                status['router'] = _ROUTER.get_status()
                status['settings'] = agt_cfg.load()
                # mask keys
                for k in ('claude_key','gpt_key'):
                    if status['settings'].get(k):
                        status['settings'][k] = '***'
            self._send_json(status)

        # ── GET /agent/settings — Phase 18 ───────────
        elif self.path == '/agent/settings':
            if _PHASE18:
                s = agt_cfg.load()
                for k in ('claude_key','gpt_key'):
                    if s.get(k): s[k] = '***'
                self._send_json(s)
            else:
                self._send_json({})

        # ── GET /audit/log — Phase 18 ─────────────────
        elif self.path.startswith('/audit/log'):
            if not _PHASE18:
                self._send_json({'events': []}); return
            from urllib.parse import urlparse, parse_qs
            qs    = parse_qs(urlparse(self.path).query)
            limit = int(qs.get('limit', ['50'])[0])
            etype = qs.get('type', [None])[0]
            date  = qs.get('date', [None])[0]
            self._send_json({
                'events': aud.get_audit_log(limit, etype, date),
                'stats':  aud.get_audit_stats(),
            })

        # ── GET /audit/pending — Phase 18 ────────────
        elif self.path == '/audit/pending':
            if _PHASE18:
                self._send_json({'pending': aud.list_pending()})
            else:
                self._send_json({'pending': []})

        else:
            self._send_json({'error': 'not found'}, 404)

    # ── POST /chat ────────────────────────────────
    def do_POST(self):
        if self.path == '/chat':
            try:
                data    = self._read_json()
                message = data.get('message', '').strip()

                if not message:
                    self._send_json({'error': 'empty message'}, 400)
                    return

                print(f"\n👤 {message}")

                # Phase 11 — check cache first (non-conversational queries)
                if _OFFLINE_AVAILABLE:
                    cached = lc.get("chat", {"message": message})
                    if cached:
                        print(f"📦 Cache hit: {message[:40]}")
                        self._send_json(cached)
                        return

                # Run agent — returns AgentResult now
                agent  = get_agent()
                result = agent.run(message, verbose=True)
                result_dict = result.to_dict()

                # Phase 11 — cache the response
                if _OFFLINE_AVAILABLE:
                    lc.set("chat", {"message": message}, result_dict)

                print(f"🤖 {result.text[:80]}...")
                self._send_json(result_dict)

            except Exception as e:
                print(f"❌ Error: {e}")
                self._send_json({'error': str(e)}, 500)

        elif self.path == '/reset':
            get_agent().reset()
            self._send_json({'status': 'reset ok'})

        # ── POST /multi_agent — Phase 10 ───────────
        elif self.path == '/multi_agent':
            try:
                data    = self._read_json()
                message = data.get('message', '').strip()
                context = data.get('context', '')

                if not message:
                    self._send_json({'error': 'empty message'}, 400)
                    return

                if not _MULTI_AGENT:
                    # fallback للـ main agent
                    agent  = get_agent()
                    result = agent.run(message, verbose=False)
                    self._send_json({
                        'mode':        'fallback',
                        'agents_used': ['main'],
                        'text':        result.text,
                        'sub_results': [],
                        'total_ms':    0,
                    })
                    return

                print(f"\n🎯 MultiAgent: {message}")
                orch_result = _orchestrator.route(message, context)

                # لو orchestrator مش عارف → main agent
                if orch_result.final_text is None:
                    agent  = get_agent()
                    result = agent.run(message, verbose=True)
                    self._send_json({
                        'mode':        'main_fallback',
                        'agents_used': ['main'],
                        'text':        result.text,
                        'sub_results': [],
                        'total_ms':    orch_result.total_ms,
                    })
                else:
                    self._send_json(orch_result.to_dict())

            except Exception as e:
                print(f"❌ MultiAgent error: {e}")
                self._send_json({'error': str(e)}, 500)

        # ── POST /classify — Phase 10 ───────────────
        # يصنّف الـ query بدون تشغيل
        elif self.path == '/classify':
            try:
                data    = self._read_json()
                message = data.get('message', '').strip()
                if not message:
                    self._send_json({'error': 'empty'}, 400)
                    return
                if _MULTI_AGENT:
                    scores = _orchestrator.classify(message)
                    self._send_json({'scores': scores})
                else:
                    self._send_json({'scores': {}})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        elif self.path == '/notify':
            # Flutter بتبعت notification request
            try:
                data  = self._read_json()
                title = data.get('title', '')
                body  = data.get('body', '')
                print(f"📲 Notify: {title} — {body}")
                self._send_json({'status': 'ok'})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /screen_context — Phase 7 ─────────
        elif self.path == '/screen_context':
            try:
                data     = self._read_json()
                app_name = data.get('app_name',    '')
                package  = data.get('package',     '')
                scr_text = data.get('screen_text', '')
                tools_mod.update_screen_context(app_name, package, scr_text)
                suggestion = ""
                try:
                    result = tools_mod.run("suggest_action", {
                        "app_name":    app_name,
                        "screen_text": scr_text,
                    })
                    if result and not result.startswith("❌") and result.strip():
                        suggestion = result
                except Exception:
                    pass
                self._send_json({'ok': True, 'suggestion': suggestion})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /lora/export — Phase 8 ────────────
        elif self.path == '/lora/export':
            if not _LORA_AVAILABLE:
                self._send_json({'error': 'lora not available'}, 503)
                return
            try:
                data   = self._read_json()
                db_hint = data.get('db_path', None)
                db     = find_db(db_hint)
                if not db:
                    self._send_json({'error': 'personal_ai.db not found'}, 404)
                    return

                lora_status.set_state(lora_status.EXPORTING, "جاري تصدير البيانات...")

                def _do_export():
                    try:
                        result = export_data(
                            db_path  = db,
                            out_path = "lora/data/train.jsonl",
                            min_pairs = 10,
                        )
                        lora_status.set_state(
                            lora_status.IDLE,
                            message  = f"✅ تم تصدير {result['total']} sample",
                            samples  = result['total'],
                            progress = 100,
                        )
                    except Exception as ex:
                        lora_status.set_error(str(ex))

                threading.Thread(target=_do_export, daemon=True).start()
                self._send_json({'ok': True, 'message': 'export started'})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /lora/start — Phase 8 ─────────────
        elif self.path == '/lora/start':
            if not _LORA_AVAILABLE:
                self._send_json({'error': 'lora not available'}, 503)
                return
            try:
                data_path = "lora/data/train.jsonl"
                if not __import__('os').path.exists(data_path):
                    self._send_json({'error': 'data not exported yet — run /lora/export first'}, 400)
                    return

                lora_status.set_state(lora_status.TRAINING, "بدأ التدريب...", progress=0)

                def _do_train():
                    try:
                        import subprocess, sys
                        result = subprocess.run(
                            [sys.executable, "lora/train_lora.py",
                             "--data", data_path, "--steps", "150"],
                            capture_output=True, text=True
                        )
                        if result.returncode == 0:
                            lora_status.set_done("lora_adapter/adapter", 0)
                        else:
                            lora_status.set_error(result.stderr[-300:])
                    except Exception as ex:
                        lora_status.set_error(str(ex))

                threading.Thread(target=_do_train, daemon=True).start()
                self._send_json({'ok': True, 'message': 'training started'})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /lora/reset — Phase 8 ─────────────
        elif self.path == '/lora/reset':
            if _LORA_AVAILABLE:
                lora_status.reset()
                self._send_json({'ok': True})
            else:
                self._send_json({'error': 'lora not available'}, 503)

        # ── POST /sync/retry — Phase 11 ─────────────
        elif self.path == '/sync/retry':
            if _OFFLINE_AVAILABLE:
                oq.reset_failed()
                self._send_json({'ok': True, 'message': 'failed items reset to pending'})
            else:
                self._send_json({'error': 'offline not available'}, 503)

        # ── POST /queue/enqueue — Phase 11 ──────────
        elif self.path == '/queue/enqueue':
            if not _OFFLINE_AVAILABLE:
                self._send_json({'error': 'offline not available'}, 503)
                return
            try:
                data     = self._read_json()
                endpoint = data.get('endpoint', '')
                payload  = data.get('payload',  {})
                priority = data.get('priority',  2)
                if not endpoint:
                    self._send_json({'error': 'endpoint required'}, 400)
                    return
                item_id = oq.enqueue(
                    endpoint     = endpoint,
                    payload      = payload,
                    priority     = oq.Priority(priority),
                )
                self._send_json({'ok': True, 'id': item_id})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /ambient/analyze — Phase 9 ────────
        elif self.path == '/ambient/analyze':
            if not _AMBIENT_AVAILABLE:
                self._send_json({'error': 'ambient not available'}, 503)
                return
            try:
                data    = self._read_json()
                db_hint = data.get('db_path', None)

                def _do_analyze():
                    try:
                        result = engine_mod.run_and_update(db_hint)
                        print(f"🧠 Ambient analyzed: {result.get('sample_size', 0)} msgs")
                    except Exception as ex:
                        print(f"❌ Ambient analysis failed: {ex}")

                threading.Thread(target=_do_analyze, daemon=True).start()
                self._send_json({'ok': True, 'message': 'analysis started'})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /profile/update — Phase 9 ─────────
        elif self.path == '/profile/update':
            if not _AMBIENT_AVAILABLE:
                self._send_json({'error': 'ambient not available'}, 503)
                return
            try:
                data    = self._read_json()
                profile = profile_mod.load()
                # Merge incoming fields
                name = data.get('name')
                if name:
                    profile['name'] = name
                tz = data.get('timezone')
                if tz:
                    profile['timezone'] = tz
                profile_mod.save(profile)
                self._send_json({'ok': True, 'profile': profile})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /app_usage — Phase 9 ───────────────
        # Android بيبعت usage data كل ساعة
        elif self.path == '/app_usage':
            if not _AMBIENT_AVAILABLE:
                self._send_json({'ok': True})  # silent ignore
                return
            try:
                data     = self._read_json()
                apps     = data.get('apps', [])   # [{package, name, minutes}]
                hour     = data.get('hour', 0)

                profile  = profile_mod.load()
                # merge top apps
                existing = {a['package']: a for a in profile.get('top_apps', [])}
                for app in apps:
                    pkg = app.get('package', '')
                    if pkg and not pkg.startswith('com.android.'):
                        if pkg in existing:
                            existing[pkg]['count'] = existing[pkg].get('count', 0) + 1
                        else:
                            existing[pkg] = {
                                'package': pkg,
                                'name':    app.get('name', pkg.split('.')[-1]),
                                'count':   1,
                            }

                # keep top 20 sorted by count
                sorted_apps = sorted(existing.values(), key=lambda x: x.get('count', 0), reverse=True)
                profile['top_apps'] = sorted_apps[:20]

                # update active hour
                active = profile['peak_hours'].get('most_active', [])
                if hour not in active:
                    active.append(hour)
                    profile['peak_hours']['most_active'] = sorted(active)[-8:]

                profile_mod.save(profile)
                self._send_json({'ok': True})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ════════════════════════════════════════════
        # Phase 12 — Creative endpoints
        # ════════════════════════════════════════════

        # ── POST /image/generate ─────────────────────
        elif self.path == '/image/generate':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data     = self._read_json()
                prompt   = data.get('prompt', '').strip()
                style    = data.get('style',    'realistic')
                size     = data.get('size',     '512x512')
                negative = data.get('negative', '')
                if not prompt:
                    self._send_json({'error': 'prompt required'}, 400)
                    return
                result = img_svc.generate(prompt, style=style,
                                          size=size, negative=negative)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /image/edit ──────────────────────────
        elif self.path == '/image/edit':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data      = self._read_json()
                filename  = data.get('filename', '')
                operation = data.get('operation', '')
                params    = data.get('params', {})
                if not filename or not operation:
                    self._send_json({'error': 'filename + operation required'}, 400)
                    return
                result = img_svc.edit(filename, operation, params)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /image/get ───────────────────────────
        elif self.path == '/image/get':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data     = self._read_json()
                filename = data.get('filename', '')
                b64      = img_svc.get_image_b64(filename)
                if b64:
                    self._send_json({'ok': True, 'base64': b64, 'filename': filename})
                else:
                    self._send_json({'error': 'not found'}, 404)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /meeting/create ──────────────────────
        elif self.path == '/meeting/create':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data      = self._read_json()
                title     = data.get('title', 'اجتماع جديد')
                attendees = data.get('attendees', [])
                language  = data.get('language', 'ar')
                m_id      = meetings.create_meeting(title, attendees, language)
                self._send_json({'ok': True, 'meeting_id': m_id})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /meeting/transcript ──────────────────
        elif self.path == '/meeting/transcript':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data       = self._read_json()
                m_id       = data.get('meeting_id', '')
                transcript = data.get('transcript', '')
                duration_s = int(data.get('duration_s', 0))
                if not m_id:
                    self._send_json({'error': 'meeting_id required'}, 400)
                    return
                ok = meetings.save_transcript(m_id, transcript, duration_s)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /meeting/summarize ───────────────────
        elif self.path == '/meeting/summarize':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data = self._read_json()
                m_id = data.get('meeting_id', '')
                if not m_id:
                    self._send_json({'error': 'meeting_id required'}, 400)
                    return
                meeting = meetings.get_meeting(m_id)
                if not meeting:
                    self._send_json({'error': 'meeting not found'}, 404)
                    return

                transcript = meeting.get('transcript', '')
                backend    = get_agent().backend if get_agent() else None
                result     = summarizer.summarize(transcript, backend=backend)

                meetings.save_summary(
                    m_id,
                    result['summary'],
                    result['action_items'],
                    result['keywords'],
                )
                self._send_json({'ok': True, **result})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /meeting/get ─────────────────────────
        elif self.path == '/meeting/get':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data = self._read_json()
                m_id = data.get('meeting_id', '')
                m    = meetings.get_meeting(m_id)
                if m:
                    self._send_json(m)
                else:
                    self._send_json({'error': 'not found'}, 404)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /meeting/delete ──────────────────────
        elif self.path == '/meeting/delete':
            if not _CREATIVE_AVAILABLE:
                self._send_json({'error': 'creative not available'}, 503)
                return
            try:
                data = self._read_json()
                m_id = data.get('meeting_id', '')
                ok   = meetings.delete_meeting(m_id)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ════════════════════════════════════════════
        # Phase 14 — Backup / Restore / Export
        # ════════════════════════════════════════════

        # ── POST /backup/create ───────────────────────
        elif self.path == '/backup/create':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data           = self._read_json()
                password       = data.get('password', '')
                include_images = data.get('include_images', False)
                label          = data.get('label', '')
                result = bak.create_backup(
                    password=password,
                    include_images=include_images,
                    label=label,
                )
                # Don't return manifest in response (too large)
                result.pop('manifest', None)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /backup/delete ───────────────────────
        elif self.path == '/backup/delete':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data     = self._read_json()
                filename = data.get('filename', '')
                ok       = bak.delete_backup(filename)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /backup/validate ─────────────────────
        elif self.path == '/backup/validate':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data     = self._read_json()
                filename = data.get('filename', '')
                password = data.get('password', '')
                result   = rst.validate(filename, password)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /backup/restore ──────────────────────
        elif self.path == '/backup/restore':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data     = self._read_json()
                filename = data.get('filename', '')
                password = data.get('password', '')
                dry_run  = data.get('dry_run', False)
                if not filename:
                    self._send_json({'error': 'filename required'}, 400)
                    return
                result = rst.restore(filename, password, dry_run)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /export/json ─────────────────────────
        elif self.path == '/export/json':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data           = self._read_json()
                include_images = data.get('include_images', False)
                result         = exp.export_json(include_images)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /export/csv ──────────────────────────
        elif self.path == '/export/csv':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                result = exp.export_csv()
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /export/report ───────────────────────
        elif self.path == '/export/report':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                data   = self._read_json()
                lang   = data.get('lang', 'ar')
                result = exp.export_report(lang)
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /export/all ──────────────────────────
        elif self.path == '/export/all':
            if not _BACKUP_AVAILABLE:
                self._send_json({'error': 'backup not available'}, 503)
                return
            try:
                result = exp.export_all()
                self._send_json(result)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ════════════════════════════════════════════
        # Phase 16 — Reminders / Smart Alerts
        # ════════════════════════════════════════════

        # ── POST /reminder/create ─────────────────────
        elif self.path == '/reminder/create':
            if not _NOTIF_AVAILABLE:
                self._send_json({'error': 'notifications not available'}, 503)
                return
            try:
                d   = self._read_json()
                rid = rem_eng.create_reminder(
                    label       = d.get('label', 'تذكير'),
                    time        = d.get('time', '09:00'),
                    date        = d.get('date'),
                    repeat      = d.get('repeat', 'none'),
                    repeat_days = d.get('repeat_days', []),
                    pre_alert   = int(d.get('pre_alert', 10)),
                    priority    = d.get('priority', 'normal'),
                    tags        = d.get('tags', []),
                    note        = d.get('note', ''),
                )
                self._send_json({'ok': True, 'id': rid})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /reminder/update ─────────────────────
        elif self.path == '/reminder/update':
            if not _NOTIF_AVAILABLE:
                self._send_json({'error': 'notifications not available'}, 503)
                return
            try:
                d   = self._read_json()
                rid = d.pop('id', None)
                if not rid:
                    self._send_json({'error': 'id required'}, 400)
                    return
                ok = rem_eng.update_reminder(rid, **d)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /reminder/delete ─────────────────────
        elif self.path == '/reminder/delete':
            if not _NOTIF_AVAILABLE:
                self._send_json({'error': 'notifications not available'}, 503)
                return
            try:
                d   = self._read_json()
                rid = d.get('id', '')
                ok  = rem_eng.delete_reminder(rid)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /reminder/done ───────────────────────
        elif self.path == '/reminder/done':
            if not _NOTIF_AVAILABLE:
                self._send_json({'error': 'notifications not available'}, 503)
                return
            try:
                d   = self._read_json()
                rid = d.get('id', '')
                ok  = rem_eng.mark_done(rid)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /reminder/snooze ─────────────────────
        elif self.path == '/reminder/snooze':
            if not _NOTIF_AVAILABLE:
                self._send_json({'error': 'notifications not available'}, 503)
                return
            try:
                d       = self._read_json()
                rid     = d.get('id', '')
                minutes = int(d.get('minutes', 10))
                ok      = rem_eng.snooze_reminder(rid, minutes)
                self._send_json({'ok': ok, 'snoozed_minutes': minutes})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /alerts/clear ────────────────────────
        elif self.path == '/alerts/clear':
            if _NOTIF_AVAILABLE and sa_eng:
                sa_eng.clear_sent()
            self._send_json({'ok': True})

        # ── POST /alerts/test ─────────────────────────
        elif self.path == '/alerts/test':
            """يبعت notification اختباري فوراً"""
            try:
                d     = self._read_json()
                title = d.get('title', '🔔 تنبيه تجريبي')
                body  = d.get('body',  'هذا اختبار للـ notification system')
                import urllib.request, json as _j
                data = _j.dumps({'title': title, 'body': body}).encode()
                req  = urllib.request.Request(
                    'http://localhost:7070/notify', data=data,
                    headers={'Content-Type': 'application/json'})
                urllib.request.urlopen(req, timeout=2)
                self._send_json({'ok': True, 'sent': title})
            except Exception as e:
                self._send_json({'ok': False, 'error': str(e)})

        # ════════════════════════════════════════════
        # Phase 17 — Security
        # ════════════════════════════════════════════

        # ── POST /security/setup_pin ──────────────────
        elif self.path == '/security/setup_pin':
            if not _SECURITY_AVAILABLE:
                self._send_json({'error': 'security not available'}, 503); return
            try:
                d   = self._read_json()
                pin = d.get('pin', '')
                self._send_json(app_lock.get_service().setup_pin(pin))
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /security/unlock ─────────────────────
        elif self.path == '/security/unlock':
            if not _SECURITY_AVAILABLE:
                self._send_json({'error': 'security not available'}, 503); return
            try:
                d   = self._read_json()
                pin = d.get('pin', '')
                self._send_json(app_lock.get_service().unlock(pin))
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /security/lock ───────────────────────
        elif self.path == '/security/lock':
            if not _SECURITY_AVAILABLE:
                self._send_json({'ok': True}); return
            self._send_json(app_lock.get_service().lock())

        # ── POST /security/biometric_unlock ──────────
        elif self.path == '/security/biometric_unlock':
            if not _SECURITY_AVAILABLE:
                self._send_json({'error': 'security not available'}, 503); return
            self._send_json(app_lock.get_service().unlock_biometric())

        # ── POST /security/change_pin ─────────────────
        elif self.path == '/security/change_pin':
            if not _SECURITY_AVAILABLE:
                self._send_json({'error': 'security not available'}, 503); return
            try:
                d       = self._read_json()
                old_pin = d.get('old_pin', '')
                new_pin = d.get('new_pin', '')
                self._send_json(app_lock.get_service().change_pin(old_pin, new_pin))
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /security/configure ──────────────────
        elif self.path == '/security/configure':
            if not _SECURITY_AVAILABLE:
                self._send_json({'error': 'security not available'}, 503); return
            try:
                d = self._read_json()
                self._send_json(app_lock.get_service().configure(**d))
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ════════════════════════════════════════════
        # Phase 17 — Analytics
        # ════════════════════════════════════════════

        # ── POST /analytics/track ─────────────────────
        elif self.path == '/analytics/track':
            if not _ANALYTICS_AVAILABLE:
                self._send_json({'ok': True}); return
            try:
                d = self._read_json()
                anl.track(
                    event_type = d.get('type', 'unknown'),
                    subtype    = d.get('subtype', ''),
                    value      = float(d.get('value', 1)),
                    meta       = d.get('meta', {}),
                )
                self._send_json({'ok': True})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /analytics/keepalive ─────────────────
        elif self.path == '/analytics/keepalive':
            if _SECURITY_AVAILABLE:
                app_lock.get_service().keep_alive()
            if _ANALYTICS_AVAILABLE:
                anl.track('session', 'keepalive')
            self._send_json({'ok': True})

        # ════════════════════════════════════════════
        # Phase 18 — Agent Settings + Audit + Router
        # ════════════════════════════════════════════

        # ── POST /agent/settings/update ───────────────
        elif self.path == '/agent/settings/update':
            if not _PHASE18:
                self._send_json({'error': 'phase18 not loaded'}, 503); return
            try:
                d   = self._read_json()
                key = d.get('key', '')
                val = d.get('value')
                if not key:
                    self._send_json({'error': 'key required'}, 400); return
                new_settings = agt_cfg.update(key, val)
                # Apply live if router-related
                if key == 'claude_key':
                    _ROUTER.set_keys(claude_key=val)
                elif key == 'gpt_key':
                    _ROUTER.set_keys(gpt_key=val)
                elif key == 'mistral_url':
                    _ROUTER.set_keys(mistral_url=val)
                elif key == 'prefer_cloud':
                    _ROUTER.set_prefer_cloud(bool(val))
                self._send_json({'ok': True, 'key': key})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /agent/settings/bulk ─────────────────
        elif self.path == '/agent/settings/bulk':
            if not _PHASE18:
                self._send_json({'ok': False}); return
            try:
                d = self._read_json()
                s = agt_cfg.load()
                for k, v in d.items():
                    if k in s:
                        agt_cfg.update(k, v)
                # Apply router keys
                _ROUTER.set_keys(
                    claude_key  = d.get('claude_key'),
                    gpt_key     = d.get('gpt_key'),
                    mistral_url = d.get('mistral_url'),
                )
                if 'prefer_cloud' in d:
                    _ROUTER.set_prefer_cloud(bool(d['prefer_cloud']))
                self._send_json({'ok': True})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /audit/approve ───────────────────────
        elif self.path == '/audit/approve':
            if not _PHASE18:
                self._send_json({'ok': False}); return
            try:
                d   = self._read_json()
                pid = d.get('id', '')
                res = aud.approve_pending(pid)
                self._send_json({'ok': bool(res), 'action': res})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /audit/reject ────────────────────────
        elif self.path == '/audit/reject':
            if not _PHASE18:
                self._send_json({'ok': False}); return
            try:
                d   = self._read_json()
                pid = d.get('id', '')
                ok  = aud.reject_pending(pid)
                self._send_json({'ok': ok})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        # ── POST /audit/log_event ─────────────────────
        elif self.path == '/audit/log_event':
            if not _PHASE18:
                self._send_json({'ok': True}); return
            try:
                d = self._read_json()
                aud.log(
                    event_type       = d.get('type', 'action'),
                    title            = d.get('title', ''),
                    detail           = d.get('detail', ''),
                    permission_level = int(d.get('level', 0)),
                )
                self._send_json({'ok': True})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        else:
            self._send_json({'error': 'not found'}, 404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()


# ══════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════
def main():
    port = int(os.environ.get('AGENT_PORT', 7070))
    host = '127.0.0.1'   # localhost only — أمان

    print(f"""
╔══════════════════════════════════════╗
║   Personal AI OS — Agent Server     ║
║   http://{host}:{port}              ║
╠══════════════════════════════════════╣
║  GET  /health  → status check       ║
║  GET  /stats   → user statistics    ║
║  POST /chat    → {{message: "..."}}   ║
║  POST /reset   → new conversation   ║
╠══════════════════════════════════════╣
║  ADB tunnel (للفون):                ║
║  adb reverse tcp:{port} tcp:{port}  ║
╚══════════════════════════════════════╝
""")

    # Initialize agent
    agent = get_agent()
    print(f"✅ Backend: {agent.backend.name}")
    print(f"   Available: {agent.backend.is_available()}\n")

    server = HTTPServer((host, port), AgentHandler)
    print(f"🚀 Listening on {host}:{port}...\n")

    # Start notification service in background
    notif.start(tools_module=tools_mod)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped.")
        server.server_close()


if __name__ == '__main__':
    main()
