# agent/tools.py
# ══════════════════════════════════════════════════
# Tool registry — بيشتغل مع Claude و Gemma بنفس الطريقة
# Claude: JSON schema (tool_use API)
# Gemma:  نفس الـ schema في الـ prompt
# ══════════════════════════════════════════════════
import math
import datetime
from typing import Any, Callable, Dict, List

# ── In-memory stores (local — no cloud) ──────────
_reminders: List[Dict] = []
_notes:     List[Dict] = []
_stats = {
    "messages_today": 14,
    "tasks_done": 4,
    "tasks_total": 7,
    "streak_days": 5,
}


# ══════════════════════════════════════════════════
# TOOL IMPLEMENTATIONS
# ══════════════════════════════════════════════════

def _search(query: str) -> str:
    """في الإنتاج: HTTP عبر الـ Sandbox المشفر"""
    db = {
        "سعر الدولار": "💵 الدولار = 30.85 جنيه (تحديث: اليوم)",
        "dollar":      "💵 USD = 30.85 EGP (today)",
        "طقس":         "🌤️ القاهرة: 24°C، مشمس",
        "weather":     "🌤️ Cairo: 24°C, sunny",
        "python":      "🐍 Python 3.12 — latest stable",
        "flutter":     "📱 Flutter 3.19 — Dart, cross-platform",
        "gemma":       "🧠 Gemma 2B-IT — Google's open LLM, runs on-device",
    }
    q = query.lower()
    for key, val in db.items():
        if key in q:
            return val
    return f"🔍 نتائج '{query}':\n• نتيجة 1 ...\n• نتيجة 2 ...\n• نتيجة 3 ..."


def _set_reminder(time: str, label: str, pre_alert_minutes: int = 10) -> str:
    r = {
        "id":        f"REM_{len(_reminders)+1:04d}",
        "time":      time,
        "label":     label,
        "pre_alert": pre_alert_minutes,
    }
    _reminders.append(r)
    return (
        f"✅ تذكير اتحفظ!\n"
        f"🕐 {time} — {label}\n"
        f"⏰ تنبيه {pre_alert_minutes} دقيقة قبل\n"
        f"🆔 {r['id']}"
    )


def _calculate(expression: str) -> str:
    safe = set("0123456789+-*/().% ")
    expr = "".join(c for c in expression if c in safe)
    if not expr:
        return "❌ معادلة فاضية"
    try:
        result = eval(expr, {"__builtins__": {}}, {"math": math})
        return f"🧮 {expr} = {result}"
    except Exception as e:
        return f"❌ خطأ: {e}"


def _save_note(title: str, content: str, tags: str = "") -> str:
    n = {
        "id":      f"NOTE_{len(_notes)+1:04d}",
        "title":   title,
        "content": content,
        "tags":    [t.strip() for t in tags.split(",") if t.strip()],
    }
    _notes.append(n)
    return f"📝 '{title}' اتحفظت — {n['id']}"


def _get_stats(period: str = "today") -> str:
    s = _stats
    done_pct = int(s["tasks_done"] / s["tasks_total"] * 100)
    return (
        f"📊 إحصائياتك ({period}):\n"
        f"💬 رسائل: {s['messages_today']}\n"
        f"✅ مهام: {s['tasks_done']}/{s['tasks_total']} ({done_pct}%)\n"
        f"🔥 Streak: {s['streak_days']} يوم"
    )


def _get_time() -> str:
    now = datetime.datetime.now()
    day_ar = ["الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت","الأحد"][now.weekday()]
    return f"🕐 {now.strftime('%H:%M')}  |  📅 {day_ar} {now.day}/{now.month}/{now.year}"


def _list_reminders() -> str:
    if not _reminders:
        return "📭 مفيش تذكيرات"
    lines = [f"📋 تذكيراتك ({len(_reminders)}):"]
    for r in _reminders:
        lines.append(f"  🔔 {r['time']} — {r['label']}  [{r['id']}]")
    return "\n".join(lines)


# ══════════════════════════════════════════════════
# REGISTRY — اسم + schema + function
# ══════════════════════════════════════════════════
REGISTRY: Dict[str, Dict] = {

    "search": {
        "description": "ابحث في الإنترنت — أسعار، أخبار، معلومات",
        "schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "نص البحث"}
            },
            "required": ["query"],
        },
        "fn": _search,
    },

    "set_reminder": {
        "description": "احفظ تذكير بوقت ومحتوى محددين",
        "schema": {
            "type": "object",
            "properties": {
                "time":              {"type": "string",  "description": "HH:MM مثلاً 15:30"},
                "label":             {"type": "string",  "description": "موضوع التذكير"},
                "pre_alert_minutes": {"type": "integer", "description": "تنبيه مسبق بكام دقيقة"},
            },
            "required": ["time", "label"],
        },
        "fn": _set_reminder,
    },

    "calculate": {
        "description": "احسب أي معادلة رياضية",
        "schema": {
            "type": "object",
            "properties": {
                "expression": {"type": "string", "description": "المعادلة مثلاً: 150 * 0.85"}
            },
            "required": ["expression"],
        },
        "fn": _calculate,
    },

    "save_note": {
        "description": "احفظ ملاحظة في الذاكرة المحلية المشفرة",
        "schema": {
            "type": "object",
            "properties": {
                "title":   {"type": "string", "description": "عنوان الملاحظة"},
                "content": {"type": "string", "description": "محتوى الملاحظة"},
                "tags":    {"type": "string", "description": "كلمات مفتاحية"},
            },
            "required": ["title", "content"],
        },
        "fn": _save_note,
    },

    "get_stats": {
        "description": "اجلب إحصائيات المستخدم — مهام، رسائل، streak",
        "schema": {
            "type": "object",
            "properties": {
                "period": {"type": "string", "description": "today | week | month"}
            },
            "required": [],
        },
        "fn": _get_stats,
    },

    "get_time": {
        "description": "الوقت والتاريخ الحالي",
        "schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
        "fn": _get_time,
    },

    "list_reminders": {
        "description": "اعرض كل التذكيرات المحفوظة",
        "schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
        "fn": _list_reminders,
    },
}


# ══════════════════════════════════════════════════
# Phase 7 Tools — Screen Intelligence
# ══════════════════════════════════════════════════

# Global screen context (بيتحدّث من /screen_context endpoint)
_screen_context: Dict[str, str] = {}

def update_screen_context(app_name: str, package: str, screen_text: str) -> None:
    """بيستدعيه الـ server لما يوصله context من الـ Accessibility Service"""
    _screen_context["app_name"]    = app_name
    _screen_context["package"]     = package
    _screen_context["screen_text"] = screen_text[:500]
    _screen_context["updated_at"]  = datetime.datetime.now().strftime("%H:%M:%S")


def _get_screen_context() -> str:
    """يرجّع السياق الحالي للشاشة"""
    if not _screen_context:
        return "📱 مفيش screen context متاح حالياً — الـ Accessibility Service لازم يكون شغّال"
    app  = _screen_context.get("app_name", "؟")
    txt  = _screen_context.get("screen_text", "")
    time = _screen_context.get("updated_at", "")
    return f"📱 App: {app}\n🕐 آخر تحديث: {time}\n📝 المحتوى:\n{txt[:300]}"


def _suggest_action(app_name: str = "", screen_text: str = "") -> str:
    """
    يقترح action ذكية بناءً على الـ app والمحتوى
    لو مفيش input → يستخدم الـ context المحفوظ
    """
    app  = app_name  or _screen_context.get("app_name", "")
    text = screen_text or _screen_context.get("screen_text", "")
    t    = (app + " " + text).lower()

    # WhatsApp / Telegram
    if any(w in t for w in ["whatsapp", "telegram", "رسالة", "message"]):
        return "💬 عايز أساعدك في الرد؟ قولي إيه الرسالة وهكتبلك رد مناسب"

    # Google Maps / خرائط
    if any(w in t for w in ["maps", "خرائط", "navigation", "route"]):
        return "🗺️ عايز أحفظ الموقع ده؟ أو تذكير لما توصل؟"

    # Camera
    if any(w in t for w in ["camera", "كاميرا", "photo", "صورة"]):
        return "📸 عايز أحفظ ملاحظة عن الصورة دي؟"

    # YouTube / Video
    if any(w in t for w in ["youtube", "video", "يوتيوب", "فيديو"]):
        return "🎬 عايز أحفظ الفيديو ده للمشاهدة لاحقاً؟"

    # Browser / Reading
    if any(w in t for w in ["chrome", "firefox", "browser", "http", "www"]):
        return "🌐 عايز أحفظ الصفحة دي كملاحظة؟"

    # Email
    if any(w in t for w in ["gmail", "email", "إيميل", "mail"]):
        return "📧 عايز أساعدك في كتابة رد على الإيميل ده؟"

    # Calendar
    if any(w in t for w in ["calendar", "تقويم", "موعد", "meeting"]):
        return "📅 عايز أضيف التذكير ده في الأجندة؟"

    # Shopping
    if any(w in t for w in ["noon", "amazon", "cart", "سلة", "شراء", "جنيه"]):
        return "🛒 عايز أحفظ المنتج ده في قائمة المشتريات؟"

    return ""  # مش عارف أقترح حاجة — متعرضش overlay


REGISTRY.update({
    "get_screen_context": {
        "description": "يعرض ما يظهر على الشاشة حالياً — اسم الـ app والمحتوى",
        "schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
        "fn": _get_screen_context,
    },
    "suggest_action": {
        "description": "يقترح action ذكية بناءً على الـ app اللي شغّال",
        "schema": {
            "type": "object",
            "properties": {
                "app_name":    {"type": "string", "description": "اسم الـ app"},
                "screen_text": {"type": "string", "description": "نص من الشاشة"},
            },
            "required": [],
        },
        "fn": _suggest_action,
    },
})


def run(name: str, args: Dict[str, Any]) -> str:
    """نفّذ tool وارجّع نتيجة نصية"""
    entry = REGISTRY.get(name)
    if not entry:
        return f"❌ tool مجهولة: {name}"
    try:
        return str(entry["fn"](**args))
    except Exception as e:
        return f"❌ {name} فشل: {e}"


def schemas_for_claude() -> List[Dict]:
    """JSON schema للـ Anthropic API"""
    return [
        {
            "name": name,
            "description": entry["description"],
            "input_schema": entry["schema"],
        }
        for name, entry in REGISTRY.items()
    ]


def schemas_for_gemma() -> str:
    """وصف نصي للـ Gemma prompt"""
    lines = []
    for name, entry in REGISTRY.items():
        params = list(entry["schema"].get("properties", {}).keys())
        args_str = ", ".join(params) if params else "—"
        lines.append(f"  {name}({args_str}): {entry['description']}")
    return "\n".join(lines)
