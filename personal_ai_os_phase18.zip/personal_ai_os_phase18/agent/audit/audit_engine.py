# agent/audit/audit_engine.py — Phase 18
# ══════════════════════════════════════════════════
# Agent Audit Engine
# يسجّل كل حاجة الوكيل بيعملها:
#   • كل رسالة اتبعتت (SMS/WhatsApp/Email)
#   • كل action اتنفّذ
#   • كل LLM call وأي backend استُخدم
#   • كل طلب permission
#   • مبادرات الوكيل (proactive)
#   • تغييرات الإعدادات
#
# Dashboard: ممكن تشوف كل ده وتراجعه
# ══════════════════════════════════════════════════
import sqlite3
import json
import secrets
import datetime
from pathlib import Path
from typing import Dict, List, Optional

DB_PATH = Path('audit/data/audit.db')


# ── Event types ───────────────────────────────────
EV_LLM_CALL      = 'llm_call'
EV_MSG_SENT      = 'message_sent'       # رسالة اتبعتت
EV_MSG_DRAFT     = 'message_draft'      # مسودة (level 2)
EV_EMAIL_SENT    = 'email_sent'
EV_EMAIL_DRAFT   = 'email_draft'
EV_ACTION        = 'action'             # action عام
EV_PERMISSION    = 'permission_request'
EV_PROACTIVE     = 'proactive'          # مبادرة من الوكيل
EV_SETTINGS_CHANGE = 'settings_change'
EV_BACKEND_SWITCH  = 'backend_switch'
EV_ERROR         = 'error'


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS audit_log (
            id          TEXT PRIMARY KEY,
            type        TEXT NOT NULL,
            title       TEXT NOT NULL,
            detail      TEXT DEFAULT '',
            backend     TEXT DEFAULT '',
            permission_level INTEGER DEFAULT 0,
            approved    INTEGER DEFAULT -1,  -- -1=N/A, 0=pending, 1=approved, 2=rejected
            elapsed_ms  REAL  DEFAULT 0,
            meta        TEXT  DEFAULT '{}',
            ts          TEXT  NOT NULL,
            date        TEXT  NOT NULL
        );

        CREATE TABLE IF NOT EXISTS pending_actions (
            id          TEXT PRIMARY KEY,
            type        TEXT NOT NULL,
            title       TEXT NOT NULL,
            detail      TEXT DEFAULT '',
            payload     TEXT DEFAULT '{}',
            created_at  TEXT NOT NULL,
            expires_at  TEXT
        );
    ''')
    conn.commit()
    conn.close()


# ── Log event ─────────────────────────────────────
def log(event_type: str, title: str, detail: str = '',
        backend: str = '', permission_level: int = 0,
        approved: int = -1, elapsed_ms: float = 0,
        meta: dict = None) -> str:
    eid = secrets.token_hex(4)
    now = datetime.datetime.now()
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        '''INSERT INTO audit_log
           (id,type,title,detail,backend,permission_level,approved,elapsed_ms,meta,ts,date)
           VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
        (eid, event_type, title, detail, backend,
         permission_level, approved, elapsed_ms,
         json.dumps(meta or {}),
         now.isoformat(), now.strftime('%Y-%m-%d'))
    )
    conn.commit(); conn.close()
    return eid


def log_llm_call(backend: str, elapsed_s: float,
                 has_tools: bool = False):
    log(EV_LLM_CALL,
        title   = f"LLM call → {backend}",
        detail  = f"{'tool_call' if has_tools else 'text'} | {elapsed_s:.2f}s",
        backend = backend,
        elapsed_ms = elapsed_s * 1000)


def log_message(recipient: str, content_preview: str,
                channel: str = 'sms', approved: int = -1,
                level: int = 2):
    ev = EV_MSG_SENT if approved == 1 else EV_MSG_DRAFT
    log(ev,
        title            = f"رسالة → {recipient} ({channel})",
        detail           = content_preview[:120],
        permission_level = level,
        approved         = approved)


def log_email(to: str, subject: str, approved: int = -1, level: int = 2):
    ev = EV_EMAIL_SENT if approved == 1 else EV_EMAIL_DRAFT
    log(ev,
        title            = f"إيميل → {to}",
        detail           = subject,
        permission_level = level,
        approved         = approved)


def log_action(action_name: str, detail: str = '',
               level: int = 0, approved: int = -1):
    log(EV_ACTION,
        title            = action_name,
        detail           = detail,
        permission_level = level,
        approved         = approved)


def log_settings_change(key: str, old_val, new_val):
    log(EV_SETTINGS_CHANGE,
        title  = f"تغيير إعداد: {key}",
        detail = f"{old_val} → {new_val}")


# ── Pending actions (Draft mode) ──────────────────
def create_pending(action_type: str, title: str,
                   detail: str, payload: dict,
                   expires_minutes: int = 10) -> str:
    pid     = secrets.token_hex(6)
    now     = datetime.datetime.now()
    expires = (now + datetime.timedelta(minutes=expires_minutes)).isoformat()
    conn    = sqlite3.connect(str(DB_PATH))
    conn.execute(
        'INSERT INTO pending_actions(id,type,title,detail,payload,created_at,expires_at) '
        'VALUES(?,?,?,?,?,?,?)',
        (pid, action_type, title, detail,
         json.dumps(payload), now.isoformat(), expires)
    )
    conn.commit(); conn.close()
    return pid


def approve_pending(pid: str) -> Optional[Dict]:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    row  = conn.execute(
        'SELECT * FROM pending_actions WHERE id=?', (pid,)).fetchone()
    if row:
        conn.execute('DELETE FROM pending_actions WHERE id=?', (pid,))
        conn.commit()
    conn.close()
    if not row: return None
    d = dict(row)
    d['payload'] = json.loads(d['payload'])
    log(d['type'], d['title'], d['detail'], approved=1)
    return d


def reject_pending(pid: str) -> bool:
    conn = sqlite3.connect(str(DB_PATH))
    row  = conn.execute(
        'SELECT type,title,detail FROM pending_actions WHERE id=?', (pid,)
    ).fetchone()
    conn.execute('DELETE FROM pending_actions WHERE id=?', (pid,))
    conn.commit(); conn.close()
    if row:
        log(row[0], row[1], row[2], approved=2)
    return bool(row)


def list_pending() -> List[Dict]:
    if not DB_PATH.exists(): return []
    now  = datetime.datetime.now().isoformat()
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    # تنظيف المنتهية الصلاحية
    conn.execute('DELETE FROM pending_actions WHERE expires_at<?', (now,))
    conn.commit()
    rows = conn.execute(
        'SELECT * FROM pending_actions ORDER BY created_at DESC').fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        d['payload'] = json.loads(d['payload'])
        result.append(d)
    return result


# ── Query audit log ───────────────────────────────
def get_audit_log(limit: int = 100, event_type: str = None,
                  date: str = None) -> List[Dict]:
    if not DB_PATH.exists(): return []
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    q, params = 'SELECT * FROM audit_log WHERE 1=1', []
    if event_type:
        q += ' AND type=?'; params.append(event_type)
    if date:
        q += ' AND date=?'; params.append(date)
    q += ' ORDER BY ts DESC LIMIT ?'; params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_audit_stats() -> Dict:
    if not DB_PATH.exists():
        return {'total': 0}
    conn = sqlite3.connect(str(DB_PATH))
    total     = conn.execute('SELECT COUNT(*) FROM audit_log').fetchone()[0]
    messages  = conn.execute(
        "SELECT COUNT(*) FROM audit_log WHERE type IN ('message_sent','email_sent')"
    ).fetchone()[0]
    drafts    = conn.execute(
        "SELECT COUNT(*) FROM audit_log WHERE type IN ('message_draft','email_draft')"
    ).fetchone()[0]
    errors    = conn.execute(
        "SELECT COUNT(*) FROM audit_log WHERE type='error'"
    ).fetchone()[0]
    today     = conn.execute(
        "SELECT COUNT(*) FROM audit_log WHERE date=?",
        (datetime.date.today().isoformat(),)).fetchone()[0]
    pending   = conn.execute('SELECT COUNT(*) FROM pending_actions').fetchone()[0]
    conn.close()
    return {
        'total':     total,
        'messages':  messages,
        'drafts':    drafts,
        'errors':    errors,
        'today':     today,
        'pending':   pending,
    }
