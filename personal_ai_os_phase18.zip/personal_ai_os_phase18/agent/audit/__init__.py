# agent/audit/__init__.py — Phase 18
from . import audit_engine
try:
    audit_engine.init_db()
except Exception:
    pass
