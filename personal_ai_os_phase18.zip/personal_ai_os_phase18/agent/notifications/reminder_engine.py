# agent/notifications/reminder_engine.py — Phase 16
# ══════════════════════════════════════════════════
# Reminder Engine — SQLite + Recurring + Snooze
#
# يدعم:
#   • تذكيرات عادية (وقت محدد)
#   • تذكيرات متكررة: daily | weekly | weekdays | custom
#   • snooze (تأجيل 5/10/30 دقيقة)
#   • priority: low | normal | high | urgent
#   • tags للتصنيف
#   • sync مع tools._reminders الموجود
# ══════════════════════════════════════════════════
import sqlite3
import json
import uuid
import datetime
from pathlib import Path
from typing import Dict, List, Optional

DB_PATH = Path('notifications/data/reminders.db')

# ── Repeat rules ─────────────────────────────────
REPEAT_NONE     = 'none'
REPEAT_DAILY    = 'daily'
REPEAT_WEEKLY   = 'weekly'
REPEAT_WEEKDAYS = 'weekdays'   # Sun–Thu (Arabic work week)
REPEAT_WEEKEND  = 'weekend'    # Fri–Sat
REPEAT_CUSTOM   = 'custom'     # specific days list

PRIORITY_LOW    = 'low'
PRIORITY_NORMAL = 'normal'
PRIORITY_HIGH   = 'high'
PRIORITY_URGENT = 'urgent'


# ══════════════════════════════════════════════════
def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS reminders (
            id          TEXT PRIMARY KEY,
            label       TEXT NOT NULL,
            time        TEXT NOT NULL,       -- HH:MM
            date        TEXT,                -- YYYY-MM-DD or NULL (recurring)
            repeat      TEXT DEFAULT 'none', -- none/daily/weekly/weekdays/weekend/custom
            repeat_days TEXT DEFAULT '[]',   -- JSON [0-6] for custom
            pre_alert   INTEGER DEFAULT 10,  -- minutes before
            priority    TEXT DEFAULT 'normal',
            tags        TEXT DEFAULT '[]',
            note        TEXT DEFAULT '',
            done        INTEGER DEFAULT 0,
            snoozed_to  TEXT,               -- ISO datetime if snoozed
            fired_at    TEXT,               -- ISO datetime last fired
            created_at  TEXT NOT NULL,
            updated_at  TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS notification_log (
            id          TEXT PRIMARY KEY,
            reminder_id TEXT NOT NULL,
            fired_at    TEXT NOT NULL,
            action      TEXT DEFAULT 'fired'  -- fired/snoozed/dismissed
        );
    ''')
    conn.commit()
    conn.close()


# ── CRUD ─────────────────────────────────────────
def create_reminder(
    label:       str,
    time:        str,               # HH:MM
    date:        Optional[str] = None,  # YYYY-MM-DD
    repeat:      str  = REPEAT_NONE,
    repeat_days: List[int] = None,
    pre_alert:   int  = 10,
    priority:    str  = PRIORITY_NORMAL,
    tags:        List[str] = None,
    note:        str  = '',
) -> str:
    rid = str(uuid.uuid4())[:8]
    now = datetime.datetime.now().isoformat()
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        '''INSERT INTO reminders
           (id,label,time,date,repeat,repeat_days,pre_alert,
            priority,tags,note,done,created_at,updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,0,?,?)''',
        (rid, label, time, date,
         repeat, json.dumps(repeat_days or []),
         pre_alert, priority,
         json.dumps(tags or []), note, now, now)
    )
    conn.commit(); conn.close()
    return rid


def update_reminder(rid: str, **kwargs) -> bool:
    if not kwargs: return False
    allowed = {'label','time','date','repeat','repeat_days','pre_alert',
                'priority','tags','note','done','snoozed_to'}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates: return False

    now = datetime.datetime.now().isoformat()
    updates['updated_at'] = now
    # Serialize lists
    for k in ('repeat_days','tags'):
        if k in updates and isinstance(updates[k], list):
            updates[k] = json.dumps(updates[k])

    cols = ', '.join(f'{k}=?' for k in updates)
    vals = list(updates.values()) + [rid]
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.execute(f'UPDATE reminders SET {cols} WHERE id=?', vals)
    conn.commit(); conn.close()
    return c.rowcount > 0


def delete_reminder(rid: str) -> bool:
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.execute('DELETE FROM reminders WHERE id=?', (rid,))
    conn.commit(); conn.close()
    return c.rowcount > 0


def get_reminder(rid: str) -> Optional[Dict]:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    row = conn.execute('SELECT * FROM reminders WHERE id=?', (rid,)).fetchone()
    conn.close()
    return _row_to_dict(row) if row else None


def list_reminders(
    include_done: bool = False,
    priority:     Optional[str] = None,
    tag:          Optional[str] = None,
    limit:        int = 50,
) -> List[Dict]:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    q = 'SELECT * FROM reminders WHERE 1=1'
    params = []
    if not include_done:
        q += ' AND done=0'
    if priority:
        q += ' AND priority=?'; params.append(priority)
    if tag:
        q += ' AND tags LIKE ?'; params.append(f'%{tag}%')
    q += ' ORDER BY time, date LIMIT ?'; params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [_row_to_dict(r) for r in rows]


def snooze_reminder(rid: str, minutes: int = 10) -> bool:
    snooze_to = (datetime.datetime.now() +
                 datetime.timedelta(minutes=minutes)).isoformat()
    return update_reminder(rid, snoozed_to=snooze_to)


def mark_done(rid: str) -> bool:
    return update_reminder(rid, done=1)


# ── Due reminders ─────────────────────────────────
def get_due_reminders(window_seconds: int = 60) -> List[Dict]:
    """يرجّع الـ reminders اللي وقتها جه في الـ window دي"""
    now    = datetime.datetime.now()
    result = []

    for r in list_reminders(include_done=False):
        if _is_due(r, now, window_seconds):
            result.append(r)

    return result


def log_fired(rid: str, action: str = 'fired'):
    now = datetime.datetime.now().isoformat()
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        'INSERT INTO notification_log (id,reminder_id,fired_at,action) VALUES (?,?,?,?)',
        (str(uuid.uuid4())[:8], rid, now, action)
    )
    conn.execute('UPDATE reminders SET fired_at=? WHERE id=?', (now, rid))
    # mark one-time reminders as done
    row = conn.execute('SELECT repeat FROM reminders WHERE id=?', (rid,)).fetchone()
    if row and row[0] == REPEAT_NONE:
        conn.execute('UPDATE reminders SET done=1 WHERE id=?', (rid,))
    conn.commit(); conn.close()


def get_stats() -> Dict:
    conn = sqlite3.connect(str(DB_PATH))
    total    = conn.execute('SELECT COUNT(*) FROM reminders').fetchone()[0]
    pending  = conn.execute('SELECT COUNT(*) FROM reminders WHERE done=0').fetchone()[0]
    fired    = conn.execute('SELECT COUNT(*) FROM notification_log').fetchone()[0]
    urgent   = conn.execute("SELECT COUNT(*) FROM reminders WHERE priority='urgent' AND done=0").fetchone()[0]
    conn.close()
    return {'total': total, 'pending': pending, 'fired': fired, 'urgent': urgent}


# ── Helpers ───────────────────────────────────────
def _is_due(r: Dict, now: datetime.datetime, window: int) -> bool:
    # Check snooze
    if r.get('snoozed_to'):
        try:
            snooze_dt = datetime.datetime.fromisoformat(r['snoozed_to'])
            diff = abs((now - snooze_dt).total_seconds())
            if diff <= window:
                return True
        except Exception:
            pass

    # Parse time
    try:
        h, m  = map(int, r['time'].split(':'))
        pre   = int(r.get('pre_alert', 0))
        target = now.replace(hour=h, minute=m, second=0, microsecond=0)
        alert  = target - datetime.timedelta(minutes=pre)
    except Exception:
        return False

    # One-time with date
    if r.get('date') and r['repeat'] == REPEAT_NONE:
        try:
            d = datetime.date.fromisoformat(r['date'])
            alert = datetime.datetime.combine(d, alert.time())
        except Exception:
            return False

    diff = abs((now - alert).total_seconds())
    if diff > window:
        return False

    # Already fired today?
    if r.get('fired_at'):
        try:
            fired = datetime.datetime.fromisoformat(r['fired_at'])
            if (now - fired).total_seconds() < 3600:
                return False
        except Exception:
            pass

    # Check repeat day
    repeat = r.get('repeat', REPEAT_NONE)
    if repeat == REPEAT_NONE:
        return True
    if repeat == REPEAT_DAILY:
        return True
    if repeat == REPEAT_WEEKDAYS:
        return now.weekday() < 5   # Mon–Fri
    if repeat == REPEAT_WEEKEND:
        return now.weekday() >= 5
    if repeat == REPEAT_WEEKLY:
        # same weekday as created
        try:
            created = datetime.datetime.fromisoformat(r['created_at'])
            return now.weekday() == created.weekday()
        except Exception:
            return True
    if repeat == REPEAT_CUSTOM:
        days = r.get('repeat_days', [])
        return now.weekday() in (days if isinstance(days, list) else [])

    return False


def _row_to_dict(row) -> Dict:
    d = dict(row)
    for k in ('tags', 'repeat_days'):
        try:
            d[k] = json.loads(d[k] or '[]')
        except Exception:
            d[k] = []
    return d
