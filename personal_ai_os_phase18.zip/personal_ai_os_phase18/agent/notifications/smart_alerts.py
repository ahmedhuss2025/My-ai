# agent/notifications/smart_alerts.py — Phase 16
# ══════════════════════════════════════════════════
# Smart Alerts — تنبيهات ذكية مبنية على السياق
#
# يدمج:
#   • reminder_engine   — التذكيرات المجدولة
#   • ambient/user_profile — أنماط الاستخدام
#   • proactive_engine  — اقتراحات AI
#
# أنواع التنبيهات:
#   reminder  — تذكير عادي
#   habit     — عادة يومية متأخرة
#   meeting   — اجتماع قادم
#   idle      — المستخدم ما فتحش التطبيق زمان
#   summary   — ملخص يومي
#   battery   — بطارية ضعيفة (من Android)
# ══════════════════════════════════════════════════
import datetime
import json
from pathlib import Path
from typing import Dict, List, Optional

from . import reminder_engine as rem


# ── Alert model ───────────────────────────────────
class Alert:
    def __init__(self, alert_type: str, title: str, body: str,
                 priority: str = 'normal', action: str = '',
                 reminder_id: Optional[str] = None, data: dict = None):
        self.type        = alert_type
        self.title       = title
        self.body        = body
        self.priority    = priority
        self.action      = action
        self.reminder_id = reminder_id
        self.data        = data or {}
        self.ts          = datetime.datetime.now().isoformat()

    def to_dict(self) -> Dict:
        return {
            'type':        self.type,
            'title':       self.title,
            'body':        self.body,
            'priority':    self.priority,
            'action':      self.action,
            'reminder_id': self.reminder_id,
            'data':        self.data,
            'ts':          self.ts,
        }


# ══════════════════════════════════════════════════
class SmartAlertsEngine:
    """
    يجمع ويُرتّب التنبيهات من كل المصادر
    """

    PROFILE_PATH = Path('ambient/data/user_profile.json')
    LOG_PATH     = Path('notifications/data/alert_log.json')

    def __init__(self):
        self._sent_ids: set = set()
        self._load_log()

    # ── Main: get all pending alerts ──────────────
    def get_pending_alerts(self, window_seconds: int = 60) -> List[Alert]:
        alerts = []

        # 1. Due reminders
        alerts.extend(self._reminder_alerts(window_seconds))

        # 2. Habit alerts (missed daily habits)
        alerts.extend(self._habit_alerts())

        # 3. Daily summary (once per day at 21:00)
        daily = self._daily_summary_alert()
        if daily:
            alerts.append(daily)

        # Sort by priority
        priority_order = {'urgent': 0, 'high': 1, 'normal': 2, 'low': 3}
        alerts.sort(key=lambda a: priority_order.get(a.priority, 2))

        return alerts

    # ── Reminder alerts ───────────────────────────
    def _reminder_alerts(self, window: int) -> List[Alert]:
        alerts = []
        for r in rem.get_due_reminders(window_seconds=window):
            rid = r['id']
            if rid in self._sent_ids:
                continue

            # Emoji by priority
            emoji_map = {
                'urgent': '🚨', 'high': '🔔', 'normal': '🔔', 'low': '💬'
            }
            emoji = emoji_map.get(r.get('priority', 'normal'), '🔔')

            alert = Alert(
                alert_type  = 'reminder',
                title       = f"{emoji} {r['label']}",
                body        = _format_reminder_body(r),
                priority    = r.get('priority', 'normal'),
                action      = 'open_reminders',
                reminder_id = rid,
            )
            alerts.append(alert)
            self._sent_ids.add(rid)
            rem.log_fired(rid, 'fired')

        return alerts

    # ── Habit alerts ──────────────────────────────
    def _habit_alerts(self) -> List[Alert]:
        """تتحقق إذا المستخدم ما فتحش التطبيق للمرة الدايمة"""
        profile = self._load_profile()
        if not profile:
            return []

        last_seen_str = profile.get('last_seen')
        if not last_seen_str:
            return []

        try:
            last_seen = datetime.datetime.fromisoformat(last_seen_str)
        except Exception:
            return []

        hours_away = (datetime.datetime.now() - last_seen).total_seconds() / 3600

        # تنبيه بعد 8 ساعات غياب
        if hours_away >= 8:
            key = f'habit_idle_{datetime.date.today().isoformat()}'
            if key not in self._sent_ids:
                self._sent_ids.add(key)
                return [Alert(
                    alert_type = 'habit',
                    title      = '⚡ مساعدك في انتظارك',
                    body       = f'لم تفتح التطبيق منذ {int(hours_away)} ساعة. هل تريد مراجعة مهامك؟',
                    priority   = 'low',
                    action     = 'open_chat',
                )]

        return []

    # ── Daily summary ─────────────────────────────
    def _daily_summary_alert(self) -> Optional[Alert]:
        """ملخص يومي الساعة 9 مساءً"""
        now = datetime.datetime.now()
        if now.hour != 21 or now.minute > 5:
            return None

        key = f'daily_summary_{now.strftime("%Y%m%d")}'
        if key in self._sent_ids:
            return None
        self._sent_ids.add(key)

        stats = rem.get_stats()
        pending = stats.get('pending', 0)
        if pending == 0:
            return None

        return Alert(
            alert_type = 'summary',
            title      = '📝 ملخص يومك',
            body       = f'لديك {pending} تذكير غير مكتمل. هل تريد مراجعتها؟',
            priority   = 'low',
            action     = 'open_reminders',
        )

    # ── Utils ─────────────────────────────────────
    def _load_profile(self) -> Dict:
        if self.PROFILE_PATH.exists():
            try:
                return json.loads(self.PROFILE_PATH.read_text('utf-8'))
            except Exception:
                pass
        return {}

    def _load_log(self):
        if self.LOG_PATH.exists():
            try:
                data = json.loads(self.LOG_PATH.read_text('utf-8'))
                self._sent_ids = set(data.get('sent_ids', []))
            except Exception:
                self._sent_ids = set()

    def save_log(self):
        self.LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.LOG_PATH.write_text(
            json.dumps({'sent_ids': list(self._sent_ids)[-500:]}),
            encoding='utf-8'
        )

    def clear_sent(self):
        """يمسح cache الـ sent IDs"""
        self._sent_ids.clear()
        self.save_log()


# ── Singleton ──────────────────────────────────────
_engine = SmartAlertsEngine()


def get_pending(window_seconds: int = 60) -> List[Dict]:
    alerts = _engine.get_pending_alerts(window_seconds)
    _engine.save_log()
    return [a.to_dict() for a in alerts]


def clear_sent():
    _engine.clear_sent()


# ── Helper ────────────────────────────────────────
def _format_reminder_body(r: Dict) -> str:
    parts = []
    repeat = r.get('repeat', 'none')
    repeat_labels = {
        'daily':    'يومياً',
        'weekly':   'أسبوعياً',
        'weekdays': 'أيام العمل',
        'weekend':  'نهاية الأسبوع',
    }
    if repeat != 'none' and repeat in repeat_labels:
        parts.append(f'🔁 {repeat_labels[repeat]}')
    if r.get('note'):
        parts.append(r['note'])
    tags = r.get('tags', [])
    if tags:
        parts.append(' '.join(f'#{t}' for t in tags))
    return ' | '.join(parts) if parts else r.get('time', '')
