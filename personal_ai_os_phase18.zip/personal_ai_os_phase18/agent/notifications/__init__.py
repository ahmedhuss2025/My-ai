# agent/notifications/__init__.py — Phase 16
from . import reminder_engine
from . import smart_alerts

# Init DB on import
try:
    reminder_engine.init_db()
except Exception:
    pass
