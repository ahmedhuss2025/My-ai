# agent/ambient/user_profile.py — Phase 9
# ══════════════════════════════════════════════════
# ملف المستخدم الشخصي — يتعلم ويتذكر
# يُخزَّن محلياً في JSON، يُقرأ بالـ agent في كل محادثة
# ══════════════════════════════════════════════════
import json
import os
import datetime
from pathlib import Path
from typing import Optional

PROFILE_PATH = Path("ambient/data/user_profile.json")

# ── Default profile structure ─────────────────────
DEFAULT_PROFILE = {
    "name":         "",
    "language":     "ar",
    "timezone":     "Africa/Cairo",

    # عادات النوم
    "sleep": {
        "usual_sleep_hour":  23,   # الساعة اللي بيخد فيها الفون عادةً
        "usual_wake_hour":    7,   # الساعة اللي بيبدأ فيها يستخدم الفون
        "sleep_quality":    "unknown",   # good / fair / poor
    },

    # أوقات الذروة
    "peak_hours": {
        "most_active":  [9, 10, 11, 14, 15],   # ساعات النشاط الأعلى
        "least_active": [1, 2, 3, 4, 5],
    },

    # أكتر apps بيستخدمها
    "top_apps": [],   # [{"package": "com.whatsapp", "count": 42}, ...]

    # عادات المحادثة
    "conversation": {
        "avg_messages_per_day": 0,
        "favorite_topics":     [],    # ["تذكيرات", "بحث", ...]
        "response_style":      "friendly",   # formal / friendly / brief
        "language_mix":        "arabic",     # arabic / english / mixed
    },

    # إنتاجية
    "productivity": {
        "avg_tasks_done":    0,
        "streak_record":     0,
        "best_day":          "",
        "completion_rate":   0.0,   # 0.0 – 1.0
    },

    # تفضيلات مستنتجة
    "inferred_prefs": {
        "prefers_voice":    False,
        "prefers_short":    True,
        "morning_person":   True,
        "reminder_style":   "gentle",   # gentle / urgent
    },

    # metadata
    "created_at":    "",
    "updated_at":    "",
    "update_count":  0,
}


# ══════════════════════════════════════════════════
def load() -> dict:
    """يحمّل الـ profile — أو يرجّع default لو مش موجود"""
    PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    if PROFILE_PATH.exists():
        try:
            return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    p = dict(DEFAULT_PROFILE)
    p["created_at"] = _now()
    return p


def save(profile: dict) -> None:
    PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    profile["updated_at"]   = _now()
    profile["update_count"] = profile.get("update_count", 0) + 1
    PROFILE_PATH.write_text(
        json.dumps(profile, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ══════════════════════════════════════════════════
# UPDATE from analytics
# ══════════════════════════════════════════════════
def update_from_stats(
    avg_messages: float = 0,
    top_topics:   list  = None,
    streak:       int   = 0,
    completion:   float = 0.0,
    best_day:     str   = "",
    top_apps:     list  = None,
) -> dict:
    """يحدّث الـ profile بناءً على الإحصائيات الأسبوعية"""
    p = load()

    if avg_messages > 0:
        old = p["conversation"]["avg_messages_per_day"]
        # moving average
        p["conversation"]["avg_messages_per_day"] = round(
            old * 0.7 + avg_messages * 0.3, 1
        )

    if top_topics:
        # merge and keep top 10
        existing = set(p["conversation"]["favorite_topics"])
        existing.update(top_topics[:5])
        p["conversation"]["favorite_topics"] = list(existing)[:10]

    if streak > p["productivity"]["streak_record"]:
        p["productivity"]["streak_record"] = streak

    if completion > 0:
        p["productivity"]["completion_rate"] = round(completion, 2)

    if best_day:
        p["productivity"]["best_day"] = best_day

    if top_apps:
        p["top_apps"] = top_apps[:10]

    save(p)
    return p


def update_sleep_pattern(sleep_hour: int = None, wake_hour: int = None) -> dict:
    p = load()
    if sleep_hour is not None:
        old = p["sleep"]["usual_sleep_hour"]
        p["sleep"]["usual_sleep_hour"] = round(old * 0.8 + sleep_hour * 0.2)
    if wake_hour is not None:
        old = p["sleep"]["usual_wake_hour"]
        p["sleep"]["usual_wake_hour"] = round(old * 0.8 + wake_hour * 0.2)
    p["inferred_prefs"]["morning_person"] = (
        p["sleep"]["usual_wake_hour"] <= 7
    )
    save(p)
    return p


def update_peak_hours(active_hours: list) -> dict:
    """يحدّث أوقات الذروة بناءً على نمط الاستخدام"""
    p = load()
    if active_hours:
        # top 5 most active
        from collections import Counter
        c = Counter(active_hours)
        p["peak_hours"]["most_active"] = [h for h, _ in c.most_common(5)]
        all_hours = set(range(24))
        active_set = set(p["peak_hours"]["most_active"])
        least = sorted(all_hours - active_set)[:5]
        p["peak_hours"]["least_active"] = least
    save(p)
    return p


def infer_response_style(messages: list) -> dict:
    """يستنتج أسلوب الرد المفضّل من المحادثات"""
    p = load()
    if not messages:
        return p

    user_msgs = [m for m in messages if m.get("is_user") == 1]
    if not user_msgs:
        return p

    avg_len = sum(len(m.get("content", "")) for m in user_msgs) / len(user_msgs)
    p["inferred_prefs"]["prefers_short"] = avg_len < 30

    # لو معظم الرسائل عربي
    arabic_count = sum(
        1 for m in user_msgs
        if any("\u0600" <= c <= "\u06FF" for c in m.get("content", ""))
    )
    ratio = arabic_count / len(user_msgs)
    if ratio > 0.8:
        p["conversation"]["language_mix"] = "arabic"
    elif ratio < 0.2:
        p["conversation"]["language_mix"] = "english"
    else:
        p["conversation"]["language_mix"] = "mixed"

    save(p)
    return p


# ══════════════════════════════════════════════════
# SUMMARY for agent context injection
# ══════════════════════════════════════════════════
def to_agent_context(profile: dict = None) -> str:
    """
    يولّد نص مضغوط للـ agent يستخدمه في system prompt
    مثال:
      "المستخدم صاحي عادةً الساعة 7. أكتر وقت نشاط: 9–11 ص.
       يحب الردود المختصرة. أكتر توبيك: تذكيرات، بحث."
    """
    p = profile or load()

    lines = []

    wake = p["sleep"].get("usual_wake_hour", 7)
    sleep_hr = p["sleep"].get("usual_sleep_hour", 23)
    lines.append(f"يصحى عادةً الساعة {wake}:00 وينام الساعة {sleep_hr}:00.")

    peak = p["peak_hours"].get("most_active", [])
    if peak:
        peak_str = "، ".join(f"{h}:00" for h in peak[:3])
        lines.append(f"أكتر وقت نشاط: {peak_str}.")

    prefs = p.get("inferred_prefs", {})
    if prefs.get("prefers_short"):
        lines.append("يفضّل الردود المختصرة.")
    else:
        lines.append("يستجيب للردود المفصّلة.")

    if prefs.get("morning_person"):
        lines.append("شخص صباحي — النشاط الأعلى الصبح.")

    topics = p["conversation"].get("favorite_topics", [])
    if topics:
        lines.append(f"أكتر توبيكات: {', '.join(topics[:4])}.")

    streak = p["productivity"].get("streak_record", 0)
    rate   = p["productivity"].get("completion_rate", 0)
    if streak > 0:
        lines.append(f"أعلى streak: {streak} أيام. معدل الإنجاز: {int(rate*100)}%.")

    apps = p.get("top_apps", [])
    if apps:
        app_names = [a.get("name", a.get("package", "")).split(".")[-1] for a in apps[:3]]
        lines.append(f"أكتر apps: {', '.join(app_names)}.")

    return " ".join(lines)


def get_greeting_hint(profile: dict = None) -> str:
    """تحيّة مخصصة حسب الوقت وعادات المستخدم"""
    p = profile or load()
    now  = datetime.datetime.now()
    hour = now.hour
    peak = p["peak_hours"].get("most_active", [9, 10])

    if hour in peak:
        return "⚡ وقت ذروتك — إيه أهم حاجة النهارده؟"
    elif hour < p["sleep"].get("usual_wake_hour", 7) + 1:
        return "☀️ صباح النور! جاهز نبدأ؟"
    elif hour >= p["sleep"].get("usual_sleep_hour", 23):
        return "🌙 وقت الراحة — إيه آخر حاجة عايز تخلصها؟"
    elif hour >= 12 and hour < 15:
        return "🌤️ بعد الضهر — خليك منتج!"
    else:
        return "👋 أهلاً! بخدمتك."
