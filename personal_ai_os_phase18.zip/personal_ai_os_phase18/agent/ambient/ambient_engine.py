# agent/ambient/ambient_engine.py — Phase 9
# ══════════════════════════════════════════════════
# يحلّل بيانات الاستخدام من SQLite ويبني insights
# يشتغل في الخلفية — silent, privacy-first
# ══════════════════════════════════════════════════
import sqlite3
import json
import datetime
import os
from pathlib import Path
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Tuple

from . import user_profile as prof

# ── SQLite paths ──────────────────────────────────
DEFAULT_DB_PATHS = [
    "lora/data/personal_ai.db",
    os.path.expanduser("~/personal_ai.db"),
    "../data/personal_ai.db",
]

INSIGHTS_PATH = Path("ambient/data/insights.json")


def _find_db(hint: str = None) -> Optional[str]:
    if hint and os.path.exists(hint):
        return hint
    for p in DEFAULT_DB_PATHS:
        if os.path.exists(p):
            return p
    return None


# ══════════════════════════════════════════════════
# ANALYSIS FUNCTIONS
# ══════════════════════════════════════════════════
def _load_messages(db_path: str, days: int = 30) -> List[Dict]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
    rows = conn.execute(
        "SELECT content, is_user, timestamp, sentiment FROM messages "
        "WHERE timestamp >= ? ORDER BY timestamp ASC",
        (cutoff,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _load_daily_stats(db_path: str, days: int = 30) -> List[Dict]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
    rows = conn.execute(
        "SELECT date, messages, tasks_done, tasks_total, streak_days "
        "FROM daily_stats WHERE date >= ? ORDER BY date ASC",
        (cutoff,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _extract_hour(ts: str) -> Optional[int]:
    """استخرج الساعة من timestamp"""
    try:
        for fmt in ["%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%H:%M"]:
            try:
                return datetime.datetime.strptime(ts[:19], fmt).hour
            except ValueError:
                continue
    except Exception:
        pass
    return None


def _classify_topic(text: str) -> Optional[str]:
    """صنّف الرسالة لـ topic"""
    t = text.lower()
    if any(w in t for w in ["ذكر", "تذكير", "remind", "موعد"]):
        return "تذكيرات"
    if any(w in t for w in ["ابحث", "سعر", "أخبار", "search"]):
        return "بحث"
    if any(w in t for w in ["احسب", "calculate", "+", "-", "×", "÷"]):
        return "حسابات"
    if any(w in t for w in ["احفظ", "ملاحظة", "note"]):
        return "ملاحظات"
    if any(w in t for w in ["طقس", "weather", "حرارة"]):
        return "طقس"
    if any(w in t for w in ["شكر", "صباح", "مساء", "أهلا", "مرحبا"]):
        return "تحيات"
    if any(w in t for w in ["إنتاجية", "stats", "إحصائيات", "تقرير"]):
        return "إنتاجية"
    return None


# ══════════════════════════════════════════════════
# MAIN ANALYSIS
# ══════════════════════════════════════════════════
def analyze(db_path: str = None, days: int = 30) -> Dict:
    """
    يحلّل الـ 30 يوم الأخيرة ويبني insights
    يرجع dict بكل الـ insights
    """
    db = _find_db(db_path)
    if not db:
        return {"error": "no_db", "message": "personal_ai.db not found"}

    messages   = _load_messages(db, days)
    daily      = _load_daily_stats(db, days)
    user_msgs  = [m for m in messages if m.get("is_user") == 1]

    results = {}

    # ── 1. Activity hours ─────────────────────────
    hours = [_extract_hour(m["timestamp"]) for m in user_msgs]
    hours = [h for h in hours if h is not None]

    if hours:
        counter = Counter(hours)
        results["peak_hours"]   = [h for h, _ in counter.most_common(5)]
        results["active_hours"] = hours

        # Sleep / wake detection
        sorted_hours = sorted(hours)
        if sorted_hours:
            # أول رسالة الصبح = wake
            wake = min(h for h in hours if h >= 5)
            # آخر رسالة الليل = sleep
            night = [h for h in hours if h >= 20 or h < 4]
            sleep_hr = max(night) if night else 23
            results["usual_wake"]  = wake
            results["usual_sleep"] = sleep_hr

    # ── 2. Favorite topics ────────────────────────
    topics = [_classify_topic(m["content"]) for m in user_msgs]
    topics = [t for t in topics if t]
    topic_counter = Counter(topics)
    results["top_topics"] = [t for t, _ in topic_counter.most_common(6)]

    # ── 3. Daily message volume ───────────────────
    if daily:
        total_msgs  = sum(d.get("messages", 0) for d in daily)
        active_days = sum(1 for d in daily if d.get("messages", 0) > 0)
        results["avg_messages_per_day"] = round(total_msgs / max(active_days, 1), 1)
        results["total_active_days"]    = active_days

        # Best day
        best = max(daily, key=lambda d: d.get("messages", 0))
        results["best_day"] = best.get("date", "")

        # Streak
        results["streak_record"] = max((d.get("streak_days", 0) for d in daily), default=0)

        # Completion rate
        done  = sum(d.get("tasks_done",  0) for d in daily)
        total = sum(d.get("tasks_total", 0) for d in daily)
        results["completion_rate"] = round(done / max(total, 1), 2)
    else:
        results["avg_messages_per_day"] = 0
        results["streak_record"]        = 0
        results["completion_rate"]      = 0.0

    # ── 4. Sentiment trend ────────────────────────
    sentiments = [m.get("sentiment", 1) for m in messages if m.get("sentiment") is not None]
    if sentiments:
        avg_sent = sum(sentiments) / len(sentiments)
        results["avg_sentiment"] = round(avg_sent, 2)
        # -1=negative, 0=neutral, 1=positive
        results["mood_trend"] = (
            "إيجابي" if avg_sent > 0.3 else
            "محايد"  if avg_sent > -0.3 else
            "سلبي"
        )

    # ── 5. Inferred preferences ───────────────────
    if user_msgs:
        avg_len = sum(len(m["content"]) for m in user_msgs) / len(user_msgs)
        results["avg_msg_length"]    = round(avg_len, 1)
        results["prefers_short_msgs"] = avg_len < 35

    # ── 6. Weekly pattern ─────────────────────────
    weekday_counts = defaultdict(int)
    for m in user_msgs:
        try:
            ts  = m["timestamp"][:10]
            wd  = datetime.datetime.strptime(ts, "%Y-%m-%d").weekday()
            weekday_counts[wd] += 1
        except Exception:
            pass
    days_ar = ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]
    if weekday_counts:
        best_wd = max(weekday_counts, key=weekday_counts.get)
        results["most_active_weekday"] = days_ar[best_wd]

    results["analyzed_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    results["sample_size"] = len(user_msgs)

    return results


def run_and_update(db_path: str = None) -> Dict:
    """
    يحلّل ويحدّث user_profile تلقائياً
    يُستدعى بشكل دوري من server
    """
    insights = analyze(db_path)
    if "error" in insights:
        return insights

    # Update profile
    prof.update_from_stats(
        avg_messages = insights.get("avg_messages_per_day", 0),
        top_topics   = insights.get("top_topics", []),
        streak       = insights.get("streak_record", 0),
        completion   = insights.get("completion_rate", 0.0),
        best_day     = insights.get("best_day", ""),
    )

    if "usual_wake" in insights:
        prof.update_sleep_pattern(
            sleep_hour = insights.get("usual_sleep"),
            wake_hour  = insights.get("usual_wake"),
        )

    if "active_hours" in insights:
        prof.update_peak_hours(insights["active_hours"])

    # Cache insights
    INSIGHTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    INSIGHTS_PATH.write_text(
        json.dumps(insights, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    return insights


def get_cached_insights() -> Dict:
    """يرجّع آخر insights محسوبة"""
    if INSIGHTS_PATH.exists():
        try:
            return json.loads(INSIGHTS_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def generate_insight_cards(insights: Dict = None) -> List[Dict]:
    """
    يولّد بطاقات Insights جاهزة للعرض في الـ Dashboard
    كل بطاقة: {"icon", "title", "subtitle", "color"}
    """
    d = insights or get_cached_insights()
    if not d:
        return []

    cards = []

    # Mood
    mood = d.get("mood_trend", "")
    if mood:
        icon  = "😊" if mood == "إيجابي" else "😐" if mood == "محايد" else "😔"
        cards.append({
            "icon":     icon,
            "title":    f"مزاج {mood}",
            "subtitle": "بناءً على تحليل محادثاتك",
            "color":    "green" if mood == "إيجابي" else "orange",
        })

    # Peak hours
    peak = d.get("peak_hours", [])
    if peak:
        peak_str = f"{peak[0]}:00–{peak[min(2, len(peak)-1)]}:00"
        cards.append({
            "icon":     "⚡",
            "title":    f"ذروة نشاطك {peak_str}",
            "subtitle": "خلي المهام المهمة في الوقت ده",
            "color":    "cyan",
        })

    # Streak
    streak = d.get("streak_record", 0)
    if streak > 0:
        cards.append({
            "icon":     "🔥",
            "title":    f"أعلى streak: {streak} أيام",
            "subtitle": "استمر وكسّر الرقم!",
            "color":    "orange",
        })

    # Best weekday
    best_wd = d.get("most_active_weekday", "")
    if best_wd:
        cards.append({
            "icon":     "📅",
            "title":    f"أنشط أيامك: {best_wd}",
            "subtitle": "ركّز فيه على المهام الكبيرة",
            "color":    "purple",
        })

    # Topics
    topics = d.get("top_topics", [])
    if topics:
        top2 = " + ".join(topics[:2])
        cards.append({
            "icon":     "🧠",
            "title":    f"اهتماماتك: {top2}",
            "subtitle": f"من تحليل {d.get('sample_size', 0)} رسالة",
            "color":    "blue",
        })

    # Completion rate
    rate = d.get("completion_rate", 0)
    if rate > 0:
        pct = int(rate * 100)
        cards.append({
            "icon":     "✅",
            "title":    f"معدل الإنجاز {pct}%",
            "subtitle": "نسبة المهام اللي خلّصتها",
            "color":    "green" if pct >= 70 else "orange",
        })

    return cards[:5]   # بنعرض 5 بطاقات بس
