# agent/notification_service.py — Phase 16 (upgraded)
# ══════════════════════════════════════════════════
# Notification Service — upgraded to use reminder_engine + smart_alerts
# يشتغل كـ background thread داخل server.py
# ══════════════════════════════════════════════════
import json
import time
import datetime
import threading
import subprocess
from typing import List, Dict

# Phase 16 engines
try:
    from notifications import reminder_engine as rem_eng
    from notifications import smart_alerts as sa
    _NOTIF_ENGINE = True
except ImportError:
    rem_eng = None
    sa      = None
    _NOTIF_ENGINE = False

_sent_ids = set()   # fallback for legacy tools._reminders


class NotificationService:
    CHECK_INTERVAL = 30   # seconds

    def __init__(self, tools_module=None):
        self._tools   = tools_module
        self._running = False
        self._thread: threading.Thread = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name='NotificationService')
        self._thread.start()
        print('🔔 Notification service started (Phase 16 engine)')

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self):
        while self._running:
            try:
                self._check()
            except Exception as e:
                print(f'[NotifService] error: {e}')
            time.sleep(self.CHECK_INTERVAL)

    def _check(self):
        # ── Phase 16: smart alerts engine ────────
        if _NOTIF_ENGINE and sa:
            alerts = sa.get_pending(window_seconds=self.CHECK_INTERVAL + 5)
            for alert in alerts:
                self._send(alert['title'], alert['body'],
                           priority=alert.get('priority', 'normal'))
            return

        # ── Fallback: legacy tools._reminders ────
        now = datetime.datetime.now()
        reminders = self._get_pending_reminders()
        for r in reminders:
            rid   = r.get('id', '')
            label = r.get('label', 'تذكير')
            t_str = r.get('time', '00:00')
            pre   = int(r.get('pre_alert', 10))
            if rid in _sent_ids:
                continue
            try:
                h, m = map(int, t_str.split(':'))
                remind_dt = now.replace(hour=h, minute=m, second=0, microsecond=0)
                alert_dt  = remind_dt - datetime.timedelta(minutes=pre)
            except ValueError:
                continue
            if abs((now - alert_dt).total_seconds()) <= 30:
                self._send(f'🔔 تذكير — {t_str}', label)
                _sent_ids.add(rid)

    def _get_pending_reminders(self) -> List[Dict]:
        if self._tools and hasattr(self._tools, '_reminders'):
            return self._tools._reminders
        return []

    def _send(self, title: str, body: str, priority: str = 'normal'):
        print(f'\n{"─"*40}')
        print(f'📲 NOTIFICATION: {title}')
        print(f'   {body}')
        print(f'{"─"*40}')
        self._send_adb(title, body)
        self._send_http(title, body, priority)

    def _send_adb(self, title: str, body: str):
        try:
            result = subprocess.run(
                ['adb','shell','am','broadcast','-a',
                 'com.personalai.NOTIFICATION',
                 '--es','title', title, '--es','body', body],
                capture_output=True, timeout=5)
            if result.returncode == 0:
                print('   ✅ ADB notification sent')
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    def _send_http(self, title: str, body: str, priority: str = 'normal'):
        try:
            import urllib.request
            data = json.dumps({'title': title, 'body': body,
                               'priority': priority}).encode()
            req  = urllib.request.Request(
                'http://localhost:7070/notify', data=data,
                headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass


# ── Singleton ────────────────────────────────────
_service = NotificationService()

def start(tools_module=None):
    _service._tools = tools_module
    _service.start()

def stop():
    _service.stop()
