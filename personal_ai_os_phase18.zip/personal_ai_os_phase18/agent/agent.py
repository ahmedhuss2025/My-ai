# agent/agent.py
# ══════════════════════════════════════════════════
# Personal AI OS — ReAct Agent
# نفس الـ loop مع Claude و Gemma
# ══════════════════════════════════════════════════
import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Any

from backends.base import LLMBackend, LLMResponse
from backends.claude import ClaudeBackend
from backends.gemma import GemmaBackend
import tools
import memory as mem_module


# ══════════════════════════════════════════════════
# AGENT RESULT — structured response
# ══════════════════════════════════════════════════
@dataclass
class AgentResult:
    text:          str
    tools_used:    List[str]      = field(default_factory=list)
    tool_outputs:  Dict[str, str] = field(default_factory=dict)
    sentiment:     int            = 1
    behaviors:     List[str]      = field(default_factory=list)
    reminder_id:   str | None     = None
    note_id:       str | None     = None
    should_speak:  bool           = False   # ← Phase 5: TTS

    def to_dict(self) -> Dict[str, Any]:
        return {
            "response":     self.text,
            "tools_used":   self.tools_used,
            "tool_outputs": self.tool_outputs,
            "sentiment":    self.sentiment,
            "behaviors":    self.behaviors,
            "reminder_id":  self.reminder_id,
            "note_id":      self.note_id,
            "should_speak": self.should_speak,
        }


# ── Sentiment from text ───────────────────────────
def _infer_sentiment(user_input: str, response_text: str) -> int:
    t = (user_input + " " + response_text).lower()
    if any(w in t for w in ["ممتاز","رائع","شكراً","تمام","✅","🔥","🎉"]): return 0
    if any(w in t for w in ["مشغول","عاجل","ضروري","urgent"]):              return 2
    if any(w in t for w in ["تعبان","متعب","نعسان"]):                        return 3
    if any(w in t for w in ["مشكلة","خطأ","❌","صعب","تعبت"]):              return 4
    return 1


def _infer_behaviors(user_input: str) -> List[str]:
    t = user_input.lower()
    b = []
    if any(w in t for w in ["؟","?"]):                                 b.append("يحتاج معلومة")
    if any(w in t for w in ["ابحث","دور","search"]):                   b.append("يريد بحث")
    if any(w in t for w in ["ذكرني","تذكير","remind"]):                b.append("يريد تذكير")
    if any(w in t for w in ["احفظ","ملاحظة","note"]):                  b.append("يريد حفظ")
    if any(w in t for w in ["احسب","calculate"]):                      b.append("يريد حساب")
    if any(w in t for w in ["إحصائيات","stats","تقرير"]):              b.append("يريد تقرير")
    return b


def _should_speak(user_input: str, response_text: str, tools_used: List[str]) -> bool:
    """
    يحدد لو الـ agent لازم يرد صوتاً
    - رسائل قصيرة من المستخدم → غالباً voice query
    - ردود قصيرة من الـ agent  → مناسب للصوت
    - reminders/greetings       → دايماً بالصوت
    - بيانات كتير / أرقام       → متكلمش
    """
    t_in  = user_input.lower()
    t_out = response_text.lower()

    # دايماً بالصوت
    if any(w in t_in for w in ["صباح","مساء","أخبارك","عامل إيه"]):
        return True
    if "set_reminder" in tools_used:
        return True   # تأكيد التذكير بالصوت

    # متكلمش لو في بيانات كتير
    if len(response_text) > 300:
        return False
    if any(w in t_out for w in ["•", "①", "②", "③", "جنيه", "%"]) and len(response_text) > 150:
        return False

    # ردود قصيرة → بالصوت
    if len(response_text) < 120:
        return True

    return False


class Agent:
    """
    ReAct loop:
      while not done:
          response = backend.complete(system, messages, tools)
          if response.done → return response.text
          for each tool_call:
              result = tools.run(call.name, call.args)
              messages.append(tool_result)
    """

    MAX_ROUNDS = 6

    def __init__(self, backend: LLMBackend, memory: mem_module.AgentMemory = None):
        self.backend = backend
        self.memory  = memory or mem_module.AgentMemory()
        print(f"🤖 Agent ready — backend: {backend.name}")
        print(f"   available: {backend.is_available()}\n")

    # ── System prompt ─────────────────────────────
    def _system(self, query: str) -> str:
        now = datetime.datetime.now()
        hour_ar = "صباحاً" if now.hour < 12 else ("ظهراً" if now.hour < 15 else "مساءً")
        return (
            f"أنت Personal AI OS — مساعد شخصي يعمل محلياً على الفون.\n\n"
            f"الوقت: {now.strftime('%H:%M')} {hour_ar}، {now.strftime('%A %d/%m/%Y')}\n\n"
            f"{self.memory.context_str(query)}\n\n"
            f"== قواعد ==\n"
            f"- ردودك دائماً بالعربي\n"
            f"- مختصر ومفيد\n"
            f"- استخدم tool لو محتاج معلومة حقيقية\n"
            f"- لو ناقصك معلومة → اسأل بدل ما تخمّن"
        )

    # ── Main run ──────────────────────────────────
    def run(self, user_input: str, verbose: bool = True) -> AgentResult:
        if verbose:
            print(f"{'═'*52}")
            print(f"👤  {user_input}")
            print(f"{'═'*52}")

        self.memory.add_user(user_input)
        messages = self.memory.to_messages()

        tool_schemas = (
            tools.schemas_for_claude()
            if isinstance(self.backend, ClaudeBackend)
            else []
        )

        system = self._system(user_input)

        # ── Tracking ──────────────────────────────
        tools_used:   List[str]      = []
        tool_outputs: Dict[str, str] = {}
        reminder_id:  str | None     = None
        note_id:      str | None     = None

        # ── ReAct loop ────────────────────────────
        for rnd in range(1, self.MAX_ROUNDS + 1):

            if verbose:
                print(f"\n[Round {rnd}]", end=" ", flush=True)

            response: LLMResponse = self.backend.complete(
                system=system,
                messages=messages,
                tools=tool_schemas,
            )

            # ── DONE ─────────────────────────────
            if response.done:
                if verbose:
                    print(f"done ✓")
                    print(f"\n🤖  {response.text}\n")
                self.memory.add_agent(response.text)

                return AgentResult(
                    text         = response.text,
                    tools_used   = tools_used,
                    tool_outputs = tool_outputs,
                    sentiment    = _infer_sentiment(user_input, response.text),
                    behaviors    = _infer_behaviors(user_input),
                    reminder_id  = reminder_id,
                    note_id      = note_id,
                    should_speak = _should_speak(user_input, response.text, tools_used),
                )

            # ── TOOL CALLS ────────────────────────
            if verbose:
                print(f"{len(response.tool_calls)} tool call(s)")

            messages.append({
                "role":    "assistant",
                "content": response.raw.content if hasattr(response.raw, "content") else "",
            })

            tool_results = []
            for call in (response.tool_calls or []):
                if verbose:
                    print(f"  ⚡  {call.name}({call.args})")

                result = tools.run(call.name, call.args)
                self.memory.add_tool(call.name, result)

                # ── Track ─────────────────────────
                tools_used.append(call.name)
                tool_outputs[call.name] = result

                # extract IDs for side effects
                import re
                if call.name == "set_reminder":
                    m = re.search(r"REM_\d+", result)
                    if m: reminder_id = m.group()
                elif call.name == "save_note":
                    m = re.search(r"NOTE_\d+", result)
                    if m: note_id = m.group()

                if verbose:
                    short = result[:120] + ("…" if len(result) > 120 else "")
                    print(f"  👁️  {short}")

                tool_results.append({
                    "type":        "tool_result",
                    "tool_use_id": call.id,
                    "content":     result,
                })

            messages.append({"role": "user", "content": tool_results})

        # max rounds hit
        fallback = "⚠️ وصلت لأقصى عدد جولات — قولي أكتر وأحاول تاني."
        self.memory.add_agent(fallback)
        return AgentResult(
            text       = fallback,
            tools_used = tools_used,
            sentiment  = 4,   # متوتر — حاجة غلط
        )

    # ── Conversation reset ────────────────────────
    def reset(self):
        self.memory.end_session()
        print("🔄  محادثة جديدة")


# ══════════════════════════════════════════════════
# FACTORY — اختار backend تلقائياً
# ══════════════════════════════════════════════════
def make_agent(
    prefer: str = "auto",          # "claude" | "gemma" | "auto"
    api_key: str = None,
    gemma_url: str = "http://localhost:8080/generate",
) -> Agent:
    """
    prefer="auto":
      - لو في API key → Claude
      - لو Gemma server شغال → Gemma
      - وإلا → Gemma fallback (offline rules)
    """
    memory = mem_module.AgentMemory()

    if prefer == "claude":
        return Agent(ClaudeBackend(api_key=api_key), memory)

    if prefer == "gemma":
        return Agent(GemmaBackend(gemma_url), memory)

    # auto
    claude = ClaudeBackend(api_key=api_key)
    if claude.is_available():
        print("✅  Anthropic API key موجود → Claude backend")
        return Agent(claude, memory)

    print("⚠️  مفيش API key → Gemma backend (offline fallback)")
    return Agent(GemmaBackend(gemma_url), memory)
