# agent/analytics/insights_builder.py — Phase 17
# ══════════════════════════════════════════════════
# Insights Builder — يولّد ملاحظات ذكية من البيانات
# ══════════════════════════════════════════════════
import datetime
from typing import List, Dict
from . import analytics_engine as ae


def build_insights() -> List[Dict]:
    """
    يولّد قائمة من الـ insights بناءً على البيانات
    كل insight: { type, emoji, title, body, priority }
    """
    insights = []
    week     = ae.get_weekly_stats()
    totals   = ae.get_totals()
    today    = ae.get_daily_stats()
    heatmap  = ae.get_hourly_heatmap()
    features = ae.get_feature_breakdown()
    streak   = totals.get('streak', 0)

    # ── Streak insight ────────────────────────────
    if streak >= 7:
        insights.append({
            'type':     'streak',
            'emoji':    '🔥',
            'title':    f'{streak} يوم متواصل!',
            'body':     f'أنت تستخدم مساعدك يومياً منذ {streak} يوم. استمر!',
            'priority': 'high',
        })
    elif streak >= 3:
        insights.append({
            'type':     'streak',
            'emoji':    '⚡',
            'title':    f'سلسلة {streak} أيام',
            'body':     'أنت على المسار الصحيح. حاول الوصول لـ 7 أيام!',
            'priority': 'normal',
        })

    # ── Most active hour ──────────────────────────
    if heatmap:
        peak_hour = max(heatmap, key=lambda h: heatmap[h])
        peak_cnt  = heatmap[peak_hour]
        if peak_cnt > 0:
            hour_int  = int(peak_hour)
            time_str  = f'{"صباحاً" if hour_int < 12 else "مساءً"} ' \
                        f'{hour_int if hour_int <= 12 else hour_int-12}:00'
            insights.append({
                'type':     'peak_time',
                'emoji':    '🕐',
                'title':    f'ساعة الذروة: {time_str}',
                'body':     f'أنت أكثر نشاطاً في الساعة {peak_hour}:00. '
                            f'جدوِل مهامك الكبيرة في هذا الوقت.',
                'priority': 'normal',
            })

    # ── Weekly trend ──────────────────────────────
    if len(week) >= 7:
        msgs_week = [d.get('messages_sent', 0) for d in week]
        avg_msgs  = sum(msgs_week) / max(len(msgs_week), 1)
        today_msgs= today.get('messages_sent', 0)
        if today_msgs > avg_msgs * 1.5 and avg_msgs > 0:
            insights.append({
                'type':     'trend',
                'emoji':    '📈',
                'title':    'نشاط أعلى من المعتاد',
                'body':     f'أرسلت {today_msgs} رسالة اليوم مقارنة بمتوسط '
                            f'{avg_msgs:.0f} يومياً هذا الأسبوع.',
                'priority': 'normal',
            })

    # ── Feature usage tips ────────────────────────
    total_events = sum(features.values())
    if total_events > 0:
        voice_pct = features.get('voice', 0) / total_events * 100
        if voice_pct < 10 and total_events > 20:
            insights.append({
                'type':     'tip',
                'emoji':    '🎙️',
                'title':    'جرّب الإدخال الصوتي',
                'body':     'أنت نادراً ما تستخدم الصوت. '
                            'جرّبه للمهام السريعة — أسرع بـ 3x من الكتابة!',
                'priority': 'low',
            })
        img_pct = features.get('image', 0) / total_events * 100
        if img_pct < 5 and total_events > 30:
            insights.append({
                'type':     'tip',
                'emoji':    '🎨',
                'title':    'ابدأ مع توليد الصور',
                'body':     'جرّب توليد الصور بالذكاء الاصطناعي. '
                            'اكتب وصفاً وسيرسم لك المساعد!',
                'priority': 'low',
            })

    # ── Milestone ─────────────────────────────────
    total_msgs = totals.get('total_messages', 0)
    milestones = [10, 50, 100, 500, 1000, 5000]
    for m in milestones:
        if total_msgs >= m:
            prev = milestones[milestones.index(m)-1] if milestones.index(m) > 0 else 0
            if total_msgs - today.get('messages_sent', 0) < m:
                insights.append({
                    'type':     'milestone',
                    'emoji':    '🏆',
                    'title':    f'إنجاز: {m} رسالة!',
                    'body':     f'تهانيّ! وصلت لـ {total_msgs} رسالة إجمالاً.',
                    'priority': 'high',
                })

    # ── Reminders completion rate ─────────────────
    rem_done    = totals.get('total_reminders_done', 0)
    rem_created = ae.get_totals().get('total_messages', 0)  # reuse
    if rem_done > 5:
        insights.append({
            'type':     'productivity',
            'emoji':    '✅',
            'title':    f'أكملت {rem_done} تذكير',
            'body':     'أنت منتظم في إنجاز مهامك. استمر على هذا المنوال!',
            'priority': 'normal',
        })

    # Default if empty
    if not insights:
        insights.append({
            'type':     'welcome',
            'emoji':    '👋',
            'title':    'ابدأ رحلتك',
            'body':     'ابدأ باستخدام مساعدك وسترى إحصاءاتك هنا قريباً.',
            'priority': 'low',
        })

    return insights
