# agent/analytics/analytics_engine.py — Phase 17
# ══════════════════════════════════════════════════
# Analytics Engine
# يتتبع استخدام التطبيق ويولّد إحصاءات
#
# يتتبع:
#   • عدد المحادثات ومتوسط طولها
#   • استخدام الـ features (chat/voice/meetings/images)
#   • أوقات الذروة
#   • streak الاستخدام اليومي
#   • أكثر المواضيع تكراراً
# ══════════════════════════════════════════════════
import sqlite3
import json
import datetime
import secrets
from pathlib import Path
from typing import Dict, List, Optional
from collections import defaultdict

DB_PATH = Path('analytics/data/analytics.db')


# ══════════════════════════════════════════════════
def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS events (
            id         TEXT PRIMARY KEY,
            type       TEXT NOT NULL,    -- chat/voice/meeting/image/reminder/search
            subtype    TEXT DEFAULT '',  -- create/view/complete/etc
            value      REAL DEFAULT 1,   -- duration_s / count / etc
            meta       TEXT DEFAULT '{}',-- JSON extra data
            ts         TEXT NOT NULL,
            date       TEXT NOT NULL     -- YYYY-MM-DD
        );

        CREATE TABLE IF NOT EXISTS daily_summary (
            date              TEXT PRIMARY KEY,
            messages_sent     INTEGER DEFAULT 0,
            voice_sessions    INTEGER DEFAULT 0,
            meetings          INTEGER DEFAULT 0,
            images_generated  INTEGER DEFAULT 0,
            reminders_created INTEGER DEFAULT 0,
            reminders_done    INTEGER DEFAULT 0,
            active_minutes    INTEGER DEFAULT 0,
            streak_day        INTEGER DEFAULT 0,
            updated_at        TEXT
        );
    ''')
    conn.commit()
    conn.close()


# ══════════════════════════════════════════════════
# Track events
# ══════════════════════════════════════════════════
def track(event_type: str, subtype: str = '',
          value: float = 1.0, meta: dict = None):
    now  = datetime.datetime.now()
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute(
        'INSERT INTO events(id,type,subtype,value,meta,ts,date) VALUES(?,?,?,?,?,?,?)',
        (secrets.token_hex(4), event_type, subtype,
         value, json.dumps(meta or {}),
         now.isoformat(), now.strftime('%Y-%m-%d'))
    )
    conn.commit(); conn.close()
    _update_daily(event_type, subtype, value, now.strftime('%Y-%m-%d'))


def _update_daily(event_type: str, subtype: str,
                  value: float, date: str):
    conn = sqlite3.connect(str(DB_PATH))
    # Ensure row exists
    conn.execute(
        'INSERT OR IGNORE INTO daily_summary(date,updated_at) VALUES(?,?)',
        (date, datetime.datetime.now().isoformat())
    )
    col = {
        'chat':     'messages_sent',
        'voice':    'voice_sessions',
        'meeting':  'meetings',
        'image':    'images_generated',
        'reminder_create': 'reminders_created',
        'reminder_done':   'reminders_done',
    }.get(event_type)

    if col:
        conn.execute(
            f'UPDATE daily_summary SET {col}={col}+1, updated_at=? WHERE date=?',
            (datetime.datetime.now().isoformat(), date)
        )
    conn.commit(); conn.close()


# ══════════════════════════════════════════════════
# Aggregations
# ══════════════════════════════════════════════════
def get_daily_stats(date: Optional[str] = None) -> Dict:
    d    = date or datetime.date.today().isoformat()
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    row  = conn.execute(
        'SELECT * FROM daily_summary WHERE date=?', (d,)).fetchone()
    conn.close()
    if row:
        return dict(row)
    return {'date': d, 'messages_sent': 0, 'voice_sessions': 0,
            'meetings': 0, 'images_generated': 0,
            'reminders_created': 0, 'reminders_done': 0,
            'active_minutes': 0, 'streak_day': 0}


def get_weekly_stats() -> List[Dict]:
    """7 أيام من اليوم"""
    today  = datetime.date.today()
    result = []
    conn   = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    for i in range(6, -1, -1):
        d   = (today - datetime.timedelta(days=i)).isoformat()
        row = conn.execute(
            'SELECT * FROM daily_summary WHERE date=?', (d,)).fetchone()
        if row:
            result.append(dict(row))
        else:
            result.append({'date': d, 'messages_sent': 0,
                           'voice_sessions': 0, 'meetings': 0,
                           'images_generated': 0, 'active_minutes': 0})
    conn.close()
    return result


def get_monthly_stats() -> List[Dict]:
    """30 يوم"""
    today  = datetime.date.today()
    conn   = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    start  = (today - datetime.timedelta(days=29)).isoformat()
    rows   = conn.execute(
        'SELECT * FROM daily_summary WHERE date>=? ORDER BY date',
        (start,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_hourly_heatmap(days: int = 7) -> Dict[str, int]:
    """توزيع الاستخدام على ساعات اليوم"""
    since = (datetime.datetime.now() -
             datetime.timedelta(days=days)).isoformat()
    conn  = sqlite3.connect(str(DB_PATH))
    rows  = conn.execute(
        "SELECT strftime('%H', ts) as hour, COUNT(*) as cnt "
        "FROM events WHERE ts>=? GROUP BY hour", (since,)
    ).fetchall()
    conn.close()
    heatmap = {str(h).zfill(2): 0 for h in range(24)}
    for row in rows:
        heatmap[row[0]] = row[1]
    return heatmap


def get_feature_breakdown(days: int = 30) -> Dict[str, int]:
    """كم مرة استُخدمت كل feature"""
    since = (datetime.datetime.now() -
             datetime.timedelta(days=days)).isoformat()
    conn  = sqlite3.connect(str(DB_PATH))
    rows  = conn.execute(
        'SELECT type, COUNT(*) as cnt FROM events WHERE ts>=? GROUP BY type',
        (since,)
    ).fetchall()
    conn.close()
    return {r[0]: r[1] for r in rows}


def get_streak() -> int:
    """عدد الأيام المتتالية في الاستخدام"""
    today  = datetime.date.today()
    streak = 0
    conn   = sqlite3.connect(str(DB_PATH))
    for i in range(365):
        d   = (today - datetime.timedelta(days=i)).isoformat()
        row = conn.execute(
            'SELECT messages_sent+voice_sessions+meetings FROM daily_summary WHERE date=?',
            (d,)).fetchone()
        if row and row[0] > 0:
            streak += 1
        else:
            break
    conn.close()
    return streak


def get_totals() -> Dict:
    conn = sqlite3.connect(str(DB_PATH))
    row  = conn.execute('''
        SELECT
            SUM(messages_sent)     as total_messages,
            SUM(voice_sessions)    as total_voice,
            SUM(meetings)          as total_meetings,
            SUM(images_generated)  as total_images,
            SUM(reminders_done)    as total_reminders_done,
            COUNT(*)               as active_days
        FROM daily_summary
        WHERE messages_sent+voice_sessions+meetings+images_generated > 0
    ''').fetchone()
    conn.close()
    if row:
        return {
            'total_messages':       row[0] or 0,
            'total_voice':          row[1] or 0,
            'total_meetings':       row[2] or 0,
            'total_images':         row[3] or 0,
            'total_reminders_done': row[4] or 0,
            'active_days':          row[5] or 0,
            'streak':               get_streak(),
        }
    return {'total_messages': 0, 'active_days': 0, 'streak': 0}


def get_full_report() -> Dict:
    return {
        'today':     get_daily_stats(),
        'week':      get_weekly_stats(),
        'totals':    get_totals(),
        'heatmap':   get_hourly_heatmap(),
        'features':  get_feature_breakdown(),
        'generated_at': datetime.datetime.now().isoformat(),
    }
