# agent/analytics/__init__.py — Phase 17
from . import analytics_engine
from . import insights_builder

try:
    analytics_engine.init_db()
except Exception:
    pass
