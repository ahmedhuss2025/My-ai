#!/usr/bin/env python3
# agent/lora/lora_status.py — Phase 8
# ══════════════════════════════════════════════════
# تتبع حالة التدريب — server يقرأ منه Flutter
# ══════════════════════════════════════════════════
import json
import os
import time
from pathlib import Path
from datetime import datetime

STATUS_FILE = Path("lora/data/training_status.json")

# States
IDLE       = "idle"
EXPORTING  = "exporting"
TRAINING   = "training"
MERGING    = "merging"
DONE       = "done"
ERROR      = "error"


def _read():
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "state":       IDLE,
        "progress":    0,
        "message":     "لم يبدأ التدريب بعد",
        "samples":     0,
        "steps_done":  0,
        "steps_total": 0,
        "model_path":  "",
        "updated_at":  "",
        "error":       "",
    }


def _write(data):
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = datetime.now().strftime("%H:%M:%S")
    STATUS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get() -> dict:
    return _read()


def set_state(state, message="", progress=0, **kwargs):
    d = _read()
    d["state"]    = state
    d["message"]  = message
    d["progress"] = progress
    d.update(kwargs)
    _write(d)


def set_progress(steps_done, steps_total, loss=None):
    d = _read()
    d["steps_done"]  = steps_done
    d["steps_total"] = steps_total
    d["progress"]    = int(100 * steps_done / max(steps_total, 1))
    d["state"]       = TRAINING
    if loss is not None:
        d["last_loss"] = round(loss, 4)
    _write(d)


def set_done(model_path, samples):
    set_state(DONE,
        message   = "التدريب اكتمل ✅",
        progress  = 100,
        model_path = str(model_path),
        samples    = samples,
    )


def set_error(msg):
    set_state(ERROR, message=f"خطأ: {msg}", progress=0, error=msg)


def reset():
    set_state(IDLE, message="جاهز للتدريب", progress=0,
              samples=0, steps_done=0, steps_total=0,
              model_path="", error="")
