#!/usr/bin/env python3
# agent/lora/train_lora.py — Phase 8
# ══════════════════════════════════════════════════
# LoRA Fine-tuning على Gemma 2B-IT
# يستخدم Unsloth للتدريب السريع (2x speed, 70% less VRAM)
#
# المتطلبات (PC مع GPU):
#   pip install unsloth[colab-new]
#   pip install trl datasets
#
# الاستخدام:
#   python lora/train_lora.py --data data/train.jsonl
#   python lora/train_lora.py --data data/train.jsonl --steps 100
# ══════════════════════════════════════════════════
import argparse
import json
import os
import sys
from pathlib import Path
from datetime import datetime

# ── Config defaults ───────────────────────────────
DEFAULT_MODEL    = "google/gemma-2b-it"   # HuggingFace model ID
DEFAULT_OUT_DIR  = "lora_adapter"
DEFAULT_STEPS    = 150
DEFAULT_BATCH    = 4
DEFAULT_LR       = 2e-4
DEFAULT_SEQ_LEN  = 512

LORA_R       = 16
LORA_ALPHA   = 32
LORA_DROPOUT = 0.05
TARGET_MODS  = ["q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj"]

ALPACA_TEMPLATE = """### Instruction:
{instruction}

### Input:
{input}

### Response:
{output}"""


# ══════════════════════════════════════════════════
# Check dependencies
# ══════════════════════════════════════════════════
def check_deps():
    missing = []
    for pkg in ["unsloth", "trl", "datasets", "torch"]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    return missing


def check_gpu():
    try:
        import torch
        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory / 1e9
            return True, f"{gpu} ({vram:.1f}GB VRAM)"
        return False, "No GPU — CPU only (very slow)"
    except ImportError:
        return False, "torch not installed"


# ══════════════════════════════════════════════════
# Load JSONL dataset
# ══════════════════════════════════════════════════
def load_jsonl(path):
    samples = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                obj = json.loads(line)
                # Format as Alpaca prompt
                text = ALPACA_TEMPLATE.format(
                    instruction = obj.get("instruction", ""),
                    input       = obj.get("input", ""),
                    output      = obj.get("output", ""),
                )
                samples.append({"text": text})
    return samples


# ══════════════════════════════════════════════════
# TRAIN
# ══════════════════════════════════════════════════
def train(
    data_path,
    model_id    = DEFAULT_MODEL,
    out_dir     = DEFAULT_OUT_DIR,
    max_steps   = DEFAULT_STEPS,
    batch_size  = DEFAULT_BATCH,
    lr          = DEFAULT_LR,
    seq_len     = DEFAULT_SEQ_LEN,
):
    print("\n" + "═"*50)
    print("🧠 Personal AI OS — LoRA Fine-tuning")
    print("═"*50)

    # 1. Check GPU
    has_gpu, gpu_info = check_gpu()
    print(f"\n🖥️  GPU: {gpu_info}")
    if not has_gpu:
        print("⚠️  تدريب بدون GPU هيكون بطيء جداً")
        print("   نصيحة: استخدم Google Colab مع T4 GPU (مجاني)")

    # 2. Load Unsloth model
    print(f"\n📥 Loading model: {model_id}")
    from unsloth import FastLanguageModel

    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name    = model_id,
        max_seq_length = seq_len,
        dtype          = None,   # auto detect
        load_in_4bit   = True,   # 4-bit quantization
    )

    # 3. Add LoRA adapters
    print("🔧 Adding LoRA adapters...")
    model = FastLanguageModel.get_peft_model(
        model,
        r              = LORA_R,
        target_modules = TARGET_MODS,
        lora_alpha     = LORA_ALPHA,
        lora_dropout   = LORA_DROPOUT,
        bias           = "none",
        use_gradient_checkpointing = True,
        random_state   = 42,
    )

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total     = sum(p.numel() for p in model.parameters())
    print(f"   Trainable params: {trainable:,} / {total:,} ({100*trainable/total:.2f}%)")

    # 4. Load dataset
    print(f"\n📊 Loading dataset: {data_path}")
    samples = load_jsonl(data_path)
    print(f"   Samples: {len(samples)}")

    from datasets import Dataset
    dataset = Dataset.from_list(samples)

    # 5. Tokenize
    def tokenize_fn(examples):
        return tokenizer(
            examples["text"],
            truncation = True,
            max_length = seq_len,
            padding    = False,
        )

    dataset = dataset.map(tokenize_fn, batched=True, remove_columns=["text"])

    # 6. Train
    from trl import SFTTrainer
    from transformers import TrainingArguments

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n🚀 Training — {max_steps} steps")
    print(f"   Batch size : {batch_size}")
    print(f"   LR         : {lr}")
    print(f"   Output     : {out_dir}")
    print()

    training_args = TrainingArguments(
        output_dir              = str(out_dir / "checkpoints"),
        max_steps               = max_steps,
        per_device_train_batch_size = batch_size,
        gradient_accumulation_steps = 4,
        warmup_steps            = 10,
        learning_rate           = lr,
        fp16                    = has_gpu,
        bf16                    = False,
        logging_steps           = 10,
        save_steps              = 50,
        save_total_limit        = 2,
        optim                   = "adamw_8bit" if has_gpu else "adamw_torch",
        seed                    = 42,
        report_to               = "none",
    )

    trainer = SFTTrainer(
        model            = model,
        tokenizer        = tokenizer,
        train_dataset    = dataset,
        dataset_text_field = "input_ids",
        max_seq_length   = seq_len,
        args             = training_args,
    )

    start = datetime.now()
    trainer.train()
    elapsed = (datetime.now() - start).total_seconds()
    print(f"\n⏱️  Training took: {elapsed/60:.1f} minutes")

    # 7. Save adapter
    adapter_path = out_dir / "adapter"
    print(f"\n💾 Saving LoRA adapter → {adapter_path}")
    model.save_pretrained(str(adapter_path))
    tokenizer.save_pretrained(str(adapter_path))

    print("\n✅ Training complete!")
    print(f"   Adapter saved: {adapter_path}")
    print(f"\nالخطوة الجاية:")
    print(f"   python lora/merge_lora.py --adapter {adapter_path}")


# ══════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="LoRA Fine-tuning for Personal AI OS")
    parser.add_argument("--data",    required=True,            help="JSONL training file")
    parser.add_argument("--model",   default=DEFAULT_MODEL,   help="Base model ID")
    parser.add_argument("--out",     default=DEFAULT_OUT_DIR,  help="Output directory")
    parser.add_argument("--steps",   type=int, default=DEFAULT_STEPS, help="Training steps")
    parser.add_argument("--batch",   type=int, default=DEFAULT_BATCH, help="Batch size")
    parser.add_argument("--lr",      type=float, default=DEFAULT_LR,  help="Learning rate")
    parser.add_argument("--seq-len", type=int, default=DEFAULT_SEQ_LEN, help="Max seq length")
    parser.add_argument("--check-only", action="store_true", help="Check deps only")
    args = parser.parse_args()

    # Check dependencies first
    missing = check_deps()
    if missing:
        print("❌ مكتبات ناقصة:")
        for m in missing:
            print(f"   pip install {m}")
        if args.check_only:
            sys.exit(1)
        print("\nتثبيت المكتبات:")
        print("  pip install 'unsloth[colab-new]' trl datasets")
        sys.exit(1)

    if args.check_only:
        has_gpu, gpu_info = check_gpu()
        print(f"✅ All deps installed")
        print(f"🖥️  GPU: {gpu_info}")
        sys.exit(0)

    if not os.path.exists(args.data):
        print(f"❌ مش لاقي: {args.data}")
        print("   شغّل الأول: python lora/export_training_data.py")
        sys.exit(1)

    train(
        data_path  = args.data,
        model_id   = args.model,
        out_dir    = args.out,
        max_steps  = args.steps,
        batch_size = args.batch,
        lr         = args.lr,
        seq_len    = args.seq_len,
    )
