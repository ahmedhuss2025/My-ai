#!/usr/bin/env python3
# agent/lora/merge_lora.py — Phase 8
# ══════════════════════════════════════════════════
# يدمج LoRA adapter مع base model
# النتيجة: ملف .bin واحد جاهز للـ Android (MediaPipe)
#
# الاستخدام:
#   python lora/merge_lora.py --adapter lora_adapter/adapter
#   python lora/merge_lora.py --adapter lora_adapter/adapter --quantize
# ══════════════════════════════════════════════════
import argparse
import os
import sys
from pathlib import Path


def check_deps():
    missing = []
    for pkg in ["unsloth", "torch"]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    return missing


def merge(adapter_path, out_dir="lora_merged", quantize=False):
    print("\n" + "═"*50)
    print("🔀 Merging LoRA adapter → Full model")
    print("═"*50)

    adapter_path = Path(adapter_path)
    if not adapter_path.exists():
        print(f"❌ مش لاقي: {adapter_path}")
        sys.exit(1)

    print(f"\n📥 Loading adapter: {adapter_path}")
    from unsloth import FastLanguageModel

    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name    = str(adapter_path),
        max_seq_length = 512,
        dtype          = None,
        load_in_4bit   = True,
    )

    # Merge adapter weights into model
    print("🔀 Merging weights...")
    model = model.merge_and_unload()

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    if quantize:
        # Save as GGUF (للـ llama.cpp على Android)
        print(f"\n⚙️  Quantizing to 4-bit GGUF...")
        try:
            model.save_pretrained_gguf(
                str(out_path),
                tokenizer,
                quantization_method = "q4_k_m",
            )
            print(f"✅ GGUF saved: {out_path}")
        except Exception as e:
            print(f"⚠️  GGUF failed: {e}")
            print("   Saving as HuggingFace format instead")
            model.save_pretrained(str(out_path))
            tokenizer.save_pretrained(str(out_path))
    else:
        print(f"\n💾 Saving merged model → {out_path}")
        model.save_pretrained(str(out_path))
        tokenizer.save_pretrained(str(out_path))

    print(f"\n✅ Done! Merged model: {out_path}")
    print("\nالخطوة الجاية:")
    print("  انقل الـ .bin للفون:")
    print(f"  adb push {out_path}/*.bin /sdcard/models/gemma-finetuned.bin")
    print("\nفي التطبيق:")
    print("  الإعدادات → LoRA → تفعيل الموديل المدرَّب")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Merge LoRA adapter with base Gemma model")
    parser.add_argument("--adapter",  required=True,        help="Path to LoRA adapter folder")
    parser.add_argument("--out",      default="lora_merged", help="Output directory")
    parser.add_argument("--quantize", action="store_true",   help="Export as 4-bit GGUF")
    args = parser.parse_args()

    missing = check_deps()
    if missing:
        print("❌ مكتبات ناقصة:")
        for m in missing:
            print(f"   pip install {m}")
        sys.exit(1)

    merge(args.adapter, args.out, args.quantize)
