#!/usr/bin/env python3
# agent/lora/export_training_data.py — Phase 8
# ══════════════════════════════════════════════════
# يصدّر بيانات التدريب من SQLite → JSONL
# Format: Alpaca (instruction / input / output)
#
# الاستخدام:
#   python lora/export_training_data.py
#   python lora/export_training_data.py --db /path/to/personal_ai.db
#   python lora/export_training_data.py --min-pairs 50 --out data/train.jsonl
# ══════════════════════════════════════════════════
import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

# ── Android DB default paths (after adb pull) ─────
DEFAULT_DB_PATHS = [
    "data/personal_ai.db",
    os.path.expanduser("~/personal_ai.db"),
]

SYSTEM_PROMPT = (
    "أنت Personal AI OS — مساعد شخصي يعمل محلياً على هاتف المستخدم. "
    "ردودك دائماً بالعربية. مختصر ومفيد. تعرف صاحبك وتتذكر عاداته."
)


# ══════════════════════════════════════════════════
def find_db(hint=None):
    if hint and os.path.exists(hint):
        return hint
    for p in DEFAULT_DB_PATHS:
        if os.path.exists(p):
            return p
    return None


def load_messages(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, content, is_user, timestamp, sentiment "
        "FROM messages ORDER BY timestamp ASC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def load_notes(db_path):
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT title, content, tags FROM notes"
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def load_reminders(db_path):
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT label, time FROM reminders ORDER BY time"
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ══════════════════════════════════════════════════
# Build conversation pairs
# ══════════════════════════════════════════════════
def build_pairs(messages):
    pairs = []
    i = 0
    while i < len(messages) - 1:
        m = messages[i]
        if m["is_user"] == 1:
            j = i + 1
            while j < len(messages) and messages[j]["is_user"] == 1:
                j += 1
            if j < len(messages) and messages[j]["is_user"] == 0:
                user_text  = m["content"].strip()
                agent_text = messages[j]["content"].strip()
                if len(user_text) >= 3 and len(agent_text) >= 5:
                    pairs.append({
                        "instruction": SYSTEM_PROMPT,
                        "input":       user_text,
                        "output":      agent_text,
                        "sentiment":   m.get("sentiment", 1),
                    })
                i = j + 1
                continue
        i += 1
    return pairs


def build_note_samples(notes):
    samples = []
    for n in notes:
        if n["content"] and len(n["content"]) > 20:
            samples.append({
                "instruction": SYSTEM_PROMPT,
                "input":  "احفظ ملاحظة: " + n["title"],
                "output": "✅ تمام — حفظت الملاحظة '" + n["title"] + "':\n" + n["content"][:200],
                "sentiment": 1,
            })
    return samples


def build_reminder_samples(reminders):
    return [{
        "instruction": SYSTEM_PROMPT,
        "input":  "ذكرني بـ " + r["label"] + " الساعة " + r["time"],
        "output": "🔔 تمام — هذكّرك بـ " + r["label"] + " الساعة " + r["time"] + " ✅",
        "sentiment": 1,
    } for r in reminders]


def augment_samples(pairs):
    augmented = []
    seen = set()
    variations = {
        "كيف": "إيه",
        "ماذا": "إيه",
        "متى":  "امتى",
        "هل":   "هو",
    }
    for p in pairs:
        key = p["input"][:40]
        if key not in seen:
            augmented.append(p)
            seen.add(key)
            modified = p["input"]
            for orig, alt in variations.items():
                if orig in modified:
                    modified = modified.replace(orig, alt, 1)
                    break
            if modified != p["input"]:
                aug = dict(p)
                aug["input"] = modified
                augmented.append(aug)
    return augmented


def synthetic_baseline():
    return [
        {"instruction": SYSTEM_PROMPT, "input": "صباح الخير",
         "output": "☀️ صباح النور! إيه أول حاجة النهارده؟", "sentiment": 0},
        {"instruction": SYSTEM_PROMPT, "input": "مساء الخير",
         "output": "🌙 مساء الخير! إيه اللي عملته النهارده؟", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "شكراً",
         "output": "💙 العفو دايماً! أي وقت محتاجني أنا هنا.", "sentiment": 0},
        {"instruction": SYSTEM_PROMPT, "input": "ذكرني باجتماع الساعة 3",
         "output": "🔔 تمام — هذكّرك بالاجتماع الساعة 3 ✅", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "الوقت كام؟",
         "output": "⏰ دلوقتي الساعة " + datetime.now().strftime("%H:%M"), "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "احفظ ملاحظة: فكرة مشروع",
         "output": "📝 تمام — حفظت الملاحظة ✅", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "2 + 2 كام؟",
         "output": "🔢 2 + 2 = 4", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "تذكيراتي إيه؟",
         "output": "🔔 مفيش تذكيرات دلوقتي — عايز تضيف تذكير جديد؟", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "سعر الدولار كام؟",
         "output": "🔍 هبحثلك دلوقتي...", "sentiment": 1},
        {"instruction": SYSTEM_PROMPT, "input": "إيه إنتاجيتي النهارده؟",
         "output": "📊 هجيبلك إحصائيات النهارده...", "sentiment": 1},
    ]


def write_jsonl(samples, path):
    with open(path, "w", encoding="utf-8") as f:
        for s in samples:
            obj = {
                "instruction": s["instruction"],
                "input":       s["input"],
                "output":      s["output"],
            }
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")


# ══════════════════════════════════════════════════
# MAIN EXPORT
# ══════════════════════════════════════════════════
def export(db_path, out_path="data/train.jsonl", min_pairs=20, augment=True, split=True):
    print(f"📂 Reading DB: {db_path}")
    messages  = load_messages(db_path)
    notes     = load_notes(db_path)
    reminders = load_reminders(db_path)
    print(f"   Messages  : {len(messages)}")
    print(f"   Notes     : {len(notes)}")
    print(f"   Reminders : {len(reminders)}")

    pairs    = build_pairs(messages)
    all_samp = pairs + build_note_samples(notes) + build_reminder_samples(reminders)
    if augment:
        all_samp = augment_samples(all_samp)

    filtered = [
        s for s in all_samp
        if len(s["input"]) >= 3
        and len(s["output"]) >= 5
        and not s["output"].startswith("❌")
    ]
    print(f"\n📊 Samples after filter: {len(filtered)}")

    if len(filtered) < min_pairs:
        print(f"⚠️  أقل من {min_pairs} samples — إضافة baseline")
        filtered += synthetic_baseline()
        print(f"   Total with baseline: {len(filtered)}")

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if split and len(filtered) >= 10:
        split_idx = int(len(filtered) * 0.9)
        train_data = filtered[:split_idx]
        val_data   = filtered[split_idx:]
        write_jsonl(train_data, out_path)
        write_jsonl(val_data,   out_path.with_suffix(".val.jsonl"))
        print(f"\n✅ Train: {out_path}  ({len(train_data)} samples)")
        print(f"   Val  : {out_path.with_suffix('.val.jsonl')}  ({len(val_data)} samples)")
    else:
        write_jsonl(filtered, out_path)
        print(f"\n✅ Saved: {out_path}  ({len(filtered)} samples)")

    return {"total": len(filtered), "path": str(out_path)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Export training data from SQLite → JSONL")
    parser.add_argument("--db",        default=None,               help="Path to personal_ai.db")
    parser.add_argument("--out",       default="data/train.jsonl", help="Output JSONL file")
    parser.add_argument("--min-pairs", type=int, default=20,       help="Minimum sample count")
    parser.add_argument("--no-aug",    action="store_true",        help="Disable augmentation")
    parser.add_argument("--no-split",  action="store_true",        help="No train/val split")
    args = parser.parse_args()

    db = find_db(args.db)
    if not db:
        print("❌ مش لاقي personal_ai.db")
        print("   استخدم:")
        print("   adb pull /data/data/com.personalai.os/databases/personal_ai.db data/")
        sys.exit(1)

    result = export(
        db_path   = db,
        out_path  = args.out,
        min_pairs = args.min_pairs,
        augment   = not args.no_aug,
        split     = not args.no_split,
    )
    print(f"\n🎯 جاهز للتدريب — {result['total']} samples")
