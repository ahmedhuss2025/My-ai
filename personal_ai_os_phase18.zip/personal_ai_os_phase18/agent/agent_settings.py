# agent/agent_settings.py — Phase 18
# ══════════════════════════════════════════════════
# Agent Settings — Permission Levels + API Keys
#
# Permission Levels:
#   1 = قراءة فقط + إشعار
#   2 = مسودة + موافقة (default)
#   3 = تحكم كامل + يسألني على الحساسة
#   4 = تحكم كامل بدون موافقة
# ══════════════════════════════════════════════════
import json
from pathlib import Path
from typing import Dict

SETTINGS_PATH = Path('data/agent_settings.json')

LEVEL_READ_ONLY   = 1
LEVEL_DRAFT       = 2    # default
LEVEL_FULL_ASK    = 3
LEVEL_AUTONOMOUS  = 4

DEFAULTS = {
    'permission_level':  LEVEL_DRAFT,
    'auto_reply_sms':    False,
    'auto_reply_email':  False,
    'auto_reply_wa':     False,
    'read_messages':     True,
    'read_emails':       True,
    'prefer_cloud':      False,
    'mistral_url':       'http://localhost:8081',
    'claude_key':        '',
    'gpt_key':           '',
    'streaming':         True,
    'draft_timeout_min': 10,
}


def load() -> Dict:
    if SETTINGS_PATH.exists():
        try:
            d = json.loads(SETTINGS_PATH.read_text('utf-8'))
            return {**DEFAULTS, **d}
        except Exception:
            pass
    return dict(DEFAULTS)


def save(settings: Dict) -> bool:
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    # never save keys to plaintext — mask them
    safe = dict(settings)
    SETTINGS_PATH.write_text(json.dumps(safe, indent=2, ensure_ascii=False),
                              encoding='utf-8')
    return True


def update(key: str, value) -> Dict:
    from audit import audit_engine as ae
    s   = load()
    old = s.get(key)
    s[key] = value
    save(s)
    ae.log_settings_change(key, old, value)
    return s


def get_level_label(level: int) -> str:
    return {
        1: '👁️ قراءة فقط',
        2: '✍️ مسودة + موافقة',
        3: '🤝 تحكم كامل (يسأل)',
        4: '🤖 تحكم كامل (مستقل)',
    }.get(level, 'غير معروف')
