# agent/memory.py
# ══════════════════════════════════════════════════
# 3-layer memory — working / episodic / semantic
# ══════════════════════════════════════════════════
import datetime
from dataclasses import dataclass, field
from typing import Any, Dict, List


# ── Turn — رسالة واحدة ────────────────────────────
@dataclass
class Turn:
    role:      str           # user | agent | tool | thought
    content:   str
    tool_name: str = ""
    ts:        str = field(
        default_factory=lambda: datetime.datetime.now().strftime("%H:%M")
    )


# ── Memory item ───────────────────────────────────
@dataclass
class Item:
    text:       str
    importance: float        # 0.0 → 1.0
    tags:       List[str]
    hits:       int = 0      # كام مرة اتبحث عنها

    def score(self) -> float:
        return self.importance + self.hits * 0.05


# ══════════════════════════════════════════════════
class AgentMemory:
    """
    working  → المحادثة الحالية (cleared per session)
    episodic → أحداث مهمة من محادثات سابقة
    semantic → profile ثابت عن المستخدم
    """

    def __init__(self, window: int = 20):
        self._turns:    List[Turn] = []
        self._episodic: List[Item] = []
        self._window = window

        # ── semantic: user profile ────────────────
        self.profile: Dict[str, Any] = {
            "name":       "المستخدم",
            "occupation": "مطوّر",
            "project":    "Personal AI OS",
            "skills":     ["Flutter", "Python", "Android"],
            "language":   "arabic",
            "peak_hours": [9, 10, 11],
        }

        # seed some episodic memories
        self._seed()

    # ── Working memory ops ────────────────────────

    def add_user(self, text: str):
        self._push(Turn("user", text))

    def add_agent(self, text: str):
        self._push(Turn("agent", text))

    def add_thought(self, text: str):
        self._push(Turn("thought", text))

    def add_tool(self, name: str, result: str):
        self._push(Turn("tool", result, tool_name=name))

    def _push(self, t: Turn):
        self._turns.append(t)
        if len(self._turns) > self._window:
            self._turns = self._turns[-self._window:]

    # ── Build messages for LLM ────────────────────

    def to_messages(self) -> List[Dict]:
        """تحويل للـ messages format (Claude / OpenAI compatible)"""
        out = []
        for t in self._turns:
            if t.role in ("thought",):
                continue                          # thoughts داخلية بس
            if t.role == "tool":
                out.append({
                    "role":    "user",
                    "content": f"[نتيجة {t.tool_name}]: {t.content}",
                })
            elif t.role == "agent":
                out.append({"role": "assistant", "content": t.content})
            else:
                out.append({"role": "user",      "content": t.content})
        return out

    # ── Context string for system prompt ──────────

    def context_str(self, query: str = "") -> str:
        parts = [
            f"المستخدم: {self.profile['name']} | {self.profile['occupation']}",
            f"المشروع: {self.profile['project']}",
            f"Skills: {', '.join(self.profile['skills'])}",
        ]

        # Phase 9 — inject ambient user profile if available
        try:
            from ambient import user_profile as ambient_prof
            ambient_ctx = ambient_prof.to_agent_context()
            if ambient_ctx:
                parts.append(f"\n🧠 ملف المستخدم المتعلَّم: {ambient_ctx}")
            hint = ambient_prof.get_greeting_hint()
            if hint:
                parts.append(f"💡 اقتراح تحية مناسبة: {hint}")
        except ImportError:
            pass

        mems = self.recall(query) if query else []
        if mems:
            parts.append("\nذكريات ذات صلة:")
            for m in mems:
                parts.append(f"  • {m.text}")
        return "\n".join(parts)

    # ── Episodic memory ───────────────────────────

    def remember(self, text: str, importance: float = 0.6, tags: List[str] = None):
        self._episodic.append(Item(text, importance, tags or []))
        # keep top 150 by score
        if len(self._episodic) > 150:
            self._episodic.sort(key=lambda i: i.score(), reverse=True)
            self._episodic = self._episodic[:150]

    def recall(self, query: str, k: int = 3) -> List[Item]:
        words = set(query.lower().split())
        scored = []
        for item in self._episodic:
            overlap = words & (set(item.text.lower().split()) | set(item.tags))
            if overlap:
                scored.append((len(overlap) * 0.5 + item.score(), item))
        scored.sort(reverse=True)
        results = [i for _, i in scored[:k]]
        for i in results:
            i.hits += 1
        return results

    # ── Session boundary ──────────────────────────

    def end_session(self):
        """في نهاية المحادثة — احفظ المهم في episodic"""
        for t in self._turns:
            if t.role == "user" and any(
                w in t.content for w in ["عايز","هدف","مشروع","تعلم","أكره","بحب"]
            ):
                self.remember(t.content, importance=0.7, tags=["user_intent"])
        self._turns.clear()

    def _seed(self):
        seeds = [
            ("المستخدم يعمل على Flutter app للـ AI",         0.9, ["project","flutter"]),
            ("المستخدم عايز يفهم الـ agents بعمق",            0.8, ["goal","ai","agents"]),
            ("إنتاجيته الأعلى من 9 للـ 11 الصبح",            0.7, ["productivity"]),
            ("مش بيحب الـ boilerplate code",                  0.6, ["preference"]),
            ("بيتعلم Kotlin للـ Android native bridge",       0.75, ["learning","kotlin"]),
        ]
        for text, imp, tags in seeds:
            self.remember(text, imp, tags)
