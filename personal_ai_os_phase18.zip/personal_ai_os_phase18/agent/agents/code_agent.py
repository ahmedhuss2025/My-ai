# agent/agents/code_agent.py — Phase 10
# ══════════════════════════════════════════════════
# Code Agent — حسابات + ملاحظات + مهام تقنية
# متخصص في:
#   - الحسابات الرياضية
#   - حفظ الملاحظات التقنية
#   - الإجابات المنطقية
# ══════════════════════════════════════════════════
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from .base_agent import BaseSubAgent, SubAgentResult
import tools as tools_mod

_CODE_KEYWORDS = [
    # حسابات
    "احسب", "calculate", "كام", "يساوي", "equals", "ناتج",
    "+", "-", "×", "÷", "*", "/", "^", "√",
    "بالمية", "%", "ضرب", "جمع", "طرح", "قسمة",
    # ملاحظات
    "احفظ", "سجّل", "note", "ملاحظة", "دوّن", "اكتب",
    # إحصائيات
    "إحصائياتي", "stats", "إنتاجية", "productivity",
    "كام رسالة", "كام مهمة",
]

_MATH_RE = re.compile(
    r"[\d\+\-\*\/\^\(\)\.\s×÷√%]+"
)


class CodeAgent(BaseSubAgent):

    @property
    def name(self) -> str:
        return "Code Agent"

    @property
    def domain(self) -> str:
        return "حسابات وملاحظات"

    @property
    def emoji(self) -> str:
        return "⚙️"

    def can_handle(self, query: str) -> float:
        q = query.lower()
        # لو في عمليات رياضية واضحة
        if self._has_math(query):
            return 0.95
        hits = sum(1 for kw in _CODE_KEYWORDS if kw in q)
        if hits >= 2:
            return 0.85
        if hits == 1:
            return 0.55
        return 0.0

    def run(self, query: str, context: str = "") -> SubAgentResult:
        print(f"  ⚙️  CodeAgent: {query[:50]}")
        q = query.lower()
        tools_used = []

        # ── حسابات ───────────────────────────────
        if self._has_math(query) or any(w in q for w in ["احسب", "calculate", "ناتج", "يساوي"]):
            expr = self._extract_expr(query)
            if expr:
                result = tools_mod.run("calculate", {"expression": expr})
                tools_used.append("calculate")
                return SubAgentResult(
                    agent_name=self.name,
                    text=result,
                    tools_used=tools_used,
                    confidence=0.95,
                )

        # ── إحصائيات ─────────────────────────────
        if any(w in q for w in ["إحصائياتي", "stats", "إنتاجية", "كام رسالة", "اليوم"]):
            result = tools_mod.run("get_stats", {"period": "today"})
            tools_used.append("get_stats")
            return SubAgentResult(
                agent_name=self.name,
                text=result,
                tools_used=tools_used,
                confidence=0.90,
            )

        # ── حفظ ملاحظة ───────────────────────────
        if any(w in q for w in ["احفظ", "سجّل", "note", "ملاحظة", "دوّن", "اكتب"]):
            title, content = self._extract_note(query)
            if content:
                result = tools_mod.run("save_note", {
                    "title":   title,
                    "content": content,
                    "tags":    "phase10",
                })
                tools_used.append("save_note")
                return SubAgentResult(
                    agent_name=self.name,
                    text=result,
                    tools_used=tools_used,
                    confidence=0.88,
                )

        return SubAgentResult(
            agent_name=self.name,
            text="⚙️ محتاج تفاصيل أكتر — هل تريد حساب أو حفظ ملاحظة؟",
            tools_used=[],
            confidence=0.3,
        )

    def _has_math(self, text: str) -> bool:
        # هل في أرقام وعمليات؟
        has_num = bool(re.search(r"\d", text))
        has_op  = any(op in text for op in ["+", "-", "*", "/", "×", "÷", "^", "%", "ضرب", "جمع", "طرح", "مضروب", "مقسوم"])
        return has_num and has_op

    def _extract_expr(self, text: str) -> str:
        """استخرج المعادلة الرياضية"""
        # استبدل العربي بالرموز
        t = text.replace("×", "*").replace("÷", "/").replace("√", "sqrt(")
        t = t.replace("ضرب", "*").replace("جمع", "+").replace("طرح", "-")
        t = t.replace("مقسوم على", "/").replace("مضروب في", "*")
        # احذف الكلمات
        for word in ["احسب", "calculate", "ناتج", "إيه", "يساوي", "كام"]:
            t = t.replace(word, " ")
        # استخرج المعادلة
        m = _MATH_RE.search(t)
        if m:
            expr = m.group(0).strip()
            # تنظيف
            expr = re.sub(r"\s+", "", expr)
            if len(expr) >= 3:
                return expr
        return ""

    def _extract_note(self, query: str) -> tuple[str, str]:
        """استخرج عنوان + محتوى من الـ query"""
        for trigger in ["احفظ ملاحظة:", "احفظ:", "سجّل:", "note:", "اكتب:"]:
            if trigger in query.lower():
                rest = query.split(":", 1)[1].strip()
                # أول جملة = title
                parts = rest.split("—") if "—" in rest else rest.split("\n")
                title   = parts[0].strip()[:50]
                content = rest
                return title, content
        # fallback
        content = query.replace("احفظ", "").replace("ملاحظة", "").strip()
        return "ملاحظة سريعة", content
