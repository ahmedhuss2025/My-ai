# agent/agents/research_agent.py — Phase 10
# ══════════════════════════════════════════════════
# Research Agent — بحث + summarize
# متخصص في:
#   - البحث عن معلومات وأسعار وأخبار
#   - تلخيص المحتوى
#   - الإجابة على أسئلة factual
# ══════════════════════════════════════════════════
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from .base_agent import BaseSubAgent, SubAgentResult
import tools as tools_mod


_RESEARCH_KEYWORDS = [
    # بحث
    "ابحث", "بحث", "search", "ابحثلي", "فين", "where",
    # سعر
    "سعر", "price", "كام", "how much", "تكلفة", "cost",
    # معلومة
    "معلومة", "info", "ما هو", "ايه", "إيه", "what is",
    # أخبار
    "أخبار", "news", "جديد", "latest", "آخر",
    # طقس
    "طقس", "weather", "حرارة", "temperature",
    # شرح
    "اشرحلي", "وضّح", "explain", "كيف", "how",
]

_SYSTEM_PROMPT = """أنت Research Agent متخصص.
مهمتك: ابحث وارجّع معلومات دقيقة ومختصرة.
- استخدم search tool للمعلومات الحديثة
- لخّص النتائج بوضوح
- ذكر المصدر لو متاح
- الرد بالعربية دايماً"""


class ResearchAgent(BaseSubAgent):

    @property
    def name(self) -> str:
        return "Research Agent"

    @property
    def domain(self) -> str:
        return "بحث ومعلومات"

    @property
    def emoji(self) -> str:
        return "🔍"

    def can_handle(self, query: str) -> float:
        q = query.lower()
        hits = sum(1 for kw in _RESEARCH_KEYWORDS if kw in q)
        if hits >= 3:
            return 0.95
        if hits == 2:
            return 0.80
        if hits == 1:
            return 0.55
        return 0.0

    def run(self, query: str, context: str = "") -> SubAgentResult:
        print(f"  🔍 ResearchAgent: {query[:50]}")

        # استدعي search tool
        search_result = tools_mod.run("search", {"query": query})
        tools_used = ["search"]

        # صيغ الرد
        if search_result and not search_result.startswith("❌"):
            text = f"🔍 **نتيجة البحث**\n\n{search_result}"
        else:
            # fallback — رد مباشر
            text = self._direct_answer(query)

        return SubAgentResult(
            agent_name = self.name,
            text       = text,
            tools_used = tools_used,
            confidence = 0.85,
        )

    def _direct_answer(self, query: str) -> str:
        q = query.lower()
        if "طقس" in q or "weather" in q:
            return "⛅ مش قادر أجيب الطقس دلوقتي — تأكد من اتصال الإنترنت"
        if "سعر" in q or "price" in q:
            return "💰 مش قادر أجيب الأسعار دلوقتي — جرّب تاني"
        return f"🔍 بحثت عن: '{query}' — محتاج إنترنت للنتائج الحية"
