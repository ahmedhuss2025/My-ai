# agent/agents/base_agent.py — Phase 10
# ══════════════════════════════════════════════════
# Base class لكل الـ sub-agents
# كل agent عنده:
#   - اسم واضح
#   - مجال تخصص (domain)
#   - يعرف يتعامل مع طلب معين؟ (can_handle)
#   - ينفّذ الطلب (run)
# ══════════════════════════════════════════════════
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import datetime


@dataclass
class SubAgentResult:
    """نتيجة sub-agent"""
    agent_name:  str
    text:        str
    tools_used:  List[str]    = field(default_factory=list)
    confidence:  float        = 1.0     # 0.0 – 1.0
    metadata:    Dict         = field(default_factory=dict)
    error:       str          = ""
    elapsed_ms:  int          = 0

    @property
    def ok(self) -> bool:
        return not self.error and bool(self.text)

    def to_dict(self) -> dict:
        return {
            "agent":      self.agent_name,
            "text":       self.text,
            "tools_used": self.tools_used,
            "confidence": self.confidence,
            "error":      self.error,
            "elapsed_ms": self.elapsed_ms,
        }


class BaseSubAgent(ABC):
    """
    Interface مشترك لكل الـ sub-agents.
    كل sub-agent يرث منه ويطبّق:
      - domain: str
      - can_handle(query) → float (0–1 confidence)
      - run(query, context) → SubAgentResult
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """اسم الـ agent"""
        ...

    @property
    @abstractmethod
    def domain(self) -> str:
        """مجال التخصص"""
        ...

    @property
    @abstractmethod
    def emoji(self) -> str:
        """أيقونة للـ UI"""
        ...

    @abstractmethod
    def can_handle(self, query: str) -> float:
        """
        كام الـ confidence إن الـ agent ده يقدر يتعامل مع الطلب؟
        0.0 = مش مناسب
        1.0 = مناسب تماماً
        """
        ...

    @abstractmethod
    def run(self, query: str, context: str = "") -> SubAgentResult:
        """نفّذ الطلب وارجّع النتيجة"""
        ...

    def _timed_run(self, query: str, context: str = "") -> SubAgentResult:
        """wrapper يقيس الوقت"""
        start = datetime.datetime.now()
        try:
            result = self.run(query, context)
            elapsed = int((datetime.datetime.now() - start).total_seconds() * 1000)
            result.elapsed_ms = elapsed
            return result
        except Exception as e:
            elapsed = int((datetime.datetime.now() - start).total_seconds() * 1000)
            return SubAgentResult(
                agent_name = self.name,
                text       = "",
                error      = str(e),
                elapsed_ms = elapsed,
            )
