# agent/agents/schedule_agent.py — Phase 10
# ══════════════════════════════════════════════════
# Schedule Agent — تقويم + تذكيرات + مهام
# متخصص في:
#   - إضافة وعرض التذكيرات
#   - تنظيم المهام اليومية
#   - الإجابة عن الوقت والتاريخ
# ══════════════════════════════════════════════════
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from .base_agent import BaseSubAgent, SubAgentResult
import tools as tools_mod

_SCHEDULE_KEYWORDS = [
    # تذكير
    "ذكّرني", "ذكرني", "تذكير", "remind", "reminder",
    "اذكرني",
    # وقت
    "الوقت", "الساعة", "time", "كام الساعة",
    "النهارده", "بكرة", "tomorrow", "today",
    "موعد", "appointment", "meeting", "اجتماع",
    # مهام
    "مهمة", "task", "لازم", "خطة", "plan",
    "قائمة", "list", "todo",
    # تقويم
    "تقويم", "calendar", "جدول",
]

_SCHEDULE_SYSTEM = """أنت Schedule Agent متخصص في الوقت والمهام.
مهمتك: نظّم جدول المستخدم واحفظ تذكيراته.
- استخدم set_reminder للتذكيرات
- استخدم list_reminders للعرض
- استخدم get_time للوقت
- الرد دايماً بالعربية ومباشر"""


# regex لاستخراج الوقت
_TIME_RE = re.compile(
    r"(\d{1,2})\s*(?::(\d{2}))?\s*(ص|م|am|pm|صباح|مساء)?",
    re.IGNORECASE
)
_LABEL_RE = re.compile(
    r"(?:ذكّرني|ذكرني|اذكرني|remind me?)\s+(?:بـ?|b|by|to|with)?\s*(.+?)(?:\s+(?:الساعة|في|at)\s+|$)",
    re.IGNORECASE
)


class ScheduleAgent(BaseSubAgent):

    @property
    def name(self) -> str:
        return "Schedule Agent"

    @property
    def domain(self) -> str:
        return "تذكيرات ومواعيد"

    @property
    def emoji(self) -> str:
        return "📅"

    def can_handle(self, query: str) -> float:
        q = query.lower()
        hits = sum(1 for kw in _SCHEDULE_KEYWORDS if kw in q)
        if hits >= 3:
            return 0.95
        if hits == 2:
            return 0.85
        if hits == 1:
            return 0.60
        return 0.0

    def run(self, query: str, context: str = "") -> SubAgentResult:
        print(f"  📅 ScheduleAgent: {query[:50]}")

        q = query.lower()
        tools_used = []

        # ── عرض تذكيرات ──────────────────────────
        if any(w in q for w in ["تذكيراتي", "عندي إيه", "قائمة", "list"]):
            result = tools_mod.run("list_reminders", {})
            tools_used.append("list_reminders")
            return SubAgentResult(
                agent_name=self.name,
                text=result,
                tools_used=tools_used,
                confidence=0.9,
            )

        # ── الوقت الحالي ─────────────────────────
        if any(w in q for w in ["الوقت", "الساعة", "كام الساعة", "time", "التاريخ"]):
            result = tools_mod.run("get_time", {})
            tools_used.append("get_time")
            return SubAgentResult(
                agent_name=self.name,
                text=result,
                tools_used=tools_used,
                confidence=0.95,
            )

        # ── إضافة تذكير ──────────────────────────
        if any(w in q for w in ["ذكّرني", "ذكرني", "اذكرني", "remind"]):
            label, time_str = self._extract_reminder(query)
            if label and time_str:
                result = tools_mod.run("set_reminder", {
                    "label": label,
                    "time":  time_str,
                    "pre_alert_minutes": 10,
                })
                tools_used.append("set_reminder")
                return SubAgentResult(
                    agent_name=self.name,
                    text=result,
                    tools_used=tools_used,
                    confidence=0.9,
                )
            # مش لاقي وقت واضح
            return SubAgentResult(
                agent_name=self.name,
                text=f"🔔 عايز أحفظ تذكير — قولي الوقت بالظبط (مثال: ذكرني باجتماع الساعة 3:00م)",
                tools_used=[],
                confidence=0.6,
            )

        # ── fallback: list reminders ──────────────
        result = tools_mod.run("list_reminders", {})
        tools_used.append("list_reminders")
        return SubAgentResult(
            agent_name=self.name,
            text=f"📅 {result}",
            tools_used=tools_used,
            confidence=0.7,
        )

    def _extract_reminder(self, query: str) -> tuple[str, str]:
        """يستخرج label + HH:MM من الـ query"""
        # استخراج الوقت
        time_m = _TIME_RE.search(query)
        time_str = ""
        if time_m:
            h   = int(time_m.group(1))
            m   = int(time_m.group(2) or 0)
            suf = (time_m.group(3) or "").lower()
            if suf in ("م", "pm", "مساء") and h < 12:
                h += 12
            elif suf in ("ص", "am", "صباح") and h == 12:
                h = 0
            time_str = f"{h:02d}:{m:02d}"

        # استخراج الـ label
        label = ""
        label_m = _LABEL_RE.search(query)
        if label_m:
            label = label_m.group(1).strip()
        else:
            # استخراج بسيط: ما بعد فعل التذكير
            for trigger in ["ذكّرني بـ", "ذكرني بـ", "ذكّرني ب", "ذكرني ب", "اذكرني بـ", "remind me with", "remind me to"]:
                if trigger in query.lower():
                    after = query.lower().split(trigger, 1)[1]
                    label = after.split("الساعة")[0].split("في")[0].split("at")[0].strip()
                    break

        return label, time_str
