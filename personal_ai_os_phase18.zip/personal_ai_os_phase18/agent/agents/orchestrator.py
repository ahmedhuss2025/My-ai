# agent/agents/orchestrator.py — Phase 10
# ══════════════════════════════════════════════════
# Orchestrator — يقرر مين يشتغل
#
# Modes:
#   SINGLE   → يبعت للـ agent الأنسب
#   PARALLEL → يشغّل أكتر من agent وبيدمج النتائج
#   CHAIN    → A يحضّر context → B يستخدمه
#
# Decision flow:
#   1. كل agent يقيّم الطلب (can_handle)
#   2. لو واضح → SINGLE
#   3. لو مركّب → PARALLEL (ثم merge)
#   4. لو مش عارف → fallback للـ main agent
# ══════════════════════════════════════════════════
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import concurrent.futures
import datetime

from .base_agent import BaseSubAgent, SubAgentResult
from .research_agent  import ResearchAgent
from .schedule_agent  import ScheduleAgent
from .code_agent      import CodeAgent


# ── Thresholds ────────────────────────────────────
SINGLE_THRESHOLD   = 0.65    # أعلى من ده → single agent
PARALLEL_THRESHOLD = 0.50    # اتنين أو أكتر → parallel
MIN_CONFIDENCE     = 0.30    # أقل من ده → fallback


@dataclass
class OrchestratorResult:
    """نتيجة الـ orchestrator الكاملة"""
    mode:        str              # "single" | "parallel" | "fallback"
    agents_used: List[str]       = field(default_factory=list)
    final_text:  str             = ""
    sub_results: List[SubAgentResult] = field(default_factory=list)
    total_ms:    int             = 0
    query:       str             = ""

    def to_dict(self) -> dict:
        return {
            "mode":        self.mode,
            "agents_used": self.agents_used,
            "text":        self.final_text,
            "sub_results": [r.to_dict() for r in self.sub_results],
            "total_ms":    self.total_ms,
        }


class Orchestrator:
    """
    يدير الـ sub-agents ويوجّه الطلبات

    الاستخدام:
        orch = Orchestrator()
        result = orch.route("ابحث عن سعر الدولار وذكرني بالتحقق الساعة 5")
    """

    def __init__(self):
        self._agents: List[BaseSubAgent] = [
            ResearchAgent(),
            ScheduleAgent(),
            CodeAgent(),
        ]
        print(f"🎯 Orchestrator ready — {len(self._agents)} agents: "
              f"{', '.join(a.emoji + a.name for a in self._agents)}")

    # ══════════════════════════════════════════════
    # MAIN ROUTING
    # ══════════════════════════════════════════════
    def route(self, query: str, context: str = "") -> OrchestratorResult:
        """الـ entry point الرئيسي"""
        start = datetime.datetime.now()

        # 1. قيّم كل agent
        scores = {
            agent: agent.can_handle(query)
            for agent in self._agents
        }

        qualified = [(a, s) for a, s in scores.items() if s >= MIN_CONFIDENCE]
        qualified.sort(key=lambda x: x[1], reverse=True)

        print(f"\n🎯 Routing: '{query[:40]}'")
        for a, s in qualified:
            print(f"   {a.emoji} {a.name}: {s:.2f}")

        # 2. قرار التوجيه
        if not qualified:
            result = self._fallback(query, context)
            mode   = "fallback"
            subs   = []
        elif len(qualified) == 1 or qualified[0][1] >= SINGLE_THRESHOLD:
            # Single best agent
            best   = qualified[0][0]
            sub    = best._timed_run(query, context)
            result = sub.text
            mode   = "single"
            subs   = [sub]
        else:
            # Parallel — كل agent يشتغل
            eligible = [a for a, s in qualified if s >= PARALLEL_THRESHOLD][:3]
            subs   = self._run_parallel(eligible, query, context)
            result = self._merge(query, subs)
            mode   = "parallel"

        elapsed = int((datetime.datetime.now() - start).total_seconds() * 1000)

        return OrchestratorResult(
            mode        = mode,
            agents_used = [s.agent_name for s in subs] if subs else ["main"],
            final_text  = result,
            sub_results = subs,
            total_ms    = elapsed,
            query       = query,
        )

    # ══════════════════════════════════════════════
    # PARALLEL EXECUTION
    # ══════════════════════════════════════════════
    def _run_parallel(
        self,
        agents: List[BaseSubAgent],
        query:  str,
        context: str,
    ) -> List[SubAgentResult]:
        """يشغّل الـ agents بالتوازي"""
        print(f"  ⚡ Parallel: {[a.name for a in agents]}")
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
            futures = {
                ex.submit(agent._timed_run, query, context): agent
                for agent in agents
            }
            for f in concurrent.futures.as_completed(futures, timeout=10):
                try:
                    results.append(f.result())
                except Exception as e:
                    agent = futures[f]
                    results.append(SubAgentResult(
                        agent_name=agent.name,
                        text="",
                        error=str(e),
                    ))
        # sort by confidence desc
        results.sort(key=lambda r: r.confidence, reverse=True)
        return results

    # ══════════════════════════════════════════════
    # MERGE RESULTS
    # ══════════════════════════════════════════════
    def _merge(self, query: str, results: List[SubAgentResult]) -> str:
        """يدمج نتائج متعددة في رد واحد متماسك"""
        ok = [r for r in results if r.ok]
        if not ok:
            return "⚠️ مش قادر أجاوب دلوقتي — جرّب تاني"

        if len(ok) == 1:
            return ok[0].text

        # أكتر من نتيجة → دمج مع headers
        parts = []
        for r in ok:
            agent = next((a for a in self._agents if a.name == r.agent_name), None)
            emoji = agent.emoji if agent else "•"
            header = f"{emoji} **{r.agent_name}**"
            parts.append(f"{header}\n{r.text}")

        merged = "\n\n---\n\n".join(parts)
        return f"🎯 نتائج من {len(ok)} agents:\n\n{merged}"

    # ══════════════════════════════════════════════
    # FALLBACK
    # ══════════════════════════════════════════════
    def _fallback(self, query: str, context: str) -> str:
        """لما مفيش agent يعرف يتعامل مع الطلب"""
        print("  ⚠️  Fallback to main agent")
        return None   # None = server يستخدم الـ main agent

    # ══════════════════════════════════════════════
    # HELPERS
    # ══════════════════════════════════════════════
    def list_agents(self) -> List[Dict]:
        return [
            {
                "name":   a.name,
                "domain": a.domain,
                "emoji":  a.emoji,
            }
            for a in self._agents
        ]

    def classify(self, query: str) -> Dict:
        """يرجّع تقييم كل agent بدون تشغيل"""
        return {
            a.name: round(a.can_handle(query), 2)
            for a in self._agents
        }
