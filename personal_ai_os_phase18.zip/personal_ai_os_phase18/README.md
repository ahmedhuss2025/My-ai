# Personal AI OS — Flutter App

## 🚀 خطوات التشغيل الصبح

### 1. تثبيت Flutter في Android Studio
```
File → Settings → Plugins → بحث عن "Flutter" → Install → Restart
```

### 2. فتح المشروع
```
File → Open → اختار مجلد personal_ai_os
```

### 3. إضافة فونت Tajawal (اختياري)
```
https://fonts.google.com/specimen/Tajawal
→ Download Family → حط الـ TTF في assets/fonts/
```
> لو مش عايز الفونت دلوقتي — شيل الـ `fonts:` section من pubspec.yaml

### 4. تشغيل
```bash
flutter pub get
flutter run
```

---

## 📁 Structure

```
lib/
├── main.dart                    # Entry point + Provider setup
├── models/
│   └── app_state.dart           # Global state (theme, messages, neural)
├── screens/
│   ├── onboarding_screen.dart   # 4 slides (Welcome/NN/Privacy/Ready)
│   ├── main_shell.dart          # Bottom nav shell
│   ├── chat_screen.dart         # Chat UI
│   ├── dashboard_screen.dart    # Dashboard
│   └── settings_screen.dart     # Settings
├── services/
│   └── ai_service.dart          # Smart chat logic + neural heuristics
└── widgets/
    ├── chat_bubble.dart         # Message bubbles
    ├── neural_bar.dart          # Neural prediction status bar
    └── thinking_dots.dart       # Animated thinking indicator
```

## 📦 Dependencies
- `shared_preferences` — حفظ إعدادات المستخدم
- `provider` — State management
- `uuid` — Message IDs

## 🔜 Phase 3
- Kotlin Bridge (Gemma + Background Service + Overlay)
- Real neural inference on-device
- Screen intelligence
