// lib/screens/onboarding_screen.dart
//
// ══════════════════════════════════════════════════
// Personal AI OS — Onboarding Screen
// ══════════════════════════════════════════════════
// 4 شرائح بـ PageView:
//   0 → Welcome (orb + pills)
//   1 → Neural Network (animated canvas painter)
//   2 → Privacy (shield + 5 security layers)
//   3 → Ready → يروح لـ MainShell
// ══════════════════════════════════════════════════

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main_shell.dart'; // هنعمله بعدين

// ── App Colors ────────────────────────────────────
const _cyan   = Color(0xFF00C8FF);
const _teal   = Color(0xFF00E5CC);
const _green  = Color(0xFF00FF9D);
const _lime   = Color(0xFFAAFF00);
const _purple = Color(0xFF9D4EDD);
const _orange = Color(0xFFFF6B35);
const _bg     = Color(0xFF050810);
const _card   = Color(0xFF0A1228);

// ════════════════════════════════════════════════
// MAIN SCREEN
// ════════════════════════════════════════════════
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {

  // PageController
  final _pageCtrl = PageController();
  int _current = 0;

  // Animations
  late final AnimationController _orbCtrl;
  late final AnimationController _entryCtrl;
  late final AnimationController _shieldCtrl;

  late final Animation<double> _orbPulse;
  late final Animation<double> _entryScale;
  late final Animation<double> _entryFade;
  late final Animation<double> _shieldRot;

  @override
  void initState() {
    super.initState();

    // Orb breathing
    _orbCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _orbPulse = Tween<double>(begin: 0.93, end: 1.07)
        .animate(CurvedAnimation(parent: _orbCtrl, curve: Curves.easeInOut));

    // Per-page entry
    _entryCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _entryScale = Tween<double>(begin: 0.6, end: 1.0)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.elasticOut));
    _entryFade  = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut));

    // Shield spin
    _shieldCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 6))
      ..repeat();
    _shieldRot = Tween<double>(begin: 0, end: 2 * math.pi).animate(_shieldCtrl);

    _entryCtrl.forward();
  }

  @override
  void dispose() {
    _orbCtrl.dispose();
    _entryCtrl.dispose();
    _shieldCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  // ── Data ─────────────────────────────────────────
  static const _pages = [
    _PageData(
      emoji: '🤖',
      title: 'مرحباً بك في\nPersonal AI OS',
      subtitle: 'مساعدك الذكي الشخصي\nيشتغل محلياً على فونك\nبدون نت · بدون tracking',
      primary: _cyan,
      secondary: _teal,
    ),
    _PageData(
      emoji: '🧠',
      title: 'شبكة عصبية\nعلى فونك',
      subtitle: '101,271 parameter\nبيعمل inference محلياً في < 50ms',
      primary: _purple,
      secondary: _cyan,
    ),
    _PageData(
      emoji: '🔐',
      title: 'خصوصيتك\nأولاً دايماً',
      subtitle: 'بياناتك لا تغادر الفون أبداً\n5 طبقات تشفير كل لحظة',
      primary: _teal,
      secondary: _cyan,
    ),
    _PageData(
      emoji: '✨',
      title: 'جاهز\nتبدأ؟',
      subtitle: 'Agent هيتعلم عاداتك\nويكبر معك كل يوم\nكل بياناتك تبقى عليك.',
      primary: _green,
      secondary: _teal,
    ),
  ];

  bool get _isLast => _current == _pages.length - 1;
  Color get _primaryColor => _pages[_current].primary;

  // ── Handlers ─────────────────────────────────────
  void _onPageChanged(int i) {
    setState(() => _current = i);
    _entryCtrl.reset();
    _entryCtrl.forward();
    HapticFeedback.selectionClick();
  }

  Future<void> _next() async {
    if (!_isLast) {
      _pageCtrl.nextPage(
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeInOutCubic,
      );
      return;
    }
    // Mark done & navigate
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_done', true);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => const MainShell(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  void _skip() => _pageCtrl.animateToPage(
        _pages.length - 1,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOutCubic,
      );

  // ── BUILD ─────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // Grid bg
          CustomPaint(painter: _GridPainter(), child: const SizedBox.expand()),

          // Ambient glow
          AnimatedPositioned(
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOut,
            top: -100, right: _current.isEven ? -100 : 60,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 700),
              width: mq.size.width,
              height: mq.size.width,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _primaryColor.withOpacity(0.2),
                  Colors.transparent,
                ]),
              ),
            ),
          ),

          // Pages
          PageView.builder(
            controller: _pageCtrl,
            itemCount: _pages.length,
            onPageChanged: _onPageChanged,
            itemBuilder: (_, i) => _buildPage(i),
          ),

          // Skip
          if (!_isLast)
            Positioned(
              top: mq.padding.top + 6,
              left: 12,
              child: TextButton(
                onPressed: _skip,
                style: TextButton.styleFrom(foregroundColor: Colors.white30),
                child: const Text('تخطى', style: TextStyle(fontFamily: 'Tajawal')),
              ),
            ),

          // Bottom bar
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: _BottomBar(
              count: _pages.length,
              current: _current,
              isLast: _isLast,
              primaryColor: _primaryColor,
              secondaryColor: _pages[_current].secondary,
              pageColors: _pages.map((p) => p.primary).toList(),
              onDotTap: (i) => _pageCtrl.animateToPage(i,
                  duration: const Duration(milliseconds: 400),
                  curve: Curves.easeInOutCubic),
              onNext: _next,
            ),
          ),
        ],
      ),
    );
  }

  // ── Build each page ──────────────────────────────
  Widget _buildPage(int i) {
    final page = _pages[i];
    final isActive = i == _current;
    final mq = MediaQuery.of(context);

    return Padding(
      padding: EdgeInsets.fromLTRB(24, mq.padding.top + 60, 24, 130),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Orb
          FadeTransition(
            opacity: isActive ? _entryFade : const AlwaysStoppedAnimation(1),
            child: ScaleTransition(
              scale: isActive ? _entryScale : const AlwaysStoppedAnimation(1),
              child: AnimatedBuilder(
                animation: _orbPulse,
                builder: (_, child) => Transform.scale(
                  scale: isActive ? _orbPulse.value : 1.0,
                  child: child,
                ),
                child: _buildOrb(i, page),
              ),
            ),
          ),
          const SizedBox(height: 28),

          // Title
          FadeTransition(
            opacity: isActive ? _entryFade : const AlwaysStoppedAnimation(1),
            child: ShaderMask(
              shaderCallback: (b) => LinearGradient(
                colors: [page.primary, page.secondary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(b),
              child: Text(
                page.title,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontSize: 27,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  height: 1.25,
                  letterSpacing: -0.3,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Subtitle
          Text(
            page.subtitle,
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withOpacity(0.44),
              height: 1.8,
            ),
          ),
          const SizedBox(height: 22),

          // Extra content per slide
          if (isActive || true)
            FadeTransition(
              opacity: isActive ? _entryFade : const AlwaysStoppedAnimation(1),
              child: _buildExtra(i, page),
            ),
        ],
      ),
    );
  }

  // ── Orb per slide ────────────────────────────────
  Widget _buildOrb(int i, _PageData page) {
    if (i == 2) {
      // Shield with rotating rings
      return SizedBox(
        width: 96, height: 96,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedBuilder(
              animation: _shieldRot,
              builder: (_, child) => Transform.rotate(
                angle: _shieldRot.value, child: child),
              child: Container(
                width: 96, height: 96,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _teal.withOpacity(0.25), width: 1.5),
                ),
              ),
            ),
            AnimatedBuilder(
              animation: _shieldRot,
              builder: (_, child) => Transform.rotate(
                angle: -_shieldRot.value * 0.6, child: child),
              child: Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _cyan.withOpacity(0.2), width: 1),
                ),
              ),
            ),
            _OrbCore(emoji: page.emoji, color: page.primary),
          ],
        ),
      );
    }
    return _OrbCore(emoji: page.emoji, color: page.primary);
  }

  // ── Extra widgets ────────────────────────────────
  Widget _buildExtra(int i, _PageData page) {
    switch (i) {
      case 0: // Welcome pills
        return _PillsRow(pills: const [
          ('🔒', 'Privacy-First', _cyan),
          ('⚡', 'Offline',       _green),
          ('🧠', 'On-Device AI',  _teal),
        ]);

      case 1: // Neural viz
        return SizedBox(
          height: 110,
          child: _NeuralCanvas(),
        );

      case 2: // Security layers
        return const _SecurityLayers();

      case 3: // Ready pills
        return _PillsRow(pills: const [
          ('💬', 'Chat',     _cyan),
          ('👁️', 'Overlay',  _purple),
          ('📚', 'Learning', _green),
          ('💾', 'Backup',   _orange),
          ('🔐', 'Private',  _lime),
        ]);

      default:
        return const SizedBox.shrink();
    }
  }
}

// ════════════════════════════════════════════════
// SUB-WIDGETS
// ════════════════════════════════════════════════

// ── Page Data Model ───────────────────────────────
class _PageData {
  final String emoji, title, subtitle;
  final Color primary, secondary;
  const _PageData({
    required this.emoji, required this.title,
    required this.subtitle, required this.primary,
    required this.secondary,
  });
}

// ── Orb Core ─────────────────────────────────────
class _OrbCore extends StatelessWidget {
  final String emoji;
  final Color color;
  const _OrbCore({required this.emoji, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80, height: 80,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(0.1),
        border: Border.all(color: color.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 36, spreadRadius: 4)],
      ),
      child: Center(
        child: Text(emoji, style: const TextStyle(fontSize: 36)),
      ),
    );
  }
}

// ── Pills Row ─────────────────────────────────────
class _PillsRow extends StatelessWidget {
  final List<(String, String, Color)> pills;
  const _PillsRow({required this.pills});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8, runSpacing: 8,
      alignment: WrapAlignment.center,
      children: pills.map((p) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: p.$3.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: p.$3.withOpacity(0.25)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(p.$1, style: const TextStyle(fontSize: 13)),
            const SizedBox(width: 6),
            Text(p.$2, style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w700, color: p.$3)),
          ],
        ),
      )).toList(),
    );
  }
}

// ── Neural Canvas ─────────────────────────────────
class _NeuralCanvas extends StatefulWidget {
  @override
  State<_NeuralCanvas> createState() => _NeuralCanvasState();
}

class _NeuralCanvasState extends State<_NeuralCanvas>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => CustomPaint(
        size: const Size(double.infinity, 110),
        painter: _NNPainter(_ctrl.value),
      ),
    );
  }
}

class _NNPainter extends CustomPainter {
  final double t;
  _NNPainter(this.t);

  static const _layers = [
    (_cyan,   4, 0.12),
    (_purple, 5, 0.38),
    (_teal,   4, 0.62),
    (_green,  3, 0.88),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final H = size.height;
    final W = size.width;

    // Connections
    final connPaint = Paint()
      ..color = Colors.white.withOpacity(0.05)
      ..strokeWidth = 0.7;

    for (int li = 0; li < _layers.length - 1; li++) {
      final (_, n1, xRatio1) = _layers[li];
      final (_, n2, xRatio2) = _layers[li + 1];
      final x1 = W * xRatio1, x2 = W * xRatio2;
      for (int a = 0; a < n1; a++) {
        for (int b = 0; b < n2; b++) {
          canvas.drawLine(
            Offset(x1, H * (a + 1) / (n1 + 1)),
            Offset(x2, H * (b + 1) / (n2 + 1)),
            connPaint,
          );
        }
      }

      // Animated signal
      final sig = (t - li * 0.22).clamp(0.0, 1.0);
      if (sig > 0) {
        final (color, n1, _) = _layers[li];
        final sigPaint = Paint()
          ..color = color.withOpacity(0.75 * math.sin(sig * math.pi))
          ..strokeWidth = 1.8;
        final y = H * (n1 ~/ 2 + 1) / (n1 + 1);
        canvas.drawLine(
          Offset(x1, y),
          Offset(x1 + (x2 - x1) * sig, y),
          sigPaint,
        );
      }
    }

    // Nodes
    for (final (color, n, xRatio) in _layers) {
      final x = W * xRatio;
      for (int i = 0; i < n; i++) {
        final y = H * (i + 1) / (n + 1);
        final pulse = 1 + 0.08 * math.sin(t * 2 * math.pi + i * 0.9);
        final r = 6.0 * pulse;
        canvas.drawCircle(Offset(x, y), r,
            Paint()..color = color.withOpacity(0.15));
        canvas.drawCircle(Offset(x, y), r,
            Paint()
              ..color = color
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.4);
      }
    }
  }

  @override
  bool shouldRepaint(_NNPainter old) => old.t != t;
}

// ── Security Layers ───────────────────────────────
class _SecurityLayers extends StatelessWidget {
  const _SecurityLayers();

  static const _items = [
    ('🔑', 'Android Keystore (hardware)', 'HW',     _cyan),
    ('🗄️', 'SQLCipher Database',          'AES-256', _teal),
    ('📦', 'Backup Encryption',           'HMAC',   _lime),
    ('🌐', 'Sandbox (نت معزول)',          'TLS 1.3', _orange),
    ('👁️', 'Biometric Gate',              'BIO',    _purple),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (int i = 0; i < _items.length; i++)
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: Duration(milliseconds: 350 + i * 80),
            curve: Curves.easeOutCubic,
            builder: (_, v, child) => Opacity(
              opacity: v,
              child: Transform.translate(offset: Offset(16 * (1 - v), 0), child: child),
            ),
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 3),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: Row(
                children: [
                  Text(_items[i].$1, style: const TextStyle(fontSize: 16)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_items[i].$2,
                        style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.5))),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _items[i].$4.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _items[i].$4.withOpacity(0.25)),
                    ),
                    child: Text(
                      _items[i].$3,
                      style: TextStyle(
                        fontSize: 9, fontWeight: FontWeight.w700,
                        color: _items[i].$4, fontFamily: 'monospace',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ── Bottom Bar ────────────────────────────────────
class _BottomBar extends StatelessWidget {
  final int count, current;
  final bool isLast;
  final Color primaryColor, secondaryColor;
  final List<Color> pageColors;
  final Function(int) onDotTap;
  final VoidCallback onNext;

  const _BottomBar({
    required this.count, required this.current,
    required this.isLast, required this.primaryColor,
    required this.secondaryColor, required this.pageColors,
    required this.onDotTap, required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).padding.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(24, 0, 24, bottomPad + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Dots
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(count, (i) => GestureDetector(
              onTap: () => onDotTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: current == i ? 24 : 7,
                height: 7,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: current == i
                      ? pageColors[i]
                      : Colors.white.withOpacity(0.2),
                ),
              ),
            )),
          ),
          const SizedBox(height: 18),

          // Button
          GestureDetector(
            onTap: onNext,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                gradient: LinearGradient(
                  colors: [primaryColor, secondaryColor],
                  begin: Alignment.centerRight,
                  end: Alignment.centerLeft,
                ),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.35),
                    blurRadius: 24, offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    isLast ? 'ابدأ الآن!' : 'التالي',
                    style: const TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 17, fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Icon(
                      isLast ? Icons.check_circle_rounded : Icons.arrow_back_rounded,
                      key: ValueKey(isLast),
                      color: Colors.white, size: 20,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Grid Painter ──────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = const Color(0xFF00C8FF).withOpacity(0.025)
      ..strokeWidth = 0.5;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
