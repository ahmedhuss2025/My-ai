// lib/screens/lock_screen.dart — Phase 17
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/security_service.dart';
import '../services/theme_service.dart';
import '../theme/app_theme.dart';

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});
  @override State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _pin       = ValueNotifier<String>('');
  bool  _checking  = false;
  String _errorMsg = '';
  bool  _isSetup   = false;
  String _confirmPin = '';
  bool  _inConfirm   = false;

  @override
  void initState() {
    super.initState();
    final status = SecurityService.instance.status;
    _isSetup = status.state == LockState.setupNeeded;
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.watch<ThemeService>().themeData.accent;
    final status = SecurityService.instance.status;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 340),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                // Icon
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent.withOpacity(0.12),
                    border: Border.all(color: accent.withOpacity(0.3), width: 2),
                  ),
                  child: Icon(
                    _isSetup ? Icons.lock_outline_rounded : Icons.lock_rounded,
                    color: accent, size: 32),
                ),
                const SizedBox(height: 20),

                // Title
                Text(
                  _isSetup
                    ? (_inConfirm ? 'تأكيد الـ PIN' : 'إنشاء PIN جديد')
                    : 'أدخل PIN',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800,
                    color: AppColors.text, fontFamily: 'Tajawal'),
                ),
                const SizedBox(height: 8),
                Text(
                  _isSetup
                    ? (_inConfirm ? 'أعد إدخال الـ PIN للتأكيد'
                                  : 'أدخل PIN لحماية تطبيقك (4+ أرقام)')
                    : 'أدخل PIN للوصول للمساعد',
                  style: TextStyle(fontSize: 13, color: AppColors.textMuted,
                    fontFamily: 'Tajawal'),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),

                // PIN dots
                ValueListenableBuilder<String>(
                  valueListenable: _pin,
                  builder: (_, pin, __) => Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(6, (i) {
                      final filled = i < pin.length;
                      return Container(
                        width: 14, height: 14,
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: filled ? accent : Colors.transparent,
                          border: Border.all(
                            color: filled ? accent : AppColors.textFaint, width: 2)),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 10),

                // Error
                if (_errorMsg.isNotEmpty)
                  Text(_errorMsg, style: const TextStyle(
                    color: Color(0xFFEF4444), fontSize: 12,
                    fontFamily: 'Tajawal')),
                const SizedBox(height: 20),

                // PIN Pad
                _PinPad(accent: accent, checking: _checking,
                  onDigit:  (d) => _onDigit(d),
                  onDelete: _onDelete,
                ),
                const SizedBox(height: 16),

                // Biometric button
                if (!_isSetup && status.biometricEnabled)
                  TextButton.icon(
                    onPressed: _checking ? null : _biometric,
                    icon: Icon(Icons.fingerprint_rounded, color: accent),
                    label: Text('البصمة', style: TextStyle(
                      color: accent, fontFamily: 'Tajawal')),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _onDigit(String d) {
    if (_pin.value.length >= 6 || _checking) return;
    _pin.value += d;
    if (_pin.value.length >= 4) {
      Future.delayed(const Duration(milliseconds: 100), _submit);
    }
  }

  void _onDelete() {
    if (_pin.value.isNotEmpty) {
      _pin.value = _pin.value.substring(0, _pin.value.length - 1);
    }
    setState(() => _errorMsg = '');
  }

  Future<void> _submit() async {
    if (_checking) return;
    setState(() { _checking = true; _errorMsg = ''; });
    final pin = _pin.value;

    if (_isSetup) {
      if (!_inConfirm) {
        // First entry: go to confirm
        setState(() { _inConfirm = true; _confirmPin = pin; });
        _pin.value = '';
        _checking  = false;
        return;
      } else {
        // Second entry: confirm match
        if (pin != _confirmPin) {
          setState(() { _errorMsg = '❌ الـ PIN غير متطابق'; _inConfirm = false; _confirmPin = ''; });
          _pin.value = ''; _checking = false; return;
        }
        final r = await SecurityService.instance.setupPin(pin);
        if (r['ok'] == true) { _unlock(); return; }
        setState(() => _errorMsg = r['error'] as String? ?? 'خطأ');
      }
    } else {
      final r = await SecurityService.instance.unlock(pin);
      if (r['ok'] == true) { _unlock(); return; }
      final attempts = r['attempts'] as int? ?? 0;
      setState(() => _errorMsg = 'PIN خاطئ ($attempts محاولة)');
    }
    _pin.value = ''; setState(() => _checking = false);
  }

  Future<void> _biometric() async {
    setState(() => _checking = true);
    final ok = await SecurityService.instance.authenticateBiometric();
    if (ok) { _unlock(); return; }
    setState(() { _checking = false; _errorMsg = 'فشل التحقق بالبصمة'; });
  }

  void _unlock() { widget.onUnlocked(); }
}


// ── PIN Pad ───────────────────────────────────────
class _PinPad extends StatelessWidget {
  final Color  accent;
  final bool   checking;
  final Function(String) onDigit;
  final VoidCallback     onDelete;
  const _PinPad({required this.accent, required this.checking,
    required this.onDigit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final digits = [
      ['1','2','3'],
      ['4','5','6'],
      ['7','8','9'],
      ['','0','⌫'],
    ];
    return Column(
      children: digits.map((row) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: row.map((d) {
          if (d.isEmpty) return const SizedBox(width: 80, height: 64);
          return GestureDetector(
            onTap: checking ? null : () => d == '⌫' ? onDelete() : onDigit(d),
            child: Container(
              width: 80, height: 64,
              margin: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.07)),
              ),
              alignment: Alignment.center,
              child: Text(d, style: TextStyle(
                fontSize: d == '⌫' ? 20 : 22,
                fontWeight: FontWeight.w700,
                color: d == '⌫' ? AppColors.textMuted : AppColors.text,
                fontFamily: 'Tajawal')),
            ),
          );
        }).toList(),
      )).toList(),
    );
  }
}
