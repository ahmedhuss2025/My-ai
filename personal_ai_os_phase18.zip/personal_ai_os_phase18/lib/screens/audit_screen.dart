// lib/screens/audit_screen.dart — Phase 18
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import '../services/theme_service.dart';
import '../theme/app_theme.dart';

class AuditScreen extends StatefulWidget {
  const AuditScreen({super.key});
  @override State<AuditScreen> createState() => _AuditScreenState();
}

class _AuditScreenState extends State<AuditScreen>
    with SingleTickerProviderStateMixin {
  static const _base = 'http://localhost:7070';
  late TabController _tabs;

  List<Map<String, dynamic>> _events  = [];
  List<Map<String, dynamic>> _pending = [];
  Map<String, dynamic>       _stats   = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        http.get(Uri.parse('$_base/audit/log?limit=80'))
            .timeout(const Duration(seconds: 8)),
        http.get(Uri.parse('$_base/audit/pending'))
            .timeout(const Duration(seconds: 8)),
      ]);
      if (results[0].statusCode == 200) {
        final j = jsonDecode(utf8.decode(results[0].bodyBytes)) as Map<String, dynamic>;
        _events = (j['events'] as List? ?? [])
            .map((e) => e as Map<String, dynamic>).toList();
        _stats  = j['stats'] as Map<String, dynamic>? ?? {};
      }
      if (results[1].statusCode == 200) {
        final j = jsonDecode(utf8.decode(results[1].bodyBytes)) as Map<String, dynamic>;
        _pending = (j['pending'] as List? ?? [])
            .map((e) => e as Map<String, dynamic>).toList();
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _approve(String id) async {
    try {
      await http.post(Uri.parse('$_base/audit/approve'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id})).timeout(const Duration(seconds: 8));
      await _load();
    } catch (_) {}
  }

  Future<void> _reject(String id) async {
    try {
      await http.post(Uri.parse('$_base/audit/reject'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id})).timeout(const Duration(seconds: 8));
      await _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.watch<ThemeService>().themeData.accent;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(children: [

          // ── Header ──────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(20,16,20,0),
            child: Row(children: [
              Icon(Icons.manage_search_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text('سجل الوكيل', style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w800,
                color: AppColors.text, fontFamily: 'Tajawal')),
              const Spacer(),
              if (_pending.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF59E0B).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8)),
                  child: Text('${_pending.length} معلّق',
                    style: const TextStyle(fontSize: 11, color: Color(0xFFF59E0B),
                      fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
                ),
              const SizedBox(width: 8),
              IconButton(icon: Icon(Icons.refresh_rounded, color: accent),
                onPressed: _load),
            ]),
          ),

          // ── Stats Row ──────────────────────────
          if (_stats.isNotEmpty) ...[
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _StatsRow(stats: _stats, accent: accent)),
          ],
          const SizedBox(height: 10),

          // ── Tabs ────────────────────────────────
          TabBar(
            controller: _tabs,
            indicatorColor: accent,
            labelColor: accent,
            unselectedLabelColor: AppColors.textMuted,
            labelStyle: const TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w700),
            tabs: [
              Tab(text: 'السجل (${_events.length})'),
              Tab(text: 'معلّق (${_pending.length})'),
            ],
          ),

          // ── Content ─────────────────────────────
          Expanded(
            child: _loading
              ? Center(child: CircularProgressIndicator(color: accent))
              : TabBarView(controller: _tabs, children: [
                  _EventsList(events: _events, accent: accent),
                  _PendingList(pending: _pending, accent: accent,
                    onApprove: _approve, onReject: _reject),
                ]),
          ),
        ]),
      ),
    );
  }
}


// ── Stats Row ─────────────────────────────────────
class _StatsRow extends StatelessWidget {
  final Map<String, dynamic> stats;
  final Color accent;
  const _StatsRow({required this.stats, required this.accent});
  @override
  Widget build(BuildContext context) => Row(children: [
    _StatChip('${stats["today"] ?? 0}', 'اليوم',  accent),
    const SizedBox(width: 6),
    _StatChip('${stats["messages"] ?? 0}', 'رسائل', AppColors.success),
    const SizedBox(width: 6),
    _StatChip('${stats["pending"] ?? 0}', 'معلّق', const Color(0xFFF59E0B)),
    const SizedBox(width: 6),
    _StatChip('${stats["total"] ?? 0}', 'إجمالي', AppColors.textMuted),
  ]);
}

class _StatChip extends StatelessWidget {
  final String count, label;
  final Color  color;
  const _StatChip(this.count, this.label, this.color);
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(count, style: TextStyle(
          fontSize: 16, fontWeight: FontWeight.w900,
          color: color, fontFamily: 'Tajawal')),
        Text(label, style: TextStyle(
          fontSize: 9, color: color.withOpacity(0.7), fontFamily: 'Tajawal')),
      ]),
    ),
  );
}


// ── Events List ───────────────────────────────────
class _EventsList extends StatelessWidget {
  final List<Map<String, dynamic>> events;
  final Color accent;
  const _EventsList({required this.events, required this.accent});

  static const _icons = {
    'llm_call':       '🤖',
    'message_sent':   '📤',
    'message_draft':  '✍️',
    'email_sent':     '📧',
    'email_draft':    '📝',
    'action':         '⚡',
    'settings_change':'⚙️',
    'proactive':      '💡',
    'error':          '❌',
  };

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) return Center(
      child: Text('لا يوجد سجل بعد', style: TextStyle(
        color: AppColors.textFaint, fontFamily: 'Tajawal')));
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      itemCount: events.length,
      itemBuilder: (ctx, i) {
        final e = events[i];
        final emoji = _icons[e['type']] ?? '📌';
        final ts    = (e['ts'] as String? ?? '').replaceAll('T', ' ').substring(0, 16);
        final approved = e['approved'] as int? ?? -1;
        final approvedBadge = approved == 1 ? '✅' : approved == 2 ? '❌' : '';
        return Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.card, borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white.withOpacity(0.05))),
          child: Row(children: [
            Text(emoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 10),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('$approvedBadge ${e["title"] ?? ""}',
                  style: TextStyle(color: AppColors.text, fontFamily: 'Tajawal',
                    fontSize: 13, fontWeight: FontWeight.w600))),
              ]),
              if ((e['detail'] as String? ?? '').isNotEmpty)
                Text(e['detail'] as String, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: AppColors.textFaint,
                    fontFamily: 'Tajawal', fontSize: 11)),
            ])),
            Text(ts, style: TextStyle(
              fontSize: 9, color: AppColors.textFaint, fontFamily: 'Tajawal')),
          ]),
        );
      },
    );
  }
}


// ── Pending List (Draft Mode) ─────────────────────
class _PendingList extends StatelessWidget {
  final List<Map<String, dynamic>> pending;
  final Color accent;
  final Function(String) onApprove, onReject;
  const _PendingList({required this.pending, required this.accent,
    required this.onApprove, required this.onReject});

  @override
  Widget build(BuildContext context) {
    if (pending.isEmpty) return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('✅', style: TextStyle(fontSize: 40)),
        const SizedBox(height: 8),
        Text('لا يوجد إجراءات معلّقة', style: TextStyle(
          color: AppColors.textMuted, fontFamily: 'Tajawal')),
      ]));
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      itemCount: pending.length,
      itemBuilder: (ctx, i) {
        final p = pending[i];
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.3))),
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                const Text('⏳', style: TextStyle(fontSize: 20)),
                const SizedBox(width: 10),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p['title'] as String? ?? '', style: TextStyle(
                    color: AppColors.text, fontFamily: 'Tajawal',
                    fontWeight: FontWeight.w700, fontSize: 14)),
                  if ((p['detail'] as String? ?? '').isNotEmpty)
                    Text(p['detail'] as String, style: TextStyle(
                      color: AppColors.textMuted, fontFamily: 'Tajawal', fontSize: 12)),
                ])),
              ]),
            ),
            const Divider(height: 1, color: Colors.white10),
            Row(children: [
              Expanded(child: TextButton(
                onPressed: () => onReject(p['id'] as String),
                child: const Text('❌ رفض',
                  style: TextStyle(color: Color(0xFFEF4444),
                    fontFamily: 'Tajawal', fontWeight: FontWeight.w700)))),
              Container(width: 1, height: 40, color: Colors.white10),
              Expanded(child: TextButton(
                onPressed: () => onApprove(p['id'] as String),
                child: Text('✅ موافقة',
                  style: TextStyle(color: accent,
                    fontFamily: 'Tajawal', fontWeight: FontWeight.w700)))),
            ]),
          ]),
        );
      },
    );
  }
}
