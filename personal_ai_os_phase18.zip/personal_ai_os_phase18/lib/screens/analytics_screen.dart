// lib/screens/analytics_screen.dart — Phase 17
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/analytics_service.dart';
import '../services/theme_service.dart';
import '../theme/app_theme.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});
  @override State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  @override
  void initState() {
    super.initState();
    AnalyticsService.instance.loadReport();
  }

  @override
  Widget build(BuildContext context) {
    final svc    = context.watch<AnalyticsService>();
    final accent = context.watch<ThemeService>().themeData.accent;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: svc.loading
          ? Center(child: CircularProgressIndicator(color: accent))
          : RefreshIndicator(
              color: accent,
              onRefresh: svc.loadReport,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [

                  // ── Header ──────────────────────
                  Row(children: [
                    Icon(Icons.bar_chart_rounded, color: accent, size: 22),
                    const SizedBox(width: 10),
                    Text('الإحصاءات', style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800,
                      color: AppColors.text, fontFamily: 'Tajawal')),
                    const Spacer(),
                    IconButton(icon: Icon(Icons.refresh_rounded, color: accent),
                      onPressed: svc.loadReport),
                  ]),
                  const SizedBox(height: 16),

                  // ── Totals Row ──────────────────
                  _TotalsRow(totals: svc.report.totals, accent: accent),
                  const SizedBox(height: 20),

                  // ── Weekly Bar Chart ────────────
                  _SectionLabel('📅 نشاط الأسبوع', accent),
                  const SizedBox(height: 10),
                  _WeeklyChart(week: svc.report.week, accent: accent),
                  const SizedBox(height: 20),

                  // ── Feature Breakdown ───────────
                  if (svc.report.features.isNotEmpty) ...[
                    _SectionLabel('🔧 استخدام الميزات', accent),
                    const SizedBox(height: 10),
                    _FeatureBreakdown(features: svc.report.features, accent: accent),
                    const SizedBox(height: 20),
                  ],

                  // ── Hourly Heatmap ──────────────
                  if (svc.report.heatmap.isNotEmpty) ...[
                    _SectionLabel('🕐 ساعات الذروة', accent),
                    const SizedBox(height: 10),
                    _HourlyHeatmap(heatmap: svc.report.heatmap, accent: accent),
                    const SizedBox(height: 20),
                  ],

                  // ── AI Insights ─────────────────
                  if (svc.insights.isNotEmpty) ...[
                    _SectionLabel('💡 ملاحظات ذكية', accent),
                    const SizedBox(height: 10),
                    ...svc.insights.map((i) => _InsightCard(insight: i, accent: accent)),
                  ],

                  const SizedBox(height: 30),
                ],
              ),
            ),
      ),
    );
  }
}


// ── Totals Row ────────────────────────────────────
class _TotalsRow extends StatelessWidget {
  final Map<String, dynamic> totals;
  final Color accent;
  const _TotalsRow({required this.totals, required this.accent});
  @override
  Widget build(BuildContext context) {
    final cards = [
      ('💬', '${totals["total_messages"] ?? 0}', 'رسالة'),
      ('🎙️', '${totals["total_voice"]    ?? 0}', 'صوتي'),
      ('🎙️📝','${totals["total_meetings"] ?? 0}', 'اجتماع'),
      ('🔥', '${totals["streak"]         ?? 0}', 'يوم'),
    ];
    return Row(children: cards.map((c) => Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: accent.withOpacity(0.12)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(c.$1, style: const TextStyle(fontSize: 20)),
          const SizedBox(height: 4),
          Text(c.$2, style: TextStyle(
            fontSize: 22, fontWeight: FontWeight.w900,
            color: accent, fontFamily: 'Tajawal')),
          Text(c.$3, style: TextStyle(
            fontSize: 10, color: AppColors.textMuted, fontFamily: 'Tajawal')),
        ]),
      ),
    )).toList());
  }
}


// ── Weekly Bar Chart ──────────────────────────────
class _WeeklyChart extends StatelessWidget {
  final List<Map<String, dynamic>> week;
  final Color accent;
  const _WeeklyChart({required this.week, required this.accent});

  @override
  Widget build(BuildContext context) {
    if (week.isEmpty) return const _EmptyChart();
    final maxVal = week.map((d) =>
      (d['messages_sent'] as int? ?? 0) + (d['voice_sessions'] as int? ?? 0)
    ).fold(0, (a, b) => a > b ? a : b);

    return Container(
      height: 140,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: week.map((d) {
          final msgs  = (d['messages_sent']  as int? ?? 0);
          final voice = (d['voice_sessions'] as int? ?? 0);
          final total = msgs + voice;
          final frac  = maxVal > 0 ? total / maxVal : 0.0;
          final dateStr = (d['date'] as String? ?? '').split('-').last;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (total > 0)
                    Text('$total', style: TextStyle(
                      fontSize: 9, color: accent, fontFamily: 'Tajawal')),
                  const SizedBox(height: 2),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 600),
                    curve: Curves.easeOutCubic,
                    height: (80 * frac).clamp(3, 80).toDouble(),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(total > 0 ? 0.8 : 0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(dateStr, style: TextStyle(
                    fontSize: 9, color: AppColors.textFaint, fontFamily: 'Tajawal')),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}


// ── Feature Breakdown ─────────────────────────────
class _FeatureBreakdown extends StatelessWidget {
  final Map<String, int> features;
  final Color accent;
  const _FeatureBreakdown({required this.features, required this.accent});

  static const _labels = {
    'chat':    ('💬', 'محادثة'),
    'voice':   ('🎙️', 'صوت'),
    'meeting': ('📝', 'اجتماع'),
    'image':   ('🎨', 'صورة'),
    'reminder_create': ('🔔', 'تذكير'),
  };

  @override
  Widget build(BuildContext context) {
    final total = features.values.fold(0, (a, b) => a + b);
    if (total == 0) return const _EmptyChart();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(children: features.entries
        .where((e) => e.value > 0)
        .toList()
        ..sort((a, b) => b.value.compareTo(a.value))
        ..take(5).map((e) {
          final pct  = e.value / total;
          final info = _labels[e.key] ?? ('📌', e.key);
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              Text(info.$1, style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 10),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(info.$2, style: TextStyle(
                      fontSize: 12, color: AppColors.text, fontFamily: 'Tajawal')),
                    const Spacer(),
                    Text('${e.value}', style: TextStyle(
                      fontSize: 11, color: accent, fontFamily: 'Tajawal',
                      fontWeight: FontWeight.w700)),
                  ]),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: pct, minHeight: 5,
                      backgroundColor: Colors.white10,
                      valueColor: AlwaysStoppedAnimation(accent),
                    ),
                  ),
                ],
              )),
            ]),
          );
        }).toList()),
    );
  }
}


// ── Hourly Heatmap ────────────────────────────────
class _HourlyHeatmap extends StatelessWidget {
  final Map<String, int> heatmap;
  final Color accent;
  const _HourlyHeatmap({required this.heatmap, required this.accent});
  @override
  Widget build(BuildContext context) {
    final maxVal = heatmap.values.fold(0, (a, b) => a > b ? a : b);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Wrap(
        spacing: 5, runSpacing: 5,
        children: List.generate(24, (h) {
          final key  = h.toString().padLeft(2, '0');
          final cnt  = heatmap[key] ?? 0;
          final opac = maxVal > 0 ? (cnt / maxVal).clamp(0.05, 1.0) : 0.05;
          return Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                color: accent.withOpacity(opac),
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            const SizedBox(height: 2),
            Text('$h', style: TextStyle(
              fontSize: 8, color: AppColors.textFaint, fontFamily: 'Tajawal')),
          ]);
        }),
      ),
    );
  }
}


// ── Insight Card ──────────────────────────────────
class _InsightCard extends StatelessWidget {
  final Map<String, dynamic> insight;
  final Color accent;
  const _InsightCard({required this.insight, required this.accent});
  @override
  Widget build(BuildContext context) {
    final priority = insight['priority'] as String? ?? 'normal';
    final borderColor = switch (priority) {
      'high'   => accent,
      'low'    => Colors.white.withOpacity(0.06),
      _        => accent.withOpacity(0.3),
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor),
      ),
      child: Row(children: [
        Text(insight['emoji'] as String? ?? '💡',
          style: const TextStyle(fontSize: 24)),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(insight['title'] as String? ?? '', style: TextStyle(
              color: AppColors.text, fontFamily: 'Tajawal',
              fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 3),
            Text(insight['body'] as String? ?? '', style: TextStyle(
              color: AppColors.textMuted, fontFamily: 'Tajawal', fontSize: 12)),
          ],
        )),
      ]),
    );
  }
}


// ── Section Label ─────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String text;
  final Color  accent;
  const _SectionLabel(this.text, this.accent);
  @override
  Widget build(BuildContext context) => Text(text,
    style: TextStyle(color: accent, fontSize: 12,
      fontWeight: FontWeight.w800, fontFamily: 'Tajawal'));
}

class _EmptyChart extends StatelessWidget {
  const _EmptyChart();
  @override
  Widget build(BuildContext context) => Container(
    height: 80,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: AppColors.card, borderRadius: BorderRadius.circular(14)),
    child: Text('لا توجد بيانات بعد', style: TextStyle(
      color: AppColors.textFaint, fontFamily: 'Tajawal', fontSize: 13)),
  );
}
