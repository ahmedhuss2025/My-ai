// lib/screens/chat_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/app_state.dart';
import '../services/ai_service.dart';
import '../services/agent_service.dart';
import '../services/voice_service.dart';
import '../theme/app_theme.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/neural_bar.dart';
import '../widgets/thinking_dots.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with TickerProviderStateMixin {
  final _inputCtrl  = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode  = FocusNode();

  bool _isListening   = false;
  bool _inputHasFocus = false;
  String _agentStatus  = '🟡 جاري الاتصال...';
  String _partialText  = '';     // ← Phase 5: STT partial results

  late AnimationController _micPulse;

  @override
  void initState() {
    super.initState();
    _micPulse = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);

    _focusNode.addListener(() {
      setState(() => _inputHasFocus = _focusNode.hasFocus);
    });

    _loadHistory();
    _checkAgent();

    // Phase 5: init voice
    VoiceService.instance.init();
  }

  @override
  void dispose() {
    _micPulse.dispose();
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // ── Load history from SQLite ──────────────────
  Future<void> _loadHistory() async {
    final history = await AIService.instance.loadHistory();
    if (!mounted) return;
    final state = context.read<AppState>();
    for (final msg in history) {
      state.addMessage(msg);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollBottom(animated: false));
  }

  // ── Check agent connectivity ──────────────────
  Future<void> _checkAgent() async {
    final svc    = AgentService.instance;
    final online = await svc.checkAgent();
    if (!mounted) return;
    String status;
    if (!online) {
      status = '🟡 Offline Mode';
    } else if (svc.gemmaOnline) {
      status = '🟢 Gemma On-Device';
    } else {
      status = '🟢 ${svc.backendName}';
    }
    setState(() => _agentStatus = status);
  }

  void _scrollBottom({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      if (animated) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 320),
          curve: Curves.easeOut,
        );
      } else {
        _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
      }
    });
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;

    _inputCtrl.clear();
    _focusNode.unfocus();
    HapticFeedback.lightImpact();

    final state = context.read<AppState>();

    // Save user message to SQLite + add to UI
    final userMsg = await AIService.instance.saveUserMessage(text);
    state.addMessage(userMsg);
    state.setThinking(true);
    _scrollBottom();

    // Get AI response (Agent → SQLite → UI)
    final aiMsg = await AIService.instance.chat(text, state);
    state.addMessage(aiMsg);
    state.setThinking(false);
    _scrollBottom();

    // Refresh agent status indicator
    _checkAgent();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = Theme.of(context).colorScheme.primary;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: Column(
        children: [
          _buildHeader(isDark, accent),
          const NeuralBar(),
          Expanded(child: _buildBody(isDark, accent)),
          _buildInput(isDark, accent),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _buildHeader(bool isDark, Color accent) {
    return Container(
      padding: EdgeInsets.fromLTRB(
          16, MediaQuery.of(context).padding.top + 10, 16, 12),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : Colors.white,
        border: Border(bottom: BorderSide(
          color: isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.06))),
      ),
      child: Row(
        children: [
          // Agent avatar with pulse
          Stack(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [accent, AppColors.teal],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 12)],
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 20),
              ),
              Positioned(
                bottom: 0, right: 0,
                child: Container(
                  width: 11, height: 11,
                  decoration: BoxDecoration(
                    color: AppColors.green,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isDark ? AppColors.darkSurface : Colors.white, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Personal AI OS',
                  style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : Colors.black87,
                    fontFamily: 'Tajawal',
                  )),
                Text('محلي • مشفر • جاهز',
                  style: TextStyle(
                    fontSize: 11,
                    color: isDark ? Colors.white38 : Colors.black38,
                    fontFamily: 'Tajawal',
                  )),
              ],
            ),
          ),

          // Agent status badge
          GestureDetector(
            onTap: _checkAgent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _agentStatus.contains('🟢')
                    ? const Color(0xFF00FF9D).withOpacity(0.1)
                    : const Color(0xFFFF6B35).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _agentStatus.contains('🟢')
                    ? const Color(0xFF00FF9D).withOpacity(0.3)
                    : const Color(0xFFFF6B35).withOpacity(0.3)),
              ),
              child: Text(
                _agentStatus,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                    fontFamily: 'Tajawal'),
              ),
            ),
          ),
          const SizedBox(width: 6),

          // Message count badge
          Consumer<AppState>(
            builder: (_, state, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accent.withOpacity(0.2)),
              ),
              child: Text(
                '${state.messages.length} رسالة',
                style: TextStyle(fontSize: 11, color: accent,
                    fontWeight: FontWeight.w700, fontFamily: 'Tajawal'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Body ──
  Widget _buildBody(bool isDark, Color accent) {
    return Consumer<AppState>(
      builder: (_, state, __) {
        if (state.messages.isEmpty) {
          return _buildEmpty(isDark, accent);
        }
        return ListView.builder(
          controller: _scrollCtrl,
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
          itemCount: state.messages.length + (state.isThinking ? 1 : 0),
          itemBuilder: (_, i) {
            if (i == state.messages.length) {
              return const Padding(
                padding: EdgeInsets.only(top: 4, bottom: 8),
                child: ThinkingDots(),
              );
            }
            final msg = state.messages[i];
            final showDate = i == 0 ||
                state.messages[i - 1].timestamp.day != msg.timestamp.day;
            return Column(
              children: [
                if (showDate) _DateDivider(date: msg.timestamp),
                ChatBubble(message: msg, accent: accent),
              ],
            );
          },
        );
      },
    );
  }

  // ── Empty state ──
  Widget _buildEmpty(bool isDark, Color accent) {
    final suggestions = ['📅 نظم يومي', '🔍 ابحثلي عن حاجة',
                          '📚 علمني حاجة', '💡 حسّن إنتاجيتي'];
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Pulsing avatar
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.9, end: 1.08),
              duration: const Duration(seconds: 2),
              curve: Curves.easeInOut,
              builder: (_, s, child) => Transform.scale(scale: s, child: child),
              child: Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [accent, AppColors.teal, AppColors.green],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [BoxShadow(
                    color: accent.withOpacity(0.4), blurRadius: 35, spreadRadius: 5)],
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 40),
              ),
            ),
            const SizedBox(height: 24),
            Text('أهلاً! أنا هنا 👋',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900,
                  color: accent, fontFamily: 'Tajawal')),
            const SizedBox(height: 8),
            Text('اسألني أي حاجة — كل شيء على فونك محلياً',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, height: 1.6,
                  color: isDark ? Colors.white38 : Colors.black38,
                  fontFamily: 'Tajawal')),
            const SizedBox(height: 28),
            Wrap(
              spacing: 8, runSpacing: 8, alignment: WrapAlignment.center,
              children: suggestions.map((s) => GestureDetector(
                onTap: () {
                  _inputCtrl.text = s.substring(2).trim();
                  _send();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accent.withOpacity(0.2)),
                  ),
                  child: Text(s, style: TextStyle(fontSize: 13, color: accent,
                      fontFamily: 'Tajawal')),
                ),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  // ── Input ──
  Widget _buildInput(bool isDark, Color accent) {
    return Container(
      padding: EdgeInsets.fromLTRB(
          12, 8, 12, MediaQuery.of(context).padding.bottom + 8),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : Colors.white,
        border: Border(top: BorderSide(
          color: isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.06))),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Mic
          AnimatedBuilder(
            animation: _micPulse,
            builder: (_, __) => GestureDetector(
              onTap: _toggleMic,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 42, height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isListening
                      ? AppColors.red.withOpacity(0.1 + 0.08 * _micPulse.value)
                      : (isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.05)),
                  border: Border.all(
                    color: _isListening
                        ? AppColors.red.withOpacity(0.5) : Colors.transparent,
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  _isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                  size: 20,
                  color: _isListening
                      ? AppColors.red
                      : (isDark ? Colors.white38 : Colors.black38),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Text field
          Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              constraints: const BoxConstraints(maxHeight: 130),
              decoration: BoxDecoration(
                color: isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.05),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: _inputHasFocus ? accent.withOpacity(0.4) : Colors.transparent,
                  width: 1.5,
                ),
              ),
              child: TextField(
                controller: _inputCtrl,
                focusNode: _focusNode,
                maxLines: null,
                textDirection: TextDirection.rtl,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                style: TextStyle(
                  fontSize: 14, height: 1.4,
                  color: isDark ? Colors.white87 : Colors.black87,
                  fontFamily: 'Tajawal',
                ),
                decoration: InputDecoration(
                  hintText: _isListening
                      ? (_partialText.isNotEmpty ? _partialText : '🎙️ بتسمعك...')
                      : 'اكتب رسالتك...',
                  hintStyle: TextStyle(
                    fontSize: 14,
                    color: isDark ? Colors.white24 : Colors.black26,
                    fontFamily: 'Tajawal',
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 11),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Send
          GestureDetector(
            onTap: _send,
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [accent, AppColors.teal],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
                boxShadow: [BoxShadow(
                  color: accent.withOpacity(0.4), blurRadius: 12, spreadRadius: 1)],
              ),
              child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ── Voice toggle ──────────────────────────────
  Future<void> _toggleMic() async {
    final voice = VoiceService.instance;

    if (_isListening) {
      // إيقاف الاستماع
      await voice.stopListening();
      setState(() { _isListening = false; _partialText = ''; });
      return;
    }

    if (!voice.sttReady) {
      _showVoiceError('الميكروفون مش متاح — تأكد من الإذن');
      return;
    }

    // وقّف الـ TTS لو شغّال
    if (voice.isSpeaking) await voice.stop();

    setState(() { _isListening = true; _partialText = ''; });
    HapticFeedback.mediumImpact();

    await voice.startListening(
      onPartial: (partial) {
        setState(() => _partialText = partial);
        _inputCtrl.text = partial;
        _inputCtrl.selection = TextSelection.fromPosition(
          TextPosition(offset: _inputCtrl.text.length));
      },
      onResult: (text) {
        setState(() { _isListening = false; _partialText = ''; });
        if (text.isNotEmpty) {
          _inputCtrl.text = text;
          _inputCtrl.selection = TextSelection.fromPosition(
            TextPosition(offset: text.length));
          // إرسال تلقائي
          Future.delayed(const Duration(milliseconds: 300), _send);
        }
      },
    );
  }

  void _showVoiceError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Tajawal')),
      backgroundColor: AppColors.red,
      behavior: SnackBarBehavior.floating,
    ));
  }
}

// ── Date Divider ──
class _DateDivider extends StatelessWidget {
  final DateTime date;
  const _DateDivider({required this.date});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    String label;
    if (date.day == now.day && date.month == now.month) label = 'اليوم';
    else if (date.day == now.day - 1) label = 'أمس';
    else label = '${date.day}/${date.month}/${date.year}';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        children: [
          Expanded(child: Divider(color: Colors.white.withOpacity(0.06), height: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(label, style: TextStyle(
              fontSize: 11, color: Colors.white.withOpacity(0.25),
              fontFamily: 'Tajawal',
            )),
          ),
          Expanded(child: Divider(color: Colors.white.withOpacity(0.06), height: 1)),
        ],
      ),
    );
  }
}
