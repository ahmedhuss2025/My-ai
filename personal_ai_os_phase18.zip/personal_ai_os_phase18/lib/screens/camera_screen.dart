// lib/screens/camera_screen.dart — Phase 12
// ══════════════════════════════════════════════════
// شاشة الصور — توليد + تعديل + معرض
// ══════════════════════════════════════════════════
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/image_service.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final _promptCtrl = TextEditingController();
  String _style     = 'realistic';
  String _editOp    = 'grayscale';
  String _selectedFilename = '';
  bool   _showEditPanel    = false;

  final _styles = ['realistic', 'cartoon', 'sketch', 'watercolor'];
  final _editOps = {
    'grayscale':  'أبيض وأسود',
    'blur':       'ضبابية',
    'brightness': 'إضاءة',
    'contrast':   'تباين',
    'resize':     'تغيير الحجم',
    'rotate':     'تدوير',
  };

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    ImageService.instance.loadGallery();
  }

  @override
  void dispose() {
    _tab.dispose();
    _promptCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark  = Theme.of(context).brightness == Brightness.dark;
    final accent  = context.watch<AppState>().accentColor;
    final imgSvc  = context.watch<ImageService>();

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
      body: SafeArea(
        child: Column(children: [

          // ── Header ──
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              Icon(Icons.auto_awesome_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text('الصور الذكية',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                  color: Colors.white, fontFamily: 'Tajawal')),
              const Spacer(),
              Text('${imgSvc.gallery.length} صورة',
                style: TextStyle(fontSize: 12, color: Colors.white38,
                  fontFamily: 'Tajawal')),
            ]),
          ),

          const SizedBox(height: 12),

          // ── Tabs ──
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TabBar(
              controller: _tab,
              indicatorSize: TabBarIndicatorSize.tab,
              indicator: BoxDecoration(
                color: accent.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: accent.withOpacity(0.5)),
              ),
              labelStyle: const TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w700, fontSize: 13),
              unselectedLabelStyle: const TextStyle(fontFamily: 'Tajawal', fontSize: 12),
              labelColor: accent,
              unselectedLabelColor: Colors.white38,
              tabs: const [
                Tab(text: '✨ توليد'),
                Tab(text: '🖼️ معرض'),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // ── Tab views ──
          Expanded(
            child: TabBarView(
              controller: _tab,
              children: [
                _buildGenerateTab(accent, imgSvc),
                _buildGalleryTab(accent, imgSvc),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  // ── Generate Tab ─────────────────────────────────
  Widget _buildGenerateTab(Color accent, ImageService imgSvc) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Prompt field
        Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accent.withOpacity(0.2)),
          ),
          child: TextField(
            controller: _promptCtrl,
            maxLines: 3,
            textDirection: TextDirection.rtl,
            style: const TextStyle(color: Colors.white, fontFamily: 'Tajawal', fontSize: 14),
            decoration: InputDecoration(
              hintText: 'صف الصورة اللي عايزها...\nمثال: قطة فضائية على القمر بألوان زاهية',
              hintStyle: const TextStyle(color: Colors.white30, fontFamily: 'Tajawal', fontSize: 13),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              suffixIcon: IconButton(
                icon: Icon(Icons.clear, color: Colors.white24, size: 18),
                onPressed: () => _promptCtrl.clear(),
              ),
            ),
          ),
        ),

        const SizedBox(height: 14),

        // Style selector
        Text('الأسلوب:', style: TextStyle(color: Colors.white60,
          fontSize: 12, fontFamily: 'Tajawal')),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: _styles.map((s) {
            final sel = s == _style;
            return GestureDetector(
              onTap: () => setState(() => _style = s),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: sel ? accent.withOpacity(0.2) : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: sel ? accent : Colors.white12),
                ),
                child: Text(
                  {'realistic':'واقعي','cartoon':'كرتون','sketch':'رسم','watercolor':'ألوان مائية'}[s] ?? s,
                  style: TextStyle(fontSize: 12, color: sel ? accent : Colors.white54,
                    fontFamily: 'Tajawal', fontWeight: sel ? FontWeight.w700 : FontWeight.normal),
                ),
              ),
            );
          }).toList(),
        ),

        const SizedBox(height: 20),

        // Generate button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: imgSvc.loading ? null : _generate,
            style: ElevatedButton.styleFrom(
              backgroundColor: accent,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: imgSvc.loading
                ? const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Text('✨ ولّد الصورة', style: TextStyle(
                    fontFamily: 'Tajawal', fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ),

        const SizedBox(height: 20),

        // Last generated image
        if (imgSvc.last != null) ...[
          Text('آخر صورة مُولَّدة:', style: TextStyle(color: Colors.white60,
            fontSize: 12, fontFamily: 'Tajawal')),
          const SizedBox(height: 8),
          _ImageCard(image: imgSvc.last!, accent: accent, onEdit: _showEdit),
          const SizedBox(height: 20),
        ],

        // Edit panel
        if (_showEditPanel && _selectedFilename.isNotEmpty)
          _EditPanel(
            filename: _selectedFilename,
            accent:   accent,
            ops:      _editOps,
            onApply:  _applyEdit,
            onClose:  () => setState(() => _showEditPanel = false),
          ),

        const SizedBox(height: 30),
      ]),
    );
  }

  // ── Gallery Tab ──────────────────────────────────
  Widget _buildGalleryTab(Color accent, ImageService imgSvc) {
    if (imgSvc.gallery.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.image_not_supported_rounded, size: 48, color: Colors.white12),
          const SizedBox(height: 12),
          Text('لا توجد صور بعد\nولّد صورتك الأولى!',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white30, fontFamily: 'Tajawal', fontSize: 14)),
        ]),
      );
    }

    return RefreshIndicator(
      color: accent,
      onRefresh: imgSvc.loadGallery,
      child: GridView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1,
        ),
        itemCount: imgSvc.gallery.length,
        itemBuilder: (ctx, i) {
          final item = imgSvc.gallery[i];
          return GestureDetector(
            onLongPress: () => _showEdit(item.filename),
            child: _GalleryTile(item: item, accent: accent, imgSvc: imgSvc),
          );
        },
      ),
    );
  }

  // ── Actions ──────────────────────────────────────
  Future<void> _generate() async {
    final prompt = _promptCtrl.text.trim();
    if (prompt.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب وصف الصورة أولاً',
          style: TextStyle(fontFamily: 'Tajawal'))));
      return;
    }
    await ImageService.instance.generate(
      prompt: prompt, style: _style, size: '512x512');
    _tab.animateTo(0);
  }

  void _showEdit(String filename) {
    setState(() {
      _selectedFilename = filename;
      _showEditPanel    = true;
    });
    _tab.animateTo(0);
  }

  Future<void> _applyEdit(String filename, String op, Map<String, dynamic> params) async {
    await ImageService.instance.edit(
      filename: filename, operation: op, params: params);
    setState(() => _showEditPanel = false);
  }
}


// ── _ImageCard ────────────────────────────────────
class _ImageCard extends StatelessWidget {
  final GeneratedImage image;
  final Color          accent;
  final Function(String) onEdit;
  const _ImageCard({required this.image, required this.accent, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.3)),
        color: Colors.black,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Image
        AspectRatio(
          aspectRatio: 1,
          child: image.base64.isNotEmpty
              ? Image.memory(image.bytes, fit: BoxFit.cover)
              : Container(color: Colors.white10,
                  child: const Icon(Icons.image, color: Colors.white12, size: 48)),
        ),
        // Info
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(image.prompt, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'Tajawal')),
            const SizedBox(height: 6),
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(image.provider, style: TextStyle(fontSize: 9, color: accent,
                  fontFamily: 'monospace')),
              ),
              const SizedBox(width: 6),
              Text('${image.sizeKb}KB', style: const TextStyle(
                fontSize: 10, color: Colors.white30, fontFamily: 'Tajawal')),
              const Spacer(),
              GestureDetector(
                onTap: () => onEdit(image.filename),
                child: Icon(Icons.edit_rounded, color: accent.withOpacity(0.7), size: 18),
              ),
            ]),
          ]),
        ),
      ]),
    );
  }
}


// ── _GalleryTile ─────────────────────────────────
class _GalleryTile extends StatelessWidget {
  final ImageItem    item;
  final Color        accent;
  final ImageService imgSvc;
  const _GalleryTile({required this.item, required this.accent, required this.imgSvc});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: imgSvc.getImageBytes(item.filename),
      builder: (ctx, snap) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.white.withOpacity(0.03),
            border: Border.all(color: Colors.white10),
          ),
          clipBehavior: Clip.antiAlias,
          child: snap.hasData && snap.data != null
              ? Stack(fit: StackFit.expand, children: [
                  Image.memory(snap.data!, fit: BoxFit.cover),
                  Positioned(bottom: 0, left: 0, right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Colors.black87, Colors.transparent],
                        ),
                      ),
                      child: Text(item.ts, style: const TextStyle(
                        fontSize: 9, color: Colors.white54, fontFamily: 'Tajawal')),
                    )),
                ])
              : Center(child: CircularProgressIndicator(
                  strokeWidth: 1.5, color: accent.withOpacity(0.4))),
        );
      },
    );
  }
}


// ── _EditPanel ────────────────────────────────────
class _EditPanel extends StatefulWidget {
  final String filename;
  final Color  accent;
  final Map<String, String> ops;
  final Function(String, String, Map<String, dynamic>) onApply;
  final VoidCallback onClose;
  const _EditPanel({required this.filename, required this.accent,
    required this.ops, required this.onApply, required this.onClose});
  @override
  State<_EditPanel> createState() => _EditPanelState();
}

class _EditPanelState extends State<_EditPanel> {
  String _op    = 'grayscale';
  double _value = 1.2;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: widget.accent.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('✏️ تعديل الصورة', style: TextStyle(color: widget.accent,
            fontWeight: FontWeight.w700, fontFamily: 'Tajawal', fontSize: 14)),
          const Spacer(),
          GestureDetector(onTap: widget.onClose,
            child: const Icon(Icons.close, color: Colors.white38, size: 18)),
        ]),
        const SizedBox(height: 12),

        // Op selector
        Wrap(
          spacing: 6, runSpacing: 6,
          children: widget.ops.entries.map((e) {
            final sel = e.key == _op;
            return GestureDetector(
              onTap: () => setState(() => _op = e.key),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: sel ? widget.accent.withOpacity(0.2) : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: sel ? widget.accent : Colors.white12),
                ),
                child: Text(e.value, style: TextStyle(fontSize: 11,
                  color: sel ? widget.accent : Colors.white54, fontFamily: 'Tajawal')),
              ),
            );
          }).toList(),
        ),

        if (['brightness','contrast','blur'].contains(_op)) ...[
          const SizedBox(height: 10),
          Text('القيمة: ${_value.toStringAsFixed(1)}',
            style: const TextStyle(fontSize: 11, color: Colors.white54, fontFamily: 'Tajawal')),
          Slider(
            value: _value, min: 0.1, max: 3.0,
            activeColor: widget.accent,
            onChanged: (v) => setState(() => _value = v),
          ),
        ],

        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () => widget.onApply(widget.filename, _op, {
              'factor': _value, 'radius': _value, 'angle': 90.0,
              'width': 256, 'height': 256,
            }),
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.accent,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('✅ تطبيق التعديل', style: TextStyle(
              fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
          ),
        ),
      ]),
    );
  }
}
