// lib/screens/dashboard_screen.dart
// ══════════════════════════════════════════════════
// Dashboard — لوحة التحكم الرئيسية
// ══════════════════════════════════════════════════
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../services/agent_service.dart';
import '../services/ambient_service.dart';
import '../theme/app_theme.dart';

const _cyan   = Color(0xFF00C8FF);
const _teal   = Color(0xFF00E5CC);
const _green  = Color(0xFF00FF9D);
const _purple = Color(0xFF9D4EDD);
const _orange = Color(0xFFFF6B35);
const _bg     = Color(0xFF050810);
const _card   = Color(0xFF0A1228);

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {

  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

    // Refresh real stats from SQLite when dashboard opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppState>().loadStats();
    });
  }

  @override
  void dispose() { _pulse.dispose(); super.dispose(); }

  // ── Data ─────────────────────────────────────────
  static const _quickActions = [
    ('📅', 'جدول اليوم',    _cyan),
    ('💾', 'نسخ احتياطي',  _teal),
    ('🔍', 'بحث ذكي',       _purple),
    ('📊', 'إحصائيات',      _orange),
  ];

  static const _insights = [
    ('⚡', 'إنتاجيتك أعلى من المعدل بـ 34%', 'هذا الأسبوع', _green),
    ('🌙', 'معظم رسائلك بعد الساعة 10 مساءً', 'عادة ثابتة', _purple),
    ('📈', 'أكملت 4 من 7 مهام اليوم', '57% إنجاز', _cyan),
    ('🔋', 'الشبكة العصبية: جاهزة', 'Offline mode', _teal),
  ];

  @override
  Widget build(BuildContext context) {
    final mq     = MediaQuery.of(context);
    final state  = context.watch<AppState>();
    final accent = state.accentColor;
    final now    = DateTime.now();

    return Scaffold(
      backgroundColor: _bg,
      body: CustomScrollView(
        slivers: [
          // ── App Bar ──
          SliverAppBar(
            expandedHeight: 140,
            backgroundColor: const Color(0xFF080D1A),
            pinned: true,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFF080D1A),
                ),
                child: Padding(
                  padding: EdgeInsets.fromLTRB(20, mq.padding.top + 12, 20, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        _greeting(now),
                        style: TextStyle(
                          fontSize: 13, color: accent.withOpacity(0.8),
                          fontWeight: FontWeight.w600, fontFamily: 'Tajawal',
                        ),
                      ),
                      const SizedBox(height: 4),
                      ShaderMask(
                        shaderCallback: (b) => LinearGradient(
                          colors: [accent, _teal],
                        ).createShader(b),
                        child: const Text(
                          'لوحة التحكم',
                          style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900,
                            color: Colors.white, fontFamily: 'Tajawal',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),
              child: Container(height: 1, color: Colors.white.withOpacity(0.06)),
            ),
          ),

          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, mq.padding.bottom + 80),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── Neural Status ──
                _NeuralCard(pulse: _pulse, accent: accent, state: state),
                const SizedBox(height: 16),

                // ── Stats Row ──
                _StatsRow(state: state, accent: accent),
                const SizedBox(height: 20),

                // ── Quick Actions ──
                _SectionTitle(title: 'إجراءات سريعة', accent: accent),
                const SizedBox(height: 10),
                _QuickActions(actions: _quickActions, accent: accent),
                const SizedBox(height: 20),

                // ── Ambient Insights — Phase 9 ──
                _SectionTitle(title: '🧠 تحليل عاداتك', accent: accent),
                const SizedBox(height: 10),
                _AmbientInsightsCard(accent: accent),
                const SizedBox(height: 20),

                // ── Insights ──
                _SectionTitle(title: 'تحليلات ذكية', accent: accent),
                const SizedBox(height: 10),
                ..._insights.map((ins) => _InsightTile(
                  icon: ins.$1, title: ins.$2,
                  sub: ins.$3, color: ins.$4,
                )),

                const SizedBox(height: 10),
                // ── Model Info ──
                _ModelInfoCard(accent: accent),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  String _greeting(DateTime now) {
    if (now.hour < 12) return '🌅 صباح الخير';
    if (now.hour < 17) return '☀️ مرحباً';
    if (now.hour < 21) return '🌆 مساء الخير';
    return '🌙 مساء النور';
  }
}

// ── Neural Status Card ────────────────────────────
class _NeuralCard extends StatelessWidget {
  final AnimationController pulse;
  final Color accent;
  final AppState state;
  const _NeuralCard({required this.pulse, required this.accent, required this.state});

  @override
  Widget build(BuildContext context) {
    final pred = state.lastPrediction;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.07)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: pulse,
                builder: (_, child) => Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _green,
                    boxShadow: [BoxShadow(
                      color: _green.withOpacity(0.3 + 0.3 * pulse.value),
                      blurRadius: 8,
                    )],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text('الشبكة العصبية — نشطة',
                style: TextStyle(
                  fontSize: 12, color: _green,
                  fontWeight: FontWeight.w700, fontFamily: 'Tajawal',
                )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: accent.withOpacity(0.2)),
                ),
                child: Text('101K params',
                  style: TextStyle(
                    fontSize: 9, color: accent, fontWeight: FontWeight.w700,
                    fontFamily: 'monospace',
                  )),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _PredBadge(
                label: pred.sentimentLabel,
                color: pred.color,
                confidence: pred.sentimentConfidence,
              ),
              const SizedBox(width: 8),
              if (pred.behaviorLabels.isNotEmpty)
                Expanded(
                  child: Text(
                    pred.behaviorLabels.first,
                    style: TextStyle(
                      fontSize: 12, color: Colors.white.withOpacity(0.45),
                      fontFamily: 'Tajawal',
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PredBadge extends StatelessWidget {
  final String label;
  final Color color;
  final double confidence;
  const _PredBadge({required this.label, required this.color, required this.confidence});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 6, height: 6,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(
            fontSize: 12, color: color, fontWeight: FontWeight.w700,
            fontFamily: 'Tajawal',
          )),
          const SizedBox(width: 6),
          Text('${(confidence * 100).round()}%',
            style: TextStyle(fontSize: 10, color: color.withOpacity(0.6),
              fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Stats Row ─────────────────────────────────────
class _StatsRow extends StatelessWidget {
  final AppState state;
  final Color accent;
  const _StatsRow({required this.state, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _StatBox(
          icon: '💬', value: '${state.todayMessages}',
          label: 'رسائل اليوم', color: accent),
        const SizedBox(width: 10),
        _StatBox(
          icon: '✅', value: '${state.goalsCompleted}/${state.goalsTotal > 0 ? state.goalsTotal : "—"}',
          label: 'مهام', color: _green),
        const SizedBox(width: 10),
        _StatBox(
          icon: '🔥', value: '${state.streakDays}',
          label: 'Streak', color: _teal),
      ],
    );
  }
}

class _StatBox extends StatelessWidget {
  final String icon, value, label;
  final Color color;
  const _StatBox({required this.icon, required this.value,
    required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.12)),
        ),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 6),
            Text(value, style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w900,
              color: color, fontFamily: 'Tajawal',
            )),
            Text(label, style: TextStyle(
              fontSize: 10, color: Colors.white.withOpacity(0.35),
              fontFamily: 'Tajawal',
            )),
          ],
        ),
      ),
    );
  }
}

// ── Section Title ─────────────────────────────────
class _SectionTitle extends StatelessWidget {
  final String title;
  final Color accent;
  const _SectionTitle({required this.title, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 3, height: 16,
          decoration: BoxDecoration(
            color: accent, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 10),
        Text(title, style: const TextStyle(
          fontSize: 15, fontWeight: FontWeight.w800,
          color: Colors.white, fontFamily: 'Tajawal',
        )),
      ],
    );
  }
}

// ── Quick Actions ─────────────────────────────────
class _QuickActions extends StatelessWidget {
  final List<(String, String, Color)> actions;
  final Color accent;
  const _QuickActions({required this.actions, required this.accent});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 0.85,
      children: actions.map((a) => GestureDetector(
        onTap: () => HapticFeedback.lightImpact(),
        child: Container(
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: a.$3.withOpacity(0.15)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(a.$1, style: const TextStyle(fontSize: 24)),
              const SizedBox(height: 6),
              Text(a.$2,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10, color: a.$3,
                  fontWeight: FontWeight.w700, fontFamily: 'Tajawal',
                )),
            ],
          ),
        ),
      )).toList(),
    );
  }
}

// ── Insight Tile ──────────────────────────────────
class _InsightTile extends StatelessWidget {
  final String icon, title, sub;
  final Color color;
  const _InsightTile({required this.icon, required this.title,
    required this.sub, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(child: Text(icon, style: const TextStyle(fontSize: 18))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                  fontSize: 13, fontWeight: FontWeight.w700,
                  color: Colors.white, fontFamily: 'Tajawal',
                )),
                Text(sub, style: TextStyle(
                  fontSize: 11, color: color.withOpacity(0.7),
                  fontFamily: 'Tajawal',
                )),
              ],
            ),
          ),
          Icon(Icons.arrow_back_ios_rounded, size: 14, color: Colors.white.withOpacity(0.2)),
        ],
      ),
    );
  }
}

// ── Model Info Card ───────────────────────────────
class _ModelInfoCard extends StatefulWidget {
  final Color accent;
  const _ModelInfoCard({required this.accent});
  @override
  State<_ModelInfoCard> createState() => _ModelInfoCardState();
}

class _ModelInfoCardState extends State<_ModelInfoCard> {
  String  _backendName  = '...';
  bool    _gemmaOnline  = false;
  bool    _agentOnline  = false;
  bool    _loading      = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final svc = AgentService.instance;
    final ok  = await svc.checkAgent();
    if (mounted) setState(() {
      _agentOnline  = ok;
      _gemmaOnline  = svc.gemmaOnline;
      _backendName  = ok ? svc.backendName : 'Offline';
      _loading      = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.accent;
    final statusColor  = _agentOnline ? _green   : _orange;
    final gemmaColor   = _gemmaOnline ? _green   : _orange;
    final statusLabel  = _agentOnline ? 'متصل'   : 'offline';
    final gemmaLabel   = _gemmaOnline ? 'On-Device ✅' : 'Fallback ⚡';

    return GestureDetector(
      onTap: _refresh,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [accent.withOpacity(0.06), _teal.withOpacity(0.04)],
            begin: Alignment.topRight, end: Alignment.bottomLeft,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: accent.withOpacity(0.12)),
        ),
        child: Column(
          children: [
            // Row 1: Agent status
            Row(children: [
              const Text('🤖', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_loading ? 'جاري الفحص...' : _backendName,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800,
                      color: Colors.white, fontFamily: 'Tajawal')),
                  Text('Agent :7070', style: TextStyle(fontSize: 11,
                    color: accent.withOpacity(0.6), fontFamily: 'monospace')),
                ],
              )),
              _StatusBadge(label: statusLabel, color: statusColor),
            ]),

            const SizedBox(height: 10),
            Divider(color: Colors.white.withOpacity(0.06), height: 1),
            const SizedBox(height: 10),

            // Row 2: Gemma on-device status
            Row(children: [
              const Text('🧠', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Gemma 2B-IT',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800,
                      color: Colors.white, fontFamily: 'Tajawal')),
                  Text('On-Device :8080  |  ~1.5GB', style: TextStyle(
                    fontSize: 11, color: accent.withOpacity(0.6), fontFamily: 'monospace')),
                ],
              )),
              _StatusBadge(label: gemmaLabel, color: gemmaColor),
            ]),

            // Hint لو Gemma offline
            if (!_gemmaOnline && !_loading) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _orange.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _orange.withOpacity(0.15)),
                ),
                child: const Text(
                  '📁 ضع الموديل في:\n/sdcard/models/gemma-2b-it-gpu-int4.bin\nثم فعّل Background Service من الإعدادات',
                  style: TextStyle(fontSize: 11, color: _orange,
                    fontFamily: 'Tajawal', height: 1.5),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color  color;
  const _StatusBadge({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: color.withOpacity(0.25)),
    ),
    child: Text(label, style: TextStyle(fontSize: 11, color: color,
      fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
  );
}

// ══════════════════════════════════════════════════
// Ambient Insights Card — Phase 9
// ══════════════════════════════════════════════════
class _AmbientInsightsCard extends StatefulWidget {
  final Color accent;
  const _AmbientInsightsCard({required this.accent});
  @override
  State<_AmbientInsightsCard> createState() => _AmbientInsightsCardState();
}

class _AmbientInsightsCardState extends State<_AmbientInsightsCard> {
  @override
  void initState() {
    super.initState();
    AmbientService.instance.addListener(_onUpdate);
    AmbientService.instance.fetchInsights();
  }

  @override
  void dispose() {
    AmbientService.instance.removeListener(_onUpdate);
    super.dispose();
  }

  void _onUpdate() { if (mounted) setState(() {}); }

  Color _cardColor(String name) {
    return switch (name) {
      'green'  => const Color(0xFF00FF9D),
      'orange' => const Color(0xFFFF6B35),
      'cyan'   => const Color(0xFF00C8FF),
      'purple' => const Color(0xFF9D4EDD),
      'blue'   => const Color(0xFF4488FF),
      _        => const Color(0xFF00C8FF),
    };
  }

  @override
  Widget build(BuildContext context) {
    final svc    = AmbientService.instance;
    final cards  = svc.cards;
    final accent = widget.accent;

    if (svc.loading && cards.isEmpty) {
      return Container(
        height: 80,
        decoration: BoxDecoration(
          color: const Color(0xFF0D1520),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accent.withOpacity(0.12)),
        ),
        child: Center(child: SizedBox(
          width: 20, height: 20,
          child: CircularProgressIndicator(strokeWidth: 2, color: accent),
        )),
      );
    }

    if (cards.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF0D1520),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accent.withOpacity(0.12)),
        ),
        child: Column(children: [
          Text('لا توجد insights بعد',
            style: TextStyle(fontSize: 13, color: Colors.grey[500],
              fontFamily: 'Tajawal')),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () async {
              await svc.triggerAnalysis();
              await Future.delayed(const Duration(seconds: 2));
              svc.fetchInsights(force: true);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: accent.withOpacity(0.3)),
              ),
              child: Text('🔍 حلّل عاداتي',
                style: TextStyle(fontSize: 13, color: accent,
                  fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
            ),
          ),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.12)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Row(children: [
          Expanded(
            child: Text('بناءً على ${svc.profile?.topTopics.length ?? 0} اهتمامات',
              style: TextStyle(fontSize: 11, color: Colors.grey[500],
                fontFamily: 'Tajawal')),
          ),
          GestureDetector(
            onTap: () => svc.fetchInsights(force: true),
            child: Icon(Icons.refresh_rounded, size: 16, color: accent.withOpacity(0.6)),
          ),
        ]),
        const SizedBox(height: 12),

        // Cards grid (2 columns)
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount:  2,
            childAspectRatio: 2.6,
            crossAxisSpacing: 8,
            mainAxisSpacing:  8,
          ),
          itemCount: cards.length,
          itemBuilder: (_, i) {
            final c     = cards[i];
            final color = _cardColor(c.color);
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color.withOpacity(0.2)),
              ),
              child: Row(children: [
                Text(c.icon, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(c.title, style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.w700, color: color,
                      fontFamily: 'Tajawal'),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                    Text(c.subtitle, style: const TextStyle(fontSize: 9,
                      color: Colors.white38, fontFamily: 'Tajawal'),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  ],
                )),
              ]),
            );
          },
        ),

        // Profile context hint
        if (svc.context.isNotEmpty) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('🤖 ', style: TextStyle(fontSize: 13, color: accent)),
              Expanded(child: Text(svc.context,
                style: const TextStyle(fontSize: 11, color: Colors.white60,
                  fontFamily: 'Tajawal', height: 1.5),
                maxLines: 3, overflow: TextOverflow.ellipsis)),
            ]),
          ),
        ],
      ]),
    );
  }
}
