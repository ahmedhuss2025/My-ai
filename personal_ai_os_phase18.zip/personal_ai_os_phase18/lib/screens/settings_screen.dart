// lib/screens/settings_screen.dart
// ══════════════════════════════════════════════════
// Settings — إعدادات التطبيق
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/voice_service.dart';
import '../services/screen_service.dart';
import '../services/lora_service.dart';
import '../services/offline_service.dart';
import '../theme/app_theme.dart';

const _cyan   = Color(0xFF00C8FF);
const _teal   = Color(0xFF00E5CC);
const _green  = Color(0xFF00FF9D);
const _purple = Color(0xFF9D4EDD);
const _orange = Color(0xFFFF6B35);
const _red    = Color(0xFFFF3860);
const _card   = Color(0xFF0A1228);

// Platform Channel للـ Android native
const _systemChannel = MethodChannel('personal_ai_os/system');

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Local toggles
  bool _overlayEnabled    = false;
  bool _bgServiceEnabled  = false;
  bool _ambientLearning   = true;
  bool _autoBackup        = true;
  bool _voiceEnabled      = false;
  double _speechSpeed     = 1.0;
  bool _loading           = true;
  // Phase 7 — Screen Intelligence
  bool _screenEnabled     = false;
  bool _accessibilityOn   = false;

  // Accent colors to pick from
  static const _accentOptions = [
    _cyan, _teal, _green, _purple, _orange, _red,
  ];

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  // ── Load persisted settings ───────────────────
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _overlayEnabled   = prefs.getBool('overlay_enabled')      ?? false;
      _bgServiceEnabled = prefs.getBool('service_enabled')      ?? false;
      _autoBackup       = prefs.getBool('auto_backup')          ?? true;
      _voiceEnabled     = prefs.getBool('voice_enabled')        ?? false;
      _ambientLearning  = prefs.getBool('ambient_learning')     ?? true;
      _speechSpeed      = prefs.getDouble('speech_speed')       ?? 1.0;
      _screenEnabled    = prefs.getBool('screen_intelligence')  ?? false;
      _loading          = false;
    });
    // تحقق من حالة الـ accessibility
    if (_screenEnabled) {
      final ok = await ScreenService.instance.checkAccessibility();
      if (mounted) setState(() => _accessibilityOn = ok);
    }
  }

  // ── Overlay toggle ────────────────────────────
  Future<void> _setOverlay(bool v) async {
    setState(() => _overlayEnabled = v);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('overlay_enabled', v);

    try {
      if (v) {
        // طلب Permission لو محتاج
        final hasPermission = await _systemChannel
            .invokeMethod<bool>('checkOverlayPermission') ?? false;
        if (!hasPermission) {
          await _systemChannel.invokeMethod('requestOverlayPermission');
          if (mounted) {
            _showSnack('اتح الإذن من الإعدادات ثم اعد التفعيل', isError: true);
          }
          setState(() => _overlayEnabled = false);
          await prefs.setBool('overlay_enabled', false);
          return;
        }
        await _systemChannel.invokeMethod('showOverlay', {'text': '🤖 AI OS نشط'});
      } else {
        await _systemChannel.invokeMethod('hideOverlay');
      }
    } on PlatformException catch (e) {
      _showSnack('خطأ: ${e.message}', isError: true);
    }
  }

  // ── Background service toggle ─────────────────
  Future<void> _setService(bool v) async {
    setState(() => _bgServiceEnabled = v);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('service_enabled', v);

    try {
      if (v) {
        await _systemChannel.invokeMethod('startForegroundService');
        _showSnack('✅ Background service شغّال');
      } else {
        await _systemChannel.invokeMethod('stopForegroundService');
        _showSnack('⏹ Background service وقف');
      }
    } on PlatformException catch (e) {
      _showSnack('خطأ: ${e.message}', isError: true);
    }
  }

  // ── Auto backup toggle ────────────────────────
  Future<void> _setBackup(bool v) async {
    setState(() => _autoBackup = v);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('auto_backup', v);

    if (v) {
      try {
        await _systemChannel.invokeMethod('scheduleBackup');
        _showSnack('✅ Backup أسبوعي اتجدول');
      } on PlatformException {
        _showSnack('تعذّر جدولة الـ backup', isError: true);
      }
    }
  }

  // ── Voice toggle ──────────────────────────────
  Future<void> _setVoice(bool v) async {
    setState(() => _voiceEnabled = v);
    await VoiceService.instance.setEnabled(v);
    _showSnack(v ? '🎙️ الصوت مفعّل' : '🔇 الصوت موقف');
  }

  // ── Screen Intelligence — Phase 7 ─────────────
  Future<void> _setScreenIntelligence(bool v) async {
    setState(() => _screenEnabled = v);
    if (v) {
      // تحقق من الـ accessibility permission
      final enabled = await ScreenService.instance.checkAccessibility();
      setState(() => _accessibilityOn = enabled);
      if (!enabled) {
        _showSnack('⚠️ فعّل خدمة Screen Intelligence من الإعدادات', isError: true);
      } else {
        _showSnack('📺 Screen Intelligence مفعّل');
      }
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('screen_intelligence', v);
  }

  Future<void> _openAccessibilitySettings() async {
    await ScreenService.instance.requestPermission();
    // بعد ما يرجع → إعادة فحص
    await Future.delayed(const Duration(seconds: 1));
    final enabled = await ScreenService.instance.checkAccessibility();
    if (mounted) setState(() => _accessibilityOn = enabled);
  }

  // ── Snackbar helper ───────────────────────────
  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
        style: const TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
      backgroundColor: isError ? _red : _green,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final mq    = MediaQuery.of(context);
    final state = context.watch<AppState>();
    final accent = state.accentColor;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF050810) : const Color(0xFFF4F8FF),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: isDark ? const Color(0xFF080D1A) : Colors.white,
            pinned: true, elevation: 0,
            expandedHeight: 100,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                padding: EdgeInsets.fromLTRB(20, mq.padding.top + 12, 20, 12),
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: ShaderMask(
                    shaderCallback: (b) => LinearGradient(
                      colors: [accent, _teal]).createShader(b),
                    child: const Text('الإعدادات',
                      style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900,
                        color: Colors.white, fontFamily: 'Tajawal')),
                  ),
                ),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),
              child: Container(height: 1,
                color: isDark ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.06)),
            ),
          ),

          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, mq.padding.bottom + 80),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── Theme ──
                _SectionHeader(title: '🎨  المظهر', accent: accent),
                _SettingsCard(children: [
                  // Theme mode
                  _SettingsTile(
                    icon: Icons.brightness_6_rounded,
                    title: 'وضع العرض',
                    accent: accent,
                    trailing: SegmentedButton<ThemeMode>(
                      segments: const [
                        ButtonSegment(value: ThemeMode.dark,  label: Text('داكن',   style: TextStyle(fontFamily: 'Tajawal', fontSize: 11))),
                        ButtonSegment(value: ThemeMode.light, label: Text('فاتح',   style: TextStyle(fontFamily: 'Tajawal', fontSize: 11))),
                        ButtonSegment(value: ThemeMode.system, label: Text('تلقائي', style: TextStyle(fontFamily: 'Tajawal', fontSize: 11))),
                      ],
                      selected: {state.themeMode},
                      onSelectionChanged: (s) => state.setTheme(s.first),
                      style: ButtonStyle(
                        backgroundColor: WidgetStateProperty.resolveWith((states) =>
                          states.contains(WidgetState.selected)
                            ? accent.withOpacity(0.15) : Colors.transparent),
                        foregroundColor: WidgetStateProperty.resolveWith((states) =>
                          states.contains(WidgetState.selected)
                            ? accent : Colors.white38),
                      ),
                    ),
                  ),
                  const _Divider(),
                  // Accent color
                  _SettingsTile(
                    icon: Icons.palette_rounded,
                    title: 'لون التمييز',
                    accent: accent,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: _accentOptions.map((c) => GestureDetector(
                        onTap: () {
                          state.setAccent(c);
                          HapticFeedback.selectionClick();
                        },
                        child: Container(
                          width: 24, height: 24,
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: c,
                            border: Border.all(
                              color: state.accentColor == c
                                  ? Colors.white : Colors.transparent,
                              width: 2,
                            ),
                            boxShadow: state.accentColor == c
                                ? [BoxShadow(color: c.withOpacity(0.5), blurRadius: 8)]
                                : null,
                          ),
                        ),
                      )).toList(),
                    ),
                  ),
                ]),

                const SizedBox(height: 16),

                // ── Privacy ──
                _SectionHeader(title: '🔒  الخصوصية', accent: accent),
                _SettingsCard(children: [
                  _SwitchTile(
                    icon: Icons.layers_rounded,
                    title: 'Overlay ذكي',
                    subtitle: 'يظهر فوق أي تطبيق',
                    value: _overlayEnabled,
                    accent: accent,
                    onChanged: _setOverlay,
                  ),
                  const _Divider(),
                  _SwitchTile(
                    icon: Icons.settings_backup_restore_rounded,
                    title: 'خدمة الخلفية',
                    subtitle: 'يعمل في الخلفية دايماً',
                    value: _bgServiceEnabled,
                    accent: accent,
                    onChanged: _setService,
                  ),
                ]),

                const SizedBox(height: 16),

                // ── Voice ──
                _SectionHeader(title: '🎙️  الصوت', accent: accent),
                _SettingsCard(children: [
                  _SwitchTile(
                    icon: Icons.mic_rounded,
                    title: 'التعرف على الصوت',
                    subtitle: 'STT + TTS محلي',
                    value: _voiceEnabled,
                    accent: accent,
                    onChanged: _setVoice,
                  ),
                  const _Divider(),
                  _SettingsTile(
                    icon: Icons.speed_rounded,
                    title: 'سرعة الكلام',
                    accent: accent,
                    trailing: SizedBox(
                      width: 160,
                      child: Slider(
                        value: _speechSpeed,
                        min: 0.5, max: 2.0,
                        divisions: 6,
                        activeColor: accent,
                        inactiveColor: accent.withOpacity(0.2),
                        onChanged: (v) {
                          setState(() => _speechSpeed = v);
                          VoiceService.instance.setRate(v * 0.5); // 0.5–1.0 → 0.25–0.5 TTS rate
                        },
                      ),
                    ),
                  ),
                ]),

                const SizedBox(height: 16),

                // ── Screen Intelligence — Phase 7 ──
                _SectionHeader(title: '📺  ذكاء الشاشة', accent: accent),
                _SettingsCard(children: [
                  _SwitchTile(
                    icon: Icons.visibility_rounded,
                    title: 'Screen Intelligence',
                    subtitle: _screenEnabled
                        ? '🟢 يراقب الشاشة ويقترح actions'
                        : 'يفهم ما بتشوفه ويساعدك',
                    value: _screenEnabled,
                    accent: accent,
                    onChanged: _setScreenIntelligence,
                  ),
                  if (_screenEnabled) ...[
                    const _Divider(),
                    _SettingsTile(
                      icon: Icons.bubble_chart_rounded,
                      title: 'Overlay اقتراحات',
                      accent: accent,
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text(_accessibilityOn ? '✅ مفعّل' : '⚠️ محتاج إذن',
                          style: TextStyle(
                            fontSize: 12, fontFamily: 'Tajawal',
                            color: _accessibilityOn ? const Color(0xFF00FF9D) : const Color(0xFFFF6B35),
                          )),
                        const SizedBox(width: 8),
                        if (!_accessibilityOn)
                          GestureDetector(
                            onTap: _openAccessibilitySettings,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: accent.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text('تفعيل', style: TextStyle(
                                fontSize: 12, color: accent, fontFamily: 'Tajawal', fontWeight: FontWeight.w700,
                              )),
                            ),
                          ),
                      ]),
                    ),
                  ],
                ]),

                const SizedBox(height: 16),

                // ── Learning ──
                _SectionHeader(title: '🧠  التعلم', accent: accent),
                _SettingsCard(children: [
                  _SwitchTile(
                    icon: Icons.auto_awesome_rounded,
                    title: 'التعلم التلقائي',
                    subtitle: 'يتعلم من عاداتك محلياً',
                    value: _ambientLearning,
                    accent: accent,
                    onChanged: (v) => setState(() => _ambientLearning = v),
                  ),
                  const _Divider(),
                  _SwitchTile(
                    icon: Icons.cloud_upload_rounded,
                    title: 'نسخ احتياطي أسبوعي',
                    subtitle: 'Google Drive مشفر',
                    value: _autoBackup,
                    accent: accent,
                    onChanged: _setBackup,
                  ),
                  const _Divider(),
                  _ActionTile(
                    icon: Icons.delete_rounded,
                    title: 'مسح بيانات التعلم',
                    color: _red,
                    onTap: () => _showResetDialog(context, accent),
                  ),
                ]),

                const SizedBox(height: 16),

                // ── LoRA Fine-tuning — Phase 8 ──
                _SectionHeader(title: '⚡  تدريب شخصي (LoRA)', accent: accent),
                _LoraTrainingCard(accent: accent),

                const SizedBox(height: 16),

                // ── Offline & Sync — Phase 11 ──
                _SectionHeader(title: '📶  Offline & Sync', accent: accent),
                _OfflineSyncCard(accent: accent),

                const SizedBox(height: 16),

                // ── About ──
                _SectionHeader(title: 'ℹ️  حول', accent: accent),
                _SettingsCard(children: [
                  _InfoTile(label: 'الإصدار',       value: '1.0.0',         accent: accent),
                  const _Divider(),
                  _InfoTile(label: 'النموذج',        value: 'NN v1.0 · 101K', accent: accent),
                  const _Divider(),
                  _InfoTile(label: 'التشفير',        value: 'AES-256-GCM',   accent: accent),
                  const _Divider(),
                  _InfoTile(label: 'Gemma',          value: 'غير محمّل بعد', accent: accent),
                  const _Divider(),
                  _ActionTile(
                    icon: Icons.restart_alt_rounded,
                    title: 'إعادة عرض Onboarding',
                    color: accent,
                    onTap: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setBool('onboarding_done', false);
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text('سيظهر Onboarding عند إعادة التشغيل',
                            style: TextStyle(fontFamily: 'Tajawal')),
                          backgroundColor: accent.withOpacity(0.9),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                    },
                  ),
                ]),

              ]),
            ),
          ),
        ],
      ),
    );
  }

  void _showResetDialog(BuildContext context, Color accent) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0A1228),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('مسح بيانات التعلم؟',
          style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.w700)),
        content: const Text('لن يمكن استعادتها. سيبدأ الـ Agent من الصفر.',
          style: TextStyle(fontFamily: 'Tajawal', color: Colors.white54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('إلغاء', style: TextStyle(color: accent, fontFamily: 'Tajawal')),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<AppState>().clearMessages();
            },
            child: const Text('مسح', style: TextStyle(color: _red, fontFamily: 'Tajawal')),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════
// HELPER WIDGETS
// ════════════════════════════════════════════════

class _SectionHeader extends StatelessWidget {
  final String title;
  final Color accent;
  const _SectionHeader({required this.title, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(width: 3, height: 16,
            decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.w800,
            color: Colors.white, fontFamily: 'Tajawal',
          )),
        ],
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(children: children),
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider();
  @override
  Widget build(BuildContext context) =>
    const Divider(height: 1, thickness: 1, indent: 16, endIndent: 16,
      color: Color(0x10FFFFFF));
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color accent;
  final Widget trailing;
  const _SettingsTile({required this.icon, required this.title,
    required this.accent, required this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Icon(icon, color: accent, size: 19),
          const SizedBox(width: 12),
          Text(title, style: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.w600,
            color: Colors.white, fontFamily: 'Tajawal',
          )),
          const Spacer(),
          trailing,
        ],
      ),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool value;
  final Color accent;
  final Function(bool) onChanged;
  const _SwitchTile({required this.icon, required this.title,
    required this.subtitle, required this.value,
    required this.accent, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: value ? accent : Colors.white30, size: 19),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w600,
                  color: Colors.white, fontFamily: 'Tajawal',
                )),
                Text(subtitle, style: const TextStyle(
                  fontSize: 11, color: Colors.white38, fontFamily: 'Tajawal',
                )),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: (v) { onChanged(v); HapticFeedback.selectionClick(); },
            activeColor: accent,
            activeTrackColor: accent.withOpacity(0.3),
            inactiveThumbColor: Colors.white30,
            inactiveTrackColor: Colors.white12,
          ),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.title,
    required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        child: Row(
          children: [
            Icon(icon, color: color, size: 19),
            const SizedBox(width: 12),
            Text(title, style: TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600,
              color: color, fontFamily: 'Tajawal',
            )),
            const Spacer(),
            Icon(Icons.arrow_back_ios_rounded, size: 13, color: color.withOpacity(0.5)),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final String label, value;
  final Color accent;
  const _InfoTile({required this.label, required this.value, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Text(label, style: const TextStyle(
            fontSize: 13, color: Colors.white54, fontFamily: 'Tajawal')),
          const Spacer(),
          Text(value, style: TextStyle(
            fontSize: 12, color: accent.withOpacity(0.8),
            fontFamily: 'monospace', fontWeight: FontWeight.w600,
          )),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════
// LoRA Training Card — Phase 8
// ══════════════════════════════════════════════════
class _LoraTrainingCard extends StatefulWidget {
  final Color accent;
  const _LoraTrainingCard({required this.accent});
  @override
  State<_LoraTrainingCard> createState() => _LoraTrainingCardState();
}

class _LoraTrainingCardState extends State<_LoraTrainingCard> {
  static const _ggreen  = Color(0xFF00FF9D);
  static const _rred    = Color(0xFFFF3860);
  static const _ccyan   = Color(0xFF00C8FF);

  @override
  void initState() {
    super.initState();
    LoraService.instance.startPolling();
    LoraService.instance.addListener(_onStatus);
  }

  @override
  void dispose() {
    LoraService.instance.removeListener(_onStatus);
    super.dispose();
  }

  void _onStatus() { if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) {
    final st     = LoraService.instance.status;
    final accent = widget.accent;

    final stateColor = switch (st.state) {
      LoraState.done        => _ggreen,
      LoraState.error       => _rred,
      LoraState.unavailable => const Color(0xFFFF6B35),
      _                     => _ccyan,
    };

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.12)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Header
        Row(children: [
          const Text('🧬', style: TextStyle(fontSize: 22)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('LoRA Fine-tuning',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800,
                color: Colors.white, fontFamily: 'Tajawal')),
            Text('يدرّب Gemma على أسلوبك الشخصي',
              style: TextStyle(fontSize: 12, color: Colors.grey[500], fontFamily: 'Tajawal')),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: stateColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: stateColor.withOpacity(0.3)),
            ),
            child: Text(st.stateLabel,
              style: TextStyle(fontSize: 11, color: stateColor,
                fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
          ),
        ]),

        // Progress
        if (st.isActive || st.state == LoraState.done) ...[
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: st.progress / 100.0,
              backgroundColor: accent.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation(
                st.state == LoraState.done ? _ggreen : accent),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 6),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(st.message, style: TextStyle(fontSize: 12,
              color: Colors.grey[500], fontFamily: 'Tajawal')),
            Text('${st.progress}%', style: TextStyle(fontSize: 12,
              fontWeight: FontWeight.w700, color: accent, fontFamily: 'monospace')),
          ]),
        ],

        // Stats when done
        if (st.state == LoraState.done && st.samples > 0) ...[
          const SizedBox(height: 10),
          Row(children: [
            _chip('${st.samples}', 'sample', accent),
            const SizedBox(width: 8),
            _chip(st.updatedAt, 'آخر تدريب', accent),
          ]),
        ],

        // Error
        if (st.state == LoraState.error) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _rred.withOpacity(0.07),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _rred.withOpacity(0.2)),
            ),
            child: Text(st.error.isNotEmpty ? st.error : 'خطأ غير معروف',
              style: const TextStyle(fontSize: 11, color: _rred, fontFamily: 'Tajawal')),
          ),
        ],

        // Idle hint
        if (st.state == LoraState.idle || st.state == LoraState.unavailable) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: accent.withOpacity(0.1)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الخطوات:', style: TextStyle(fontSize: 12,
                fontWeight: FontWeight.w700, color: accent, fontFamily: 'Tajawal')),
              const SizedBox(height: 4),
              const Text(
                '① تصدير محادثاتك من SQLite\n'
                '② تدريب Gemma على الـ PC (GPU)\n'
                '③ نقل الموديل للفون عبر ADB',
                style: TextStyle(fontSize: 12, height: 1.7,
                  color: Colors.white60, fontFamily: 'Tajawal')),
            ]),
          ),
        ],

        const SizedBox(height: 14),

        // Buttons
        Row(children: [
          if (st.isActive) ...[
            Expanded(child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(width: 14, height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2, color: accent)),
                const SizedBox(width: 8),
                Text('جاري...', style: TextStyle(fontSize: 13,
                  color: accent, fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
              ]),
            )),
          ] else if (st.state == LoraState.done) ...[
            Expanded(child: _Btn(label: '🔄 تدريب جديد',  color: accent,  onTap: _reset)),
          ] else ...[
            Expanded(child: _Btn(label: '📤 تصدير',     color: accent,  onTap: _export)),
            const SizedBox(width: 8),
            Expanded(child: _Btn(label: '🚀 تدريب',     color: _ggreen, onTap: _train)),
          ],
        ]),
      ]),
    );
  }

  Widget _chip(String v, String label, Color accent) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: accent.withOpacity(0.08),
      borderRadius: BorderRadius.circular(8)),
    child: Text('$v  $label', style: TextStyle(fontSize: 11,
      color: accent, fontFamily: 'Tajawal')),
  );

  Future<void> _export() async {
    final ok = await LoraService.instance.exportData();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(ok ? '📤 جاري التصدير...' : '❌ فشل — server شغّال؟',
        style: const TextStyle(fontFamily: 'Tajawal')),
      backgroundColor: ok ? _ggreen : _rred,
    ));
  }

  Future<void> _train() async {
    final ok = await LoraService.instance.startTraining();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(ok ? '🚀 بدأ التدريب...' : '❌ صدّر البيانات الأول',
        style: const TextStyle(fontFamily: 'Tajawal')),
      backgroundColor: ok ? _ggreen : _rred,
    ));
  }

  Future<void> _reset() async => LoraService.instance.reset();
}

class _Btn extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _Btn({required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Text(label, textAlign: TextAlign.center,
        style: TextStyle(fontSize: 12, color: color,
          fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
    ),
  );
}

// ══════════════════════════════════════════════════
// Offline & Sync Card — Phase 11
// ══════════════════════════════════════════════════
class _OfflineSyncCard extends StatefulWidget {
  final Color accent;
  const _OfflineSyncCard({required this.accent});
  @override
  State<_OfflineSyncCard> createState() => _OfflineSyncCardState();
}

class _OfflineSyncCardState extends State<_OfflineSyncCard> {
  @override
  void initState() {
    super.initState();
    OfflineService.instance.addListener(_onUpdate);
    OfflineService.instance.refresh();
  }

  @override
  void dispose() {
    OfflineService.instance.removeListener(_onUpdate);
    super.dispose();
  }

  void _onUpdate() { if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) {
    final svc    = OfflineService.instance;
    final status = svc.status;
    final accent = widget.accent;

    final statusColor = status.online
        ? (status.pendingCount > 0 ? const Color(0xFFFF9800) : const Color(0xFF00FF9D))
        : const Color(0xFFEF5350);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.12)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Status row ──
        Row(children: [
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: statusColor,
              boxShadow: [BoxShadow(color: statusColor.withOpacity(0.4),
                blurRadius: 4)],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            status.statusLabel,
            style: TextStyle(fontSize: 13, color: statusColor,
              fontWeight: FontWeight.w700, fontFamily: 'Tajawal'),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () => svc.refresh(),
            child: Icon(Icons.refresh_rounded, size: 16,
              color: accent.withOpacity(0.6)),
          ),
        ]),

        const SizedBox(height: 12),

        // ── Queue stats ──
        Row(children: [
          _StatChip('⏳ ${status.queueStats.pending}',  'pending',  Colors.orange),
          const SizedBox(width: 8),
          _StatChip('🔄 ${status.queueStats.retrying}', 'retrying', Colors.blue),
          const SizedBox(width: 8),
          _StatChip('✅ ${status.queueStats.done}',     'done',     Colors.green),
          const SizedBox(width: 8),
          _StatChip('❌ ${status.queueStats.failed}',   'failed',   Colors.red),
        ]),

        if (status.lastSync.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('آخر sync: ${status.lastSync}',
            style: const TextStyle(fontSize: 10, color: Colors.white38,
              fontFamily: 'Tajawal')),
        ],

        const SizedBox(height: 14),

        // ── Action buttons ──
        Row(children: [
          _ActionBtn(
            label: '🔁 Retry Failed',
            accent: accent,
            onTap: () => svc.retryFailed(),
          ),
          const SizedBox(width: 8),
          _ActionBtn(
            label: '📡 Ping Test',
            accent: accent,
            onTap: () async {
              final ok = await svc.pingTest();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(ok ? '✅ الإنترنت شغّال' : '❌ لا يوجد اتصال',
                    style: const TextStyle(fontFamily: 'Tajawal')),
                  duration: const Duration(seconds: 2),
                  backgroundColor: ok ? Colors.green : Colors.red,
                ));
              }
            },
          ),
        ]),
      ]),
    );
  }
}

Widget _StatChip(String label, String sub, Color color) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
  decoration: BoxDecoration(
    color: color.withOpacity(0.08),
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: color.withOpacity(0.2)),
  ),
  child: Text(label, style: TextStyle(fontSize: 10, color: color,
    fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
);

class _ActionBtn extends StatelessWidget {
  final String label;
  final Color  accent;
  final VoidCallback onTap;
  const _ActionBtn({required this.label, required this.accent, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: accent.withOpacity(0.3)),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: accent,
        fontWeight: FontWeight.w700, fontFamily: 'Tajawal')),
    ),
  );
}
