// lib/screens/reminders_screen.dart — Phase 16
// ══════════════════════════════════════════════════
// شاشة إدارة التذكيرات — CRUD كامل
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/notification_service.dart';
import '../services/theme_service.dart';
import '../theme/app_theme.dart';

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});
  @override State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  String _filter   = 'pending';  // pending | all | urgent
  bool   _creating = false;

  @override
  void initState() {
    super.initState();
    NotificationService.instance.loadReminders(includeDone: true);
  }

  @override
  Widget build(BuildContext context) {
    final svc    = context.watch<NotificationService>();
    final accent = context.watch<ThemeService>().themeData.accent;

    List<Reminder> items;
    switch (_filter) {
      case 'urgent': items = svc.urgent;  break;
      case 'all':    items = svc.reminders; break;
      default:       items = svc.pending;
    }

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(children: [

          // ── Header ──────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              Icon(Icons.notifications_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text('التذكيرات', style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w800,
                color: AppColors.text, fontFamily: 'Tajawal')),
              const Spacer(),
              _StatChip(svc.stats.pending.toString(), 'معلّق', accent),
              const SizedBox(width: 6),
              if (svc.stats.urgent > 0)
                _StatChip(svc.stats.urgent.toString(), 'عاجل',
                  const Color(0xFFEF4444)),
            ]),
          ),
          const SizedBox(height: 12),

          // ── Filter row ──────────────────────────
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              _FilterBtn('معلّق',  'pending', _filter, accent,
                () => setState(() => _filter = 'pending')),
              const SizedBox(width: 8),
              _FilterBtn('عاجل',   'urgent',  _filter,
                const Color(0xFFEF4444),
                () => setState(() => _filter = 'urgent')),
              const SizedBox(width: 8),
              _FilterBtn('الكل',   'all',     _filter, accent,
                () => setState(() => _filter = 'all')),
            ]),
          ),
          const SizedBox(height: 10),

          // ── List ────────────────────────────────
          Expanded(
            child: svc.loading
              ? Center(child: CircularProgressIndicator(color: accent))
              : items.isEmpty
                ? _EmptyState(accent: accent, onAdd: () => _showAddSheet(context))
                : RefreshIndicator(
                    color: accent,
                    onRefresh: () => svc.loadReminders(includeDone: true),
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      itemCount: items.length,
                      itemBuilder: (ctx, i) => _ReminderCard(
                        reminder: items[i],
                        accent:   accent,
                        onDone:   () => svc.markDone(items[i].id),
                        onDelete: () => svc.delete(items[i].id),
                        onSnooze: (m) => svc.snooze(items[i].id, minutes: m),
                      ),
                    ),
                  ),
          ),
        ]),
      ),

      // ── FAB ─────────────────────────────────────
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddSheet(context),
        backgroundColor: accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة تذكير',
          style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
      ),
    );
  }

  void _showAddSheet(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => _AddReminderSheet(
        accent: context.read<ThemeService>().themeData.accent,
      ),
    );
  }
}


// ── Reminder Card ─────────────────────────────────
class _ReminderCard extends StatelessWidget {
  final Reminder   reminder;
  final Color      accent;
  final VoidCallback         onDone, onDelete;
  final Function(int)        onSnooze;
  const _ReminderCard({required this.reminder, required this.accent,
    required this.onDone, required this.onDelete, required this.onSnooze});

  @override
  Widget build(BuildContext context) {
    final priorityColor = switch (reminder.priority) {
      'urgent' => const Color(0xFFEF4444),
      'high'   => const Color(0xFFF59E0B),
      'low'    => Colors.white38,
      _        => accent,
    };

    return Dismissible(
      key: ValueKey(reminder.id),
      background: _SwipeBackground(
        color: AppColors.success, icon: Icons.check_rounded, align: Alignment.centerLeft),
      secondaryBackground: _SwipeBackground(
        color: AppColors.error, icon: Icons.delete_rounded, align: Alignment.centerRight),
      onDismissed: (dir) {
        if (dir == DismissDirection.startToEnd) onDone();
        else onDelete();
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: reminder.done
                ? Colors.white.withOpacity(0.04)
                : priorityColor.withOpacity(0.2)),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),

          // Left: priority indicator
          leading: Container(
            width: 4, height: 40,
            decoration: BoxDecoration(
              color: reminder.done ? Colors.white12 : priorityColor,
              borderRadius: BorderRadius.circular(2)),
          ),

          // Title + time
          title: Text(
            '${reminder.emoji} ${reminder.label}',
            style: TextStyle(
              color: reminder.done ? AppColors.textFaint : AppColors.text,
              fontFamily: 'Tajawal', fontWeight: FontWeight.w700,
              fontSize: 14,
              decoration: reminder.done ? TextDecoration.lineThrough : null),
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(children: [
              Icon(Icons.access_time_rounded,
                size: 12, color: AppColors.textMuted),
              const SizedBox(width: 4),
              Text(reminder.time, style: TextStyle(
                fontSize: 11, color: AppColors.textMuted, fontFamily: 'Tajawal')),
              if (reminder.repeatLabel.isNotEmpty) ...[
                const SizedBox(width: 8),
                Text('🔁 ${reminder.repeatLabel}', style: TextStyle(
                  fontSize: 10, color: AppColors.textFaint, fontFamily: 'Tajawal')),
              ],
              if (reminder.tags.isNotEmpty) ...[
                const SizedBox(width: 8),
                Text(reminder.tags.map((t) => '#$t').join(' '),
                  style: TextStyle(fontSize: 10, color: accent.withOpacity(0.6),
                    fontFamily: 'Tajawal')),
              ],
            ]),
          ),

          // Actions
          trailing: !reminder.done ? PopupMenuButton<String>(
            icon: Icon(Icons.more_vert_rounded,
              color: AppColors.iconMuted, size: 18),
            color: AppColors.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
            onSelected: (v) {
              switch (v) {
                case 'done':    onDone(); break;
                case 'snooze5': onSnooze(5); break;
                case 'snooze10':onSnooze(10); break;
                case 'snooze30':onSnooze(30); break;
                case 'delete':  onDelete(); break;
              }
            },
            itemBuilder: (_) => [
              _menuItem('done',     '✅ تم', Colors.green),
              _menuItem('snooze5',  '💤 5 دقائق', Colors.orange),
              _menuItem('snooze10', '💤 10 دقائق', Colors.orange),
              _menuItem('snooze30', '💤 30 دقيقة', Colors.orange),
              _menuItem('delete',   '🗑️ حذف', Colors.red),
            ],
          ) : null,
        ),
      ),
    );
  }

  PopupMenuItem<String> _menuItem(String v, String text, Color color) =>
    PopupMenuItem(value: v, child: Text(text,
      style: TextStyle(color: color, fontFamily: 'Tajawal', fontSize: 13)));
}

class _SwipeBackground extends StatelessWidget {
  final Color     color;
  final IconData  icon;
  final Alignment align;
  const _SwipeBackground({required this.color, required this.icon,
    required this.align});
  @override
  Widget build(BuildContext context) => Container(
    color: color.withOpacity(0.15),
    alignment: align,
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Icon(icon, color: color, size: 24),
  );
}


// ── Add Reminder Sheet ────────────────────────────
class _AddReminderSheet extends StatefulWidget {
  final Color accent;
  const _AddReminderSheet({required this.accent});
  @override State<_AddReminderSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<_AddReminderSheet> {
  final _labelCtrl = TextEditingController();
  final _noteCtrl  = TextEditingController();
  TimeOfDay _time     = TimeOfDay.now();
  String    _repeat   = 'none';
  String    _priority = 'normal';
  bool      _saving   = false;

  @override
  void dispose() {
    _labelCtrl.dispose(); _noteCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.accent;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20,
        MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Handle
        Center(child: Container(width: 40, height: 4,
          decoration: BoxDecoration(color: Colors.white12,
            borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 16),

        Text('تذكير جديد', style: TextStyle(
          fontSize: 16, fontWeight: FontWeight.w800,
          color: AppColors.text, fontFamily: 'Tajawal')),
        const SizedBox(height: 14),

        // Label
        TextField(
          controller: _labelCtrl,
          textDirection: TextDirection.rtl,
          style: TextStyle(color: AppColors.text, fontFamily: 'Tajawal'),
          decoration: InputDecoration(
            hintText: 'وصف التذكير...',
            hintStyle: TextStyle(color: AppColors.textFaint, fontFamily: 'Tajawal'),
            filled: true, fillColor: AppColors.surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
        const SizedBox(height: 10),

        // Time picker
        GestureDetector(
          onTap: () async {
            final t = await showTimePicker(context: context, initialTime: _time);
            if (t != null) setState(() => _time = t);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Icon(Icons.access_time_rounded, color: accent, size: 18),
              const SizedBox(width: 8),
              Text('${_time.hour.toString().padLeft(2,'0')}:${_time.minute.toString().padLeft(2,'0')}',
                style: TextStyle(color: AppColors.text,
                  fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
        const SizedBox(height: 10),

        // Repeat
        DropdownButtonFormField<String>(
          value: _repeat,
          dropdownColor: AppColors.surface,
          style: TextStyle(color: AppColors.text, fontFamily: 'Tajawal', fontSize: 13),
          decoration: InputDecoration(
            filled: true, fillColor: AppColors.surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
          items: const [
            DropdownMenuItem(value: 'none',     child: Text('مرة واحدة')),
            DropdownMenuItem(value: 'daily',    child: Text('يومياً')),
            DropdownMenuItem(value: 'weekdays', child: Text('أيام العمل')),
            DropdownMenuItem(value: 'weekend',  child: Text('نهاية الأسبوع')),
            DropdownMenuItem(value: 'weekly',   child: Text('أسبوعياً')),
          ],
          onChanged: (v) => setState(() => _repeat = v ?? 'none'),
        ),
        const SizedBox(height: 10),

        // Priority
        Row(children: ['normal','high','urgent'].map((p) {
          final colors = {'normal': accent, 'high': const Color(0xFFF59E0B),
                          'urgent': const Color(0xFFEF4444)};
          final labels = {'normal':'عادي','high':'عالٍ','urgent':'عاجل'};
          final selected = _priority == p;
          final c = colors[p]!;
          return Expanded(child: GestureDetector(
            onTap: () => setState(() => _priority = p),
            child: Container(
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: selected ? c.withOpacity(0.15) : AppColors.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: selected ? c.withOpacity(0.4) : Colors.transparent)),
              child: Text(labels[p]!, textAlign: TextAlign.center,
                style: TextStyle(color: selected ? c : AppColors.textMuted,
                  fontFamily: 'Tajawal', fontSize: 12,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w400)),
            ),
          ));
        }).toList()),
        const SizedBox(height: 16),

        // Save
        SizedBox(width: double.infinity,
          child: ElevatedButton(
            onPressed: _saving ? null : _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: accent, foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            child: _saving
              ? const SizedBox(width:18,height:18,
                  child: CircularProgressIndicator(strokeWidth:2,color:Colors.black))
              : const Text('حفظ التذكير',
                  style: TextStyle(fontFamily:'Tajawal',
                    fontWeight:FontWeight.w800, fontSize:14)),
          ),
        ),
      ]),
    );
  }

  Future<void> _save() async {
    final label = _labelCtrl.text.trim();
    if (label.isEmpty) return;
    setState(() => _saving = true);
    final time = '${_time.hour.toString().padLeft(2,'0')}:${_time.minute.toString().padLeft(2,'0')}';
    await NotificationService.instance.createReminder(
      label: label, time: time,
      repeat: _repeat, priority: _priority,
    );
    setState(() => _saving = false);
    if (mounted) Navigator.pop(context);
  }
}


// ── Sub-widgets ───────────────────────────────────
class _StatChip extends StatelessWidget {
  final String label, sub;
  final Color  color;
  const _StatChip(this.label, this.sub, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Text('$label $sub', style: TextStyle(
      fontSize: 11, color: color, fontFamily: 'Tajawal',
      fontWeight: FontWeight.w700)),
  );
}

class _FilterBtn extends StatelessWidget {
  final String label, value, current;
  final Color  accent;
  final VoidCallback onTap;
  const _FilterBtn(this.label, this.value, this.current, this.accent, this.onTap);
  @override
  Widget build(BuildContext context) {
    final selected = current == value;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? accent.withOpacity(0.15) : AppColors.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? accent.withOpacity(0.4) : Colors.white.withOpacity(0.07))),
        child: Text(label, style: TextStyle(
          fontSize: 12, color: selected ? accent : AppColors.textMuted,
          fontFamily: 'Tajawal',
          fontWeight: selected ? FontWeight.w700 : FontWeight.w400)),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final Color accent;
  final VoidCallback onAdd;
  const _EmptyState({required this.accent, required this.onAdd});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.notifications_off_rounded, size: 56, color: Colors.white12),
      const SizedBox(height: 12),
      Text('لا توجد تذكيرات معلّقة', style: TextStyle(
        color: AppColors.textMuted, fontFamily: 'Tajawal', fontSize: 14)),
      const SizedBox(height: 16),
      ElevatedButton.icon(
        onPressed: onAdd,
        icon: const Icon(Icons.add_rounded, size: 18),
        label: const Text('إضافة تذكير أول',
          style: TextStyle(fontFamily: 'Tajawal')),
        style: ElevatedButton.styleFrom(
          backgroundColor: accent, foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
      ),
    ]),
  );
}
