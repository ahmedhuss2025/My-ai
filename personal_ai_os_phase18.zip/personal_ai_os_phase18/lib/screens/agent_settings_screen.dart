// lib/screens/agent_settings_screen.dart — Phase 18
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import '../services/theme_service.dart';
import '../theme/app_theme.dart';

class AgentSettingsScreen extends StatefulWidget {
  const AgentSettingsScreen({super.key});
  @override State<AgentSettingsScreen> createState() => _AgentSettingsState();
}

class _AgentSettingsState extends State<AgentSettingsScreen> {
  static const _base = 'http://localhost:7070';

  Map<String, dynamic> _settings = {};
  bool _loading = true;
  bool _saving  = false;

  final _claudeKey  = TextEditingController();
  final _gptKey     = TextEditingController();
  final _mistralUrl = TextEditingController();

  @override
  void initState() { super.initState(); _load(); }

  @override
  void dispose() {
    _claudeKey.dispose(); _gptKey.dispose(); _mistralUrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await http.get(Uri.parse('$_base/agent/settings'))
          .timeout(const Duration(seconds: 6));
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        setState(() {
          _settings = j;
          _mistralUrl.text = j['mistral_url'] as String? ?? 'http://localhost:8081';
        });
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _save(String key, dynamic value) async {
    setState(() => _saving = true);
    try {
      await http.post(Uri.parse('$_base/agent/settings/update'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': key, 'value': value}))
          .timeout(const Duration(seconds: 8));
      setState(() => _settings[key] = value);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ تم حفظ الإعداد',
            style: const TextStyle(fontFamily: 'Tajawal')),
          backgroundColor: AppColors.success,
          duration: const Duration(seconds: 2)));
      }
    } catch (_) {}
    setState(() => _saving = false);
  }

  Future<void> _saveKeys() async {
    setState(() => _saving = true);
    final body = <String, dynamic>{};
    if (_claudeKey.text.isNotEmpty && _claudeKey.text != '***')
      body['claude_key'] = _claudeKey.text.trim();
    if (_gptKey.text.isNotEmpty && _gptKey.text != '***')
      body['gpt_key'] = _gptKey.text.trim();
    if (_mistralUrl.text.isNotEmpty)
      body['mistral_url'] = _mistralUrl.text.trim();
    try {
      await http.post(Uri.parse('$_base/agent/settings/bulk'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body)).timeout(const Duration(seconds: 8));
      _claudeKey.clear(); _gptKey.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تم حفظ المفاتيح',
          style: TextStyle(fontFamily: 'Tajawal'))));
    } catch (_) {}
    setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.watch<ThemeService>().themeData.accent;
    final level  = _settings['permission_level'] as int? ?? 2;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: _loading
          ? Center(child: CircularProgressIndicator(color: accent))
          : ListView(padding: const EdgeInsets.all(20), children: [

            _Header(accent: accent, saving: _saving),
            const SizedBox(height: 20),

            // ── Permission Level ─────────────────
            _SectionLabel('🔐 مستوى الصلاحيات', accent),
            const SizedBox(height: 10),
            _PermissionLevelPicker(
              current: level, accent: accent,
              onChanged: (v) => _save('permission_level', v)),
            const SizedBox(height: 24),

            // ── Backend ──────────────────────────
            _SectionLabel('🤖 الـ Backend', accent),
            const SizedBox(height: 10),
            _BackendStatusCard(settings: _settings, accent: accent),
            const SizedBox(height: 10),
            _ToggleRow('☁️ تفضيل الـ Cloud', 'prefer_cloud',
              _settings['prefer_cloud'] as bool? ?? false, accent, _save),
            const SizedBox(height: 16),

            // Mistral URL
            _ApiField('🔗 Mistral URL', _mistralUrl,
              hint: 'http://localhost:8081', accent: accent),
            const SizedBox(height: 24),

            // ── API Keys ─────────────────────────
            _SectionLabel('🔑 مفاتيح الـ API (طوارئ)', accent),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.3))),
              child: const Text(
                '⚠️ تُستخدم فقط لو Mistral فشل. تُحفظ على الجهاز فقط.',
                style: TextStyle(fontSize: 11, color: Color(0xFFF59E0B),
                  fontFamily: 'Tajawal')),
            ),
            const SizedBox(height: 10),
            _ApiField('Claude API Key', _claudeKey,
              hint: 'sk-ant-...', obscure: true, accent: accent),
            const SizedBox(height: 8),
            _ApiField('OpenAI API Key', _gptKey,
              hint: 'sk-...', obscure: true, accent: accent),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _saveKeys,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent, foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: const Text('حفظ المفاتيح',
                  style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w800)),
              )),
            const SizedBox(height: 24),

            // ── Auto-reply toggles ────────────────
            _SectionLabel('💬 الرد التلقائي', accent),
            const SizedBox(height: 10),
            _ToggleRow('📱 SMS', 'auto_reply_sms',
              _settings['auto_reply_sms'] as bool? ?? false, accent, _save),
            const SizedBox(height: 6),
            _ToggleRow('📧 إيميل', 'auto_reply_email',
              _settings['auto_reply_email'] as bool? ?? false, accent, _save),
            const SizedBox(height: 6),
            _ToggleRow('💚 WhatsApp', 'auto_reply_wa',
              _settings['auto_reply_wa'] as bool? ?? false, accent, _save),

            if ((_settings['permission_level'] as int? ?? 2) < 3)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  '⚠️ الرد التلقائي يحتاج مستوى صلاحية 3 أو أعلى',
                  style: TextStyle(fontSize: 11, color: Colors.orange.withOpacity(0.7),
                    fontFamily: 'Tajawal')),
              ),
            const SizedBox(height: 40),
          ]),
      ),
    );
  }
}


// ── Permission Level Picker ───────────────────────
class _PermissionLevelPicker extends StatelessWidget {
  final int current;
  final Color accent;
  final Function(int) onChanged;
  const _PermissionLevelPicker({required this.current,
    required this.accent, required this.onChanged});

  static const _levels = [
    (1, '👁️', 'قراءة فقط', 'يقرأ ويُعلمك بس'),
    (2, '✍️', 'مسودة + موافقة', 'يكتب المسودة وتوافق أنت'),
    (3, '🤝', 'تحكم + يسأل', 'يتصرف ويسألك على الحساسة'),
    (4, '🤖', 'مستقل كامل', 'يفعل كل شيء بدون موافقة'),
  ];

  @override
  Widget build(BuildContext context) => Column(
    children: _levels.map((l) {
      final sel = current == l.$1;
      final isRisky = l.$1 >= 3;
      return GestureDetector(
        onTap: () => onChanged(l.$1),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: sel ? accent.withOpacity(0.1) : AppColors.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: sel ? accent.withOpacity(0.5)
                : (isRisky ? Colors.orange.withOpacity(0.2) : Colors.white.withOpacity(0.07)),
              width: sel ? 1.5 : 1)),
          child: Row(children: [
            Text(l.$2, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(l.$3, style: TextStyle(
                color: sel ? accent : AppColors.text,
                fontFamily: 'Tajawal', fontWeight: FontWeight.w700, fontSize: 14)),
              Text(l.$4, style: TextStyle(
                color: AppColors.textMuted, fontFamily: 'Tajawal', fontSize: 11)),
            ])),
            if (sel) Icon(Icons.check_circle_rounded, color: accent, size: 20),
          ]),
        ),
      );
    }).toList(),
  );
}


// ── Backend Status Card ───────────────────────────
class _BackendStatusCard extends StatelessWidget {
  final Map<String, dynamic> settings;
  final Color accent;
  const _BackendStatusCard({required this.settings, required this.accent});
  @override
  Widget build(BuildContext context) {
    final preferCloud = settings['prefer_cloud'] as bool? ?? false;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.15))),
      child: Column(children: [
        _BackendRow('🤖 Mistral 7B', 'Primary (on-device)', preferCloud ? false : true, accent),
        const SizedBox(height: 6),
        _BackendRow('🧠 Claude API', 'طوارئ', settings['claude_key'] != null && settings['claude_key'] != '' && settings['claude_key'] != '***', accent),
        const SizedBox(height: 6),
        _BackendRow('💚 GPT-4o', 'طوارئ ثانية', settings['gpt_key'] != null && settings['gpt_key'] != '' && settings['gpt_key'] != '***', accent),
      ]),
    );
  }
}

class _BackendRow extends StatelessWidget {
  final String name, role;
  final bool   active;
  final Color  accent;
  const _BackendRow(this.name, this.role, this.active, this.accent);
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 8, height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: active ? AppColors.success : Colors.white24)),
    const SizedBox(width: 10),
    Text(name, style: TextStyle(
      color: AppColors.text, fontFamily: 'Tajawal', fontSize: 13)),
    const SizedBox(width: 6),
    Text(role, style: TextStyle(
      color: AppColors.textFaint, fontFamily: 'Tajawal', fontSize: 11)),
    const Spacer(),
    Text(active ? '✅ جاهز' : '⚫ غير مفعّل',
      style: TextStyle(fontSize: 11, fontFamily: 'Tajawal',
        color: active ? AppColors.success : Colors.white38)),
  ]);
}


// ── Helpers ───────────────────────────────────────
class _ApiField extends StatefulWidget {
  final String label, hint;
  final TextEditingController ctrl;
  final bool obscure;
  final Color accent;
  const _ApiField(this.label, this.ctrl,
    {required this.hint, this.obscure=false, required this.accent});
  @override State<_ApiField> createState() => _ApiFieldState();
}
class _ApiFieldState extends State<_ApiField> {
  bool _show = false;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(widget.label, style: TextStyle(
        fontSize: 11, color: AppColors.textMuted, fontFamily: 'Tajawal')),
      const SizedBox(height: 4),
      TextField(
        controller: widget.ctrl,
        obscureText: widget.obscure && !_show,
        style: TextStyle(color: AppColors.text, fontFamily: 'Tajawal', fontSize: 13),
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: TextStyle(color: AppColors.textFaint, fontFamily: 'Tajawal'),
          filled: true, fillColor: AppColors.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          suffixIcon: widget.obscure ? IconButton(
            icon: Icon(_show ? Icons.visibility_off_rounded : Icons.visibility_rounded,
              color: AppColors.iconMuted, size: 18),
            onPressed: () => setState(() => _show = !_show)) : null,
        ),
      ),
    ]);
}

class _ToggleRow extends StatelessWidget {
  final String label, key;
  final bool value;
  final Color accent;
  final Function(String, dynamic) onSave;
  const _ToggleRow(this.label, this.key, this.value, this.accent, this.onSave);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(
      color: AppColors.card, borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.white.withOpacity(0.06))),
    child: Row(children: [
      Text(label, style: TextStyle(
        color: AppColors.text, fontFamily: 'Tajawal', fontSize: 13)),
      const Spacer(),
      Switch(value: value, onChanged: (v) => onSave(key, v),
        activeColor: accent,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap),
    ]),
  );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  final Color  accent;
  const _SectionLabel(this.text, this.accent);
  @override
  Widget build(BuildContext context) => Text(text,
    style: TextStyle(color: accent, fontSize: 12,
      fontWeight: FontWeight.w800, fontFamily: 'Tajawal'));
}

class _Header extends StatelessWidget {
  final Color accent;
  final bool  saving;
  const _Header({required this.accent, required this.saving});
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(Icons.tune_rounded, color: accent, size: 22),
    const SizedBox(width: 10),
    Text('إعدادات الوكيل', style: TextStyle(
      fontSize: 18, fontWeight: FontWeight.w800,
      color: AppColors.text, fontFamily: 'Tajawal')),
    const Spacer(),
    if (saving) SizedBox(width: 16, height: 16,
      child: CircularProgressIndicator(strokeWidth: 2, color: accent)),
  ]);
}
