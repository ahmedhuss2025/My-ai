// lib/screens/meeting_screen.dart — Phase 12
// ══════════════════════════════════════════════════
// شاشة الاجتماعات — تسجيل + عرض + تلخيص
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/meeting_service.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';

class MeetingScreen extends StatefulWidget {
  const MeetingScreen({super.key});
  @override
  State<MeetingScreen> createState() => _MeetingScreenState();
}

class _MeetingScreenState extends State<MeetingScreen> {
  final _titleCtrl     = TextEditingController();
  final _attendeeCtrl  = TextEditingController();
  final List<String>   _attendees = [];
  bool  _showNewForm   = false;
  bool  _summarizing   = false;

  @override
  void initState() {
    super.initState();
    MeetingService.instance.loadMeetings();
    MeetingService.instance.initStt();
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _attendeeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent  = context.watch<AppState>().accentColor;
    final svc     = context.watch<MeetingService>();

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: SafeArea(
        child: Column(children: [

          // ── Header ──
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              Icon(Icons.mic_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text('الاجتماعات', style: TextStyle(fontSize: 18,
                fontWeight: FontWeight.w800, color: Colors.white,
                fontFamily: 'Tajawal')),
              const Spacer(),
              // Stats badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: accent.withOpacity(0.3)),
                ),
                child: Text(
                  '${svc.stats.total} • ${svc.stats.totalDurationMin.toStringAsFixed(0)}د',
                  style: TextStyle(fontSize: 11, color: accent,
                    fontFamily: 'Tajawal', fontWeight: FontWeight.w700),
                ),
              ),
            ]),
          ),

          const SizedBox(height: 12),

          // ── Recording bar ──
          if (svc.isRecording)
            _RecordingBar(svc: svc, accent: accent)
          else
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(children: [
                if (_showNewForm) ...[
                  _NewMeetingForm(
                    titleCtrl:    _titleCtrl,
                    attendeeCtrl: _attendeeCtrl,
                    attendees:    _attendees,
                    accent:       accent,
                    onStart:      _startRecording,
                    onCancel:     () => setState(() => _showNewForm = false),
                    onAddAttendee: _addAttendee,
                  ),
                ] else ...[
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => setState(() => _showNewForm = true),
                      icon: const Icon(Icons.fiber_manual_record_rounded,
                        color: Colors.red, size: 18),
                      label: const Text('بدء تسجيل اجتماع جديد',
                        style: TextStyle(fontFamily: 'Tajawal',
                          fontWeight: FontWeight.w800, fontSize: 14)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1A0A0A),
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.red, width: 1.5),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ),
                ],
              ]),
            ),

          const SizedBox(height: 12),

          // ── Meetings list ──
          Expanded(
            child: svc.loading
                ? Center(child: CircularProgressIndicator(color: accent))
                : svc.meetings.isEmpty
                    ? _EmptyState()
                    : RefreshIndicator(
                        color: accent,
                        onRefresh: svc.loadMeetings,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: svc.meetings.length,
                          itemBuilder: (ctx, i) => _MeetingCard(
                            meeting:     svc.meetings[i],
                            accent:      accent,
                            summarizing: _summarizing,
                            onSummarize: () => _summarize(svc.meetings[i].id),
                            onDelete:    () => _deleteMeeting(svc.meetings[i].id),
                          ),
                        ),
                      ),
          ),
        ]),
      ),
    );
  }

  void _addAttendee() {
    final name = _attendeeCtrl.text.trim();
    if (name.isNotEmpty) {
      setState(() {
        _attendees.add(name);
        _attendeeCtrl.clear();
      });
    }
  }

  Future<void> _startRecording() async {
    final title = _titleCtrl.text.trim();
    if (title.isEmpty) return;
    setState(() => _showNewForm = false);
    await MeetingService.instance.startRecording(
      title: title, attendees: List.from(_attendees));
    _titleCtrl.clear();
    _attendees.clear();
  }

  Future<void> _summarize(String meetingId) async {
    setState(() => _summarizing = true);
    await MeetingService.instance.summarize(meetingId);
    await MeetingService.instance.loadMeetings();
    setState(() => _summarizing = false);
  }

  Future<void> _deleteMeeting(String id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0D1520),
        title: const Text('حذف الاجتماع',
          style: TextStyle(color: Colors.white, fontFamily: 'Tajawal')),
        content: const Text('هتحذف الاجتماع ده نهائياً؟',
          style: TextStyle(color: Colors.white70, fontFamily: 'Tajawal')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('لا', style: TextStyle(fontFamily: 'Tajawal'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف', style: TextStyle(color: Colors.red,
              fontFamily: 'Tajawal'))),
        ],
      ),
    );
    if (confirm == true) await MeetingService.instance.deleteMeeting(id);
  }
}


// ── _RecordingBar ─────────────────────────────────
class _RecordingBar extends StatefulWidget {
  final MeetingService svc;
  final Color accent;
  const _RecordingBar({required this.svc, required this.accent});
  @override State<_RecordingBar> createState() => _RecordingBarState();
}

class _RecordingBarState extends State<_RecordingBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;
  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this,
      duration: const Duration(milliseconds: 800))..repeat(reverse: true);
  }
  @override void dispose() { _pulse.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final svc = widget.svc;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1A0808),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withOpacity(0.4)),
      ),
      child: Column(children: [
        Row(children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red.withOpacity(0.5 + 0.5 * _pulse.value),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text('جاري التسجيل... ${svc.elapsedSeconds}ث',
            style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700,
              fontFamily: 'Tajawal', fontSize: 13)),
          const Spacer(),
          GestureDetector(
            onTap: () => svc.stopRecording(),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text('إيقاف وتلخيص',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700,
                  fontFamily: 'Tajawal', fontSize: 12)),
            ),
          ),
        ]),
        if (svc.liveTranscript.isNotEmpty) ...[
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              svc.liveTranscript.length > 150
                  ? '...${svc.liveTranscript.substring(svc.liveTranscript.length - 150)}'
                  : svc.liveTranscript,
              textDirection: TextDirection.rtl,
              style: const TextStyle(color: Colors.white60, fontSize: 11,
                fontFamily: 'Tajawal'),
            ),
          ),
        ],
      ]),
    );
  }
}


// ── _NewMeetingForm ───────────────────────────────
class _NewMeetingForm extends StatelessWidget {
  final TextEditingController titleCtrl;
  final TextEditingController attendeeCtrl;
  final List<String>          attendees;
  final Color                 accent;
  final VoidCallback          onStart;
  final VoidCallback          onCancel;
  final VoidCallback          onAddAttendee;
  const _NewMeetingForm({
    required this.titleCtrl, required this.attendeeCtrl,
    required this.attendees, required this.accent,
    required this.onStart,   required this.onCancel,
    required this.onAddAttendee,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1520),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(
          controller: titleCtrl,
          textDirection: TextDirection.rtl,
          style: const TextStyle(color: Colors.white, fontFamily: 'Tajawal'),
          decoration: InputDecoration(
            hintText: 'عنوان الاجتماع',
            hintStyle: const TextStyle(color: Colors.white30, fontFamily: 'Tajawal'),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: accent.withOpacity(0.3)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: accent),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.white12),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          ),
        ),
        const SizedBox(height: 10),
        // Attendees
        Row(children: [
          Expanded(
            child: TextField(
              controller: attendeeCtrl,
              textDirection: TextDirection.rtl,
              style: const TextStyle(color: Colors.white, fontFamily: 'Tajawal', fontSize: 13),
              decoration: InputDecoration(
                hintText: 'أضف حاضر...',
                hintStyle: const TextStyle(color: Colors.white30, fontFamily: 'Tajawal', fontSize: 12),
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.white12),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.white12),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: onAddAttendee,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.add, color: accent, size: 18),
            ),
          ),
        ]),
        if (attendees.isNotEmpty) ...[
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            children: attendees.map((a) => Chip(
              label: Text(a, style: const TextStyle(fontSize: 11, fontFamily: 'Tajawal')),
              backgroundColor: accent.withOpacity(0.1),
              side: BorderSide(color: accent.withOpacity(0.3)),
              labelStyle: TextStyle(color: accent),
              deleteIconColor: accent.withOpacity(0.6),
              onDeleted: () {},
            )).toList(),
          ),
        ],
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: onStart,
              icon: const Icon(Icons.fiber_manual_record_rounded,
                color: Colors.red, size: 14),
              label: const Text('ابدأ التسجيل',
                style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
              style: ElevatedButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
          const SizedBox(width: 8),
          TextButton(
            onPressed: onCancel,
            child: const Text('إلغاء',
              style: TextStyle(color: Colors.white38, fontFamily: 'Tajawal')),
          ),
        ]),
      ]),
    );
  }
}


// ── _MeetingCard ──────────────────────────────────
class _MeetingCard extends StatefulWidget {
  final Meeting  meeting;
  final Color    accent;
  final bool     summarizing;
  final VoidCallback onSummarize;
  final VoidCallback onDelete;
  const _MeetingCard({required this.meeting, required this.accent,
    required this.summarizing, required this.onSummarize, required this.onDelete});
  @override State<_MeetingCard> createState() => _MeetingCardState();
}

class _MeetingCardState extends State<_MeetingCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final m = widget.meeting;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1228),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: m.hasSummary
              ? widget.accent.withOpacity(0.2)
              : Colors.white.withOpacity(0.07)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Top row ──
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          title: Text(m.title, style: const TextStyle(color: Colors.white,
            fontWeight: FontWeight.w700, fontFamily: 'Tajawal', fontSize: 14)),
          subtitle: Row(children: [
            Text(m.durationLabel, style: const TextStyle(
              color: Colors.white38, fontSize: 11, fontFamily: 'Tajawal')),
            const SizedBox(width: 8),
            Text(m.createdAt.substring(0, 10),
              style: const TextStyle(color: Colors.white24, fontSize: 10,
                fontFamily: 'Tajawal')),
          ]),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            // Summary badge
            if (m.hasSummary)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text('✅ ملخّص', style: TextStyle(
                  fontSize: 9, color: Colors.green, fontFamily: 'Tajawal')),
              ),
            const SizedBox(width: 4),
            IconButton(
              icon: Icon(_expanded ? Icons.expand_less : Icons.expand_more,
                color: Colors.white38, size: 20),
              onPressed: () => setState(() => _expanded = !_expanded),
            ),
          ]),
        ),

        // ── Expanded content ──
        if (_expanded) ...[
          const Divider(color: Colors.white10, height: 1),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              // Summary
              if (m.hasSummary) ...[
                _SectionLabel('📝 الملخص', widget.accent),
                const SizedBox(height: 6),
                Text(m.summary, textDirection: TextDirection.rtl,
                  style: const TextStyle(color: Colors.white70, fontSize: 13,
                    fontFamily: 'Tajawal', height: 1.5)),
                const SizedBox(height: 12),

                // Action items
                if (m.actionItems.isNotEmpty) ...[
                  _SectionLabel('✅ المهام', widget.accent),
                  const SizedBox(height: 6),
                  ...m.actionItems.map((a) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(Icons.check_circle_outline_rounded,
                        color: widget.accent, size: 14),
                      const SizedBox(width: 6),
                      Expanded(child: Text(a, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: Colors.white60, fontSize: 12,
                          fontFamily: 'Tajawal'))),
                    ]),
                  )),
                  const SizedBox(height: 10),
                ],

                // Keywords
                if (m.keywords.isNotEmpty) ...[
                  _SectionLabel('🏷️ الكلمات المفتاحية', widget.accent),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6, runSpacing: 4,
                    children: m.keywords.map((k) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: widget.accent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: widget.accent.withOpacity(0.2)),
                      ),
                      child: Text(k, style: TextStyle(fontSize: 10, color: widget.accent,
                        fontFamily: 'Tajawal')),
                    )).toList(),
                  ),
                  const SizedBox(height: 12),
                ],
              ],

              // Transcript preview
              if (m.hasTranscript) ...[
                _SectionLabel('🎙️ النص المسجّل', widget.accent),
                const SizedBox(height: 6),
                Text(
                  m.transcript.length > 200
                      ? '${m.transcript.substring(0, 200)}...'
                      : m.transcript,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(color: Colors.white38, fontSize: 11,
                    fontFamily: 'Tajawal', height: 1.5),
                ),
                const SizedBox(height: 12),
              ],

              // Action buttons
              Row(children: [
                if (!m.hasSummary && m.hasTranscript)
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: widget.summarizing ? null : widget.onSummarize,
                      icon: widget.summarizing
                          ? const SizedBox(width: 14, height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                          : const Icon(Icons.auto_awesome, size: 14),
                      label: const Text('لخّص الاجتماع',
                        style: TextStyle(fontFamily: 'Tajawal', fontSize: 12,
                          fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: widget.accent,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 9),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: widget.onDelete,
                  icon: const Icon(Icons.delete_outline_rounded,
                    color: Colors.red, size: 18),
                  tooltip: 'حذف',
                ),
              ]),
            ]),
          ),
        ],
      ]),
    );
  }
}

Widget _SectionLabel(String text, Color accent) => Text(text,
  style: TextStyle(fontSize: 11, color: accent, fontWeight: FontWeight.w700,
    fontFamily: 'Tajawal'));

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.mic_none_rounded, size: 52, color: Colors.white12),
      const SizedBox(height: 14),
      const Text('لا توجد اجتماعات بعد\nاضغط "بدء تسجيل" للبدء',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white30, fontFamily: 'Tajawal',
          fontSize: 14, height: 1.6)),
    ]),
  );
}
