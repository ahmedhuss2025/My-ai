// lib/screens/main_shell.dart
// ══════════════════════════════════════════════════
// Main Shell — Bottom Navigation يجمع كل الـ screens
// Chat | Dashboard | Camera | Meetings | Settings
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';
import '../services/offline_service.dart';
import '../services/image_service.dart';
import '../services/meeting_service.dart';
import '../services/widget_service.dart';    // Phase 13
import '../services/proactive_service.dart'; // Phase 13
import '../widgets/proactive_banner.dart';   // Phase 13
import 'chat_screen.dart';
import 'dashboard_screen.dart';
import 'camera_screen.dart';
import 'meeting_screen.dart';
import 'settings_screen.dart';
import 'backup_screen.dart';
import 'theme_screen.dart';     // Phase 15
import 'reminders_screen.dart'; // Phase 16
import 'analytics_screen.dart'; // Phase 17
import 'agent_settings_screen.dart'; // Phase 18
import 'audit_screen.dart';          // Phase 18

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with TickerProviderStateMixin {
  int _tab = 0;

  // Keep screens alive when switching tabs
  late final PageController _pageCtrl = PageController(initialPage: 0);

  static const _tabs = [
    _TabItem(icon: Icons.chat_bubble_rounded,      label: 'Chat'),
    _TabItem(icon: Icons.dashboard_rounded,         label: 'لوحة'),
    _TabItem(icon: Icons.auto_awesome_rounded,      label: 'صور'),     // Phase 12
    _TabItem(icon: Icons.mic_rounded,               label: 'اجتماع'), // Phase 12
    _TabItem(icon: Icons.settings_rounded,          label: 'إعدادات'),
    _TabItem(icon: Icons.backup_rounded,            label: 'نسخة'),     // Phase 14
    _TabItem(icon: Icons.palette_rounded,           label: 'ثيم'),      // Phase 15
    _TabItem(icon: Icons.notifications_rounded,     label: 'تذكير'),   // Phase 16
    _TabItem(icon: Icons.bar_chart_rounded,          label: 'إحصاء'),   // Phase 17
    _TabItem(icon: Icons.manage_search_rounded,      label: 'سجل'),    // Phase 18
    _TabItem(icon: Icons.tune_rounded,               label: 'وكيل'),    // Phase 18
  ];

  void _onTabTap(int i) {
    if (_tab == i) return;
    setState(() => _tab = i);
    _pageCtrl.animateToPage(
      i,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOutCubic,
    );
    HapticFeedback.selectionClick();
  }

  @override
  void initState() {
    super.initState();
    // Phase 13: listen for widget deeplinks
    WidgetService.instance.addListener(_handleWidgetDeeplink);
  }

  void _handleWidgetDeeplink() {
    final screen = WidgetService.instance.consumePending();
    switch (screen) {
      case WidgetScreen.chat:    _onTabTap(0); break;
      case WidgetScreen.meeting: _onTabTap(3); break;
      case WidgetScreen.voice:
        _onTabTap(0);
        // voice is handled in chat_screen on next build
        break;
      case WidgetScreen.none: break;
    }
  }

  @override
  void dispose() {
    WidgetService.instance.removeListener(_handleWidgetDeeplink);
    _pageCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent  = context.watch<AppState>().accentColor;
    final offline = context.watch<OfflineService>();
    final mq      = MediaQuery.of(context);

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      extendBody: true,
      body: Column(
        children: [
          // Phase 13 — Proactive AI banner
          const ProactiveBanner(),
          // Phase 11 — Offline banner
          if (!offline.isOnline)
            _OfflineBanner(status: offline.status),
          Expanded(
            child: PageView(
              controller: _pageCtrl,
              physics: const NeverScrollableScrollPhysics(),
              children: const [
                ChatScreen(),
                DashboardScreen(),
                CameraScreen(),   // Phase 12 — صور
                MeetingScreen(),  // Phase 12 — اجتماعات
                SettingsScreen(),
                BackupScreen(),    // Phase 14
                const ThemeScreen(),  // Phase 15
                const RemindersScreen(),  // Phase 16
                const AnalyticsScreen(),  // Phase 17
                const AuditScreen(),          // Phase 18
                const AgentSettingsScreen(),  // Phase 18
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _BottomBar(
        tabs: _tabs,
        current: _tab,
        accent: accent,
        onTap: _onTabTap,
        bottomPad: mq.padding.bottom,
      ),
    );
  }
}

// ── Tab Item ──────────────────────────────────────
class _TabItem {
  final IconData icon;
  final String label;
  const _TabItem({required this.icon, required this.label});
}

// ── Custom Bottom Bar ─────────────────────────────
class _BottomBar extends StatelessWidget {
  final List<_TabItem> tabs;
  final int current;
  final Color accent;
  final Function(int) onTap;
  final double bottomPad;

  const _BottomBar({
    required this.tabs, required this.current,
    required this.accent, required this.onTap,
    required this.bottomPad,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60 + bottomPad,
      decoration: BoxDecoration(
        color: AppColors.darkSurface,
        border: Border(
          top: BorderSide(color: Colors.white.withOpacity(0.07), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.only(bottom: bottomPad),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(tabs.length, (i) => _TabButton(
            item: tabs[i],
            isActive: i == current,
            accent: accent,
            onTap: () => onTap(i),
          )),
        ),
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  final _TabItem item;
  final bool isActive;
  final Color accent;
  final VoidCallback onTap;

  const _TabButton({
    required this.item, required this.isActive,
    required this.accent, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 80,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: isActive ? accent.withOpacity(0.12) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                item.icon,
                color: isActive ? accent : Colors.white30,
                size: 22,
              ),
            ),
            const SizedBox(height: 2),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 250),
              style: TextStyle(
                fontFamily: 'Tajawal',
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                color: isActive ? accent : Colors.white30,
              ),
              child: Text(item.label),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════
// Offline Banner — Phase 11
// بيظهر في أعلى الشاشة لما يكون offline أو syncing
// ══════════════════════════════════════════════════
class _OfflineBanner extends StatelessWidget {
  final SyncStatus status;
  const _OfflineBanner({required this.status});

  @override
  Widget build(BuildContext context) {
    final isPending = status.pendingCount > 0;
    final color = isPending
        ? const Color(0xFFFF9800)   // orange — في queue pending
        : const Color(0xFFEF5350);  // red — offline كامل

    return Material(
      color: color,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(
            children: [
              Icon(
                isPending ? Icons.sync_rounded : Icons.wifi_off_rounded,
                size: 15,
                color: Colors.white,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  isPending
                      ? '🔄 ${status.pendingCount} طلب في الانتظار — سيُرسَل لما يرجع الإنترنت'
                      : '📴 أنت offline — بعض المزايا غير متاحة',
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.white,
                    fontFamily: 'Tajawal',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              if (isPending)
                GestureDetector(
                  onTap: () => OfflineService.instance.retryFailed(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'إعادة المحاولة',
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.white,
                        fontFamily: 'Tajawal',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
