// lib/screens/theme_screen.dart — Phase 15
// ══════════════════════════════════════════════════
// شاشة اختيار الـ Theme + اللغة + إمكانية الوصول
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/theme_service.dart';
import '../theme/app_theme.dart';
import '../l10n/app_localizations.dart';

class ThemeScreen extends StatelessWidget {
  const ThemeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ts     = context.watch<ThemeService>();
    final accent = ts.themeData.accent;
    final s      = S.of(context);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [

            // ── Header ──────────────────────────
            Row(children: [
              Icon(Icons.palette_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text(s.appearance,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                  color: AppColors.text, fontFamily: 'Tajawal')),
            ]),
            const SizedBox(height: 24),

            // ── Theme Picker ────────────────────
            _SectionLabel(s.theme, accent),
            const SizedBox(height: 12),
            _ThemePicker(current: ts.themeId, accent: accent,
              onSelect: ts.setThemeId),
            const SizedBox(height: 24),

            // ── Dark / Light ────────────────────
            _SectionLabel(s.darkMode, accent),
            const SizedBox(height: 10),
            _ModeSelector(mode: ts.themeMode, accent: accent,
              onChange: ts.setThemeMode),
            const SizedBox(height: 24),

            // ── Language ────────────────────────
            _SectionLabel(s.language, accent),
            const SizedBox(height: 10),
            _LangSelector(locale: ts.locale, accent: accent,
              onChange: ts.setLocale),
            const SizedBox(height: 24),

            // ── Font Size ───────────────────────
            _SectionLabel('${s.fontSize}: ${ts.fontScale.toStringAsFixed(1)}x',
              accent),
            const SizedBox(height: 4),
            _FontScaleSlider(value: ts.fontScale, accent: accent,
              onChange: ts.setFontScale),
            const SizedBox(height: 8),
            _FontPreview(scale: ts.fontScale, accent: accent),
            const SizedBox(height: 24),

            // ── Accessibility ───────────────────
            _SectionLabel(s.accessibility, accent),
            const SizedBox(height: 10),
            _ToggleCard(
              icon: Icons.contrast_rounded,
              label: s.highContrast,
              desc: ts.locale.languageCode == 'ar'
                  ? 'يزيد التباين لضعاف البصر'
                  : 'Increases contrast for visual accessibility',
              value: ts.highContrast,
              accent: accent,
              onToggle: ts.setHighContrast,
            ),
            const SizedBox(height: 8),
            _ToggleCard(
              icon: Icons.animation_rounded,
              label: s.reduceMotion,
              desc: ts.locale.languageCode == 'ar'
                  ? 'يوقف الأنيميشن لتسريع الأداء'
                  : 'Disables animations for better performance',
              value: ts.reduceMotion,
              accent: accent,
              onToggle: ts.setReduceMotion,
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}


// ── Theme Picker Grid ─────────────────────────────
class _ThemePicker extends StatelessWidget {
  final AppThemeId    current;
  final Color         accent;
  final Function(AppThemeId) onSelect;
  const _ThemePicker({required this.current, required this.accent,
    required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10, runSpacing: 10,
      children: kThemes.values.map((t) {
        final selected = t.id == current;
        return GestureDetector(
          onTap: () => onSelect(t.id),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: 90, height: 90,
            decoration: BoxDecoration(
              color: t.darkCard,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? t.accent : Colors.white.withOpacity(0.08),
                width: selected ? 2.5 : 1,
              ),
              boxShadow: selected ? [
                BoxShadow(color: t.accent.withOpacity(0.3),
                  blurRadius: 12, offset: const Offset(0, 4)),
              ] : [],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Color dots preview
                Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _Dot(t.accent), const SizedBox(width: 4),
                    _Dot(t.accentSecondary),
                  ]),
                const SizedBox(height: 8),
                Text(t.emoji, style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 4),
                Text(t.nameAr, style: TextStyle(
                  color: selected ? t.accent : Colors.white60,
                  fontSize: 11, fontFamily: 'Tajawal',
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                )),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;
  const _Dot(this.color);
  @override
  Widget build(BuildContext context) => Container(
    width: 14, height: 14,
    decoration: BoxDecoration(color: color, shape: BoxShape.circle),
  );
}


// ── Mode Selector ─────────────────────────────────
class _ModeSelector extends StatelessWidget {
  final ThemeMode mode;
  final Color     accent;
  final Function(ThemeMode) onChange;
  const _ModeSelector({required this.mode, required this.accent,
    required this.onChange});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final options = [
      (ThemeMode.dark,   s.darkMode,  Icons.dark_mode_rounded),
      (ThemeMode.light,  s.lightMode, Icons.light_mode_rounded),
      (ThemeMode.system, s.systemMode,Icons.brightness_auto_rounded),
    ];
    return Row(children: options.map((o) {
      final selected = mode == o.$1;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChange(o.$1),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: selected ? accent.withOpacity(0.15) : AppColors.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? accent.withOpacity(0.5) : Colors.white.withOpacity(0.07)),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(o.$3, color: selected ? accent : AppColors.iconMuted, size: 20),
              const SizedBox(height: 6),
              Text(o.$2, style: TextStyle(
                fontSize: 11, fontFamily: 'Tajawal',
                color: selected ? accent : AppColors.textMuted,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
              )),
            ]),
          ),
        ),
      );
    }).toList());
  }
}


// ── Language Selector ─────────────────────────────
class _LangSelector extends StatelessWidget {
  final Locale locale;
  final Color  accent;
  final Function(Locale) onChange;
  const _LangSelector({required this.locale, required this.accent,
    required this.onChange});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Row(children: [
      Expanded(child: _LangBtn(
        flag: '🇸🇦', label: s.arabic, code: 'ar',
        selected: locale.languageCode == 'ar', accent: accent,
        onTap: () => onChange(const Locale('ar', 'SA')),
      )),
      const SizedBox(width: 10),
      Expanded(child: _LangBtn(
        flag: '🇺🇸', label: s.english, code: 'en',
        selected: locale.languageCode == 'en', accent: accent,
        onTap: () => onChange(const Locale('en', 'US')),
      )),
    ]);
  }
}

class _LangBtn extends StatelessWidget {
  final String flag, label, code;
  final bool   selected;
  final Color  accent;
  final VoidCallback onTap;
  const _LangBtn({required this.flag, required this.label, required this.code,
    required this.selected, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: selected ? accent.withOpacity(0.15) : AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: selected ? accent.withOpacity(0.5) : Colors.white.withOpacity(0.07)),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(flag, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(
          fontSize: 13, fontFamily: 'Tajawal',
          color: selected ? accent : AppColors.textMuted,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
        )),
      ]),
    ),
  );
}


// ── Font Scale Slider ─────────────────────────────
class _FontScaleSlider extends StatelessWidget {
  final double value;
  final Color  accent;
  final Function(double) onChange;
  const _FontScaleSlider({required this.value, required this.accent,
    required this.onChange});

  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        activeTrackColor:   accent,
        thumbColor:         accent,
        inactiveTrackColor: accent.withOpacity(0.2),
        overlayColor:       accent.withOpacity(0.1),
      ),
      child: Slider(
        value: value, min: 0.8, max: 1.4, divisions: 6,
        onChanged: onChange,
      ),
    );
  }
}

class _FontPreview extends StatelessWidget {
  final double scale;
  final Color  accent;
  const _FontPreview({required this.scale, required this.accent});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withOpacity(0.06)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Text('العنوان الرئيسي', style: TextStyle(
        fontSize: 18 * scale, fontWeight: FontWeight.w800,
        color: AppColors.text, fontFamily: 'Tajawal')),
      const SizedBox(height: 4),
      Text('نص المحتوى العادي — هذا مثال على حجم النص',
        style: TextStyle(fontSize: 14 * scale, color: AppColors.textMuted,
          fontFamily: 'Tajawal')),
      const SizedBox(height: 4),
      Text('نص صغير للتفاصيل', style: TextStyle(
        fontSize: 11 * scale, color: AppColors.textFaint,
        fontFamily: 'Tajawal')),
    ]),
  );
}


// ── Toggle Card ───────────────────────────────────
class _ToggleCard extends StatelessWidget {
  final IconData icon;
  final String   label, desc;
  final bool     value;
  final Color    accent;
  final Function(bool) onToggle;
  const _ToggleCard({required this.icon, required this.label,
    required this.desc, required this.value, required this.accent,
    required this.onToggle});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => onToggle(!value),
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: value ? accent.withOpacity(0.3) : Colors.white.withOpacity(0.06)),
      ),
      child: Row(children: [
        Icon(icon, color: value ? accent : AppColors.iconMuted, size: 22),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(
              color: AppColors.text, fontFamily: 'Tajawal',
              fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 3),
            Text(desc, style: TextStyle(
              color: AppColors.textFaint, fontFamily: 'Tajawal', fontSize: 11)),
          ]),
        ),
        Switch(value: value, onChanged: onToggle,
          activeColor: accent,
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap),
      ]),
    ),
  );
}

// ── Section Label ─────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String text;
  final Color  accent;
  const _SectionLabel(this.text, this.accent);
  @override
  Widget build(BuildContext context) => Text(text,
    style: TextStyle(color: accent, fontSize: 12,
      fontWeight: FontWeight.w800, fontFamily: 'Tajawal',
      letterSpacing: 0.5));
}
