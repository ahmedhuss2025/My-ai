// lib/screens/backup_screen.dart — Phase 14
// ══════════════════════════════════════════════════
// شاشة Backup & Restore & Export
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/backup_service.dart';
import '../models/app_state.dart';
import '../theme/app_theme.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  final _passCtrl  = TextEditingController();
  bool  _showPass  = false;
  bool  _incImages = false;
  bool  _actioning = false;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    BackupService.instance.loadBackups();
  }

  @override
  void dispose() {
    _tab.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.watch<AppState>().accentColor;
    final svc    = context.watch<BackupService>();

    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: SafeArea(
        child: Column(children: [

          // ── Header ──
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              Icon(Icons.backup_rounded, color: accent, size: 22),
              const SizedBox(width: 10),
              Text('النسخ الاحتياطي',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800,
                  color: Colors.white, fontFamily: 'Tajawal')),
              const Spacer(),
              if (svc.stats.count > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withOpacity(0.3)),
                  ),
                  child: Text(
                    '${svc.stats.count} نسخة • ${svc.stats.totalSizeKb.toStringAsFixed(0)}KB',
                    style: TextStyle(fontSize: 11, color: accent, fontFamily: 'Tajawal'),
                  ),
                ),
            ]),
          ),

          const SizedBox(height: 12),

          // ── Tabs ──
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TabBar(
              controller: _tab,
              indicator: BoxDecoration(
                color: accent.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: accent.withOpacity(0.4)),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              labelColor: accent,
              unselectedLabelColor: Colors.white38,
              labelStyle: const TextStyle(fontFamily: 'Tajawal',
                fontWeight: FontWeight.w700, fontSize: 12),
              unselectedLabelStyle: const TextStyle(fontFamily: 'Tajawal', fontSize: 11),
              tabs: const [
                Tab(text: '💾 نسخة'),
                Tab(text: '🔄 استعادة'),
                Tab(text: '📤 تصدير'),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: TabBarView(
              controller: _tab,
              children: [
                _BackupTab(accent: accent, svc: svc,
                  passCtrl: _passCtrl, showPass: _showPass,
                  incImages: _incImages, actioning: _actioning,
                  onTogglePass:   () => setState(() => _showPass = !_showPass),
                  onToggleImages: () => setState(() => _incImages = !_incImages),
                  onCreateBackup: _createBackup,
                ),
                _RestoreTab(accent: accent, svc: svc,
                  actioning: _actioning,
                  onRestore:  _restore,
                  onValidate: _validate,
                  onDelete:   _delete,
                ),
                _ExportTab(accent: accent, svc: svc,
                  actioning: _actioning,
                  onExport: _export,
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  // ── Actions ──────────────────────────────────
  Future<void> _createBackup() async {
    setState(() => _actioning = true);
    final result = await BackupService.instance.createBackup(
      password:      _passCtrl.text.trim(),
      includeImages: _incImages,
      label:         'manual',
    );
    setState(() => _actioning = false);
    if (!mounted) return;
    _showSnack(result != null
        ? '✅ تم إنشاء النسخة الاحتياطية — ${result["size_kb"]}KB'
        : '❌ ${BackupService.instance.error}');
  }

  Future<void> _validate(String filename) async {
    final r = await BackupService.instance.validateBackup(
      filename, password: _passCtrl.text.trim());
    if (!mounted) return;
    final ok = r['ok'] as bool? ?? false;
    _showSnack(ok
        ? '✅ الملف سليم — ${(r["files"] as List?)?.length ?? 0} ملف'
        : '❌ ${(r["errors"] as List?)?.first ?? "خطأ"}');
  }

  Future<void> _restore(String filename) async {
    final confirm = await _confirmDialog(
      'استعادة النسخة الاحتياطية',
      'سيتم استبدال البيانات الحالية. هل أنت متأكد؟',
    );
    if (confirm != true) return;

    setState(() => _actioning = true);
    final r = await BackupService.instance.restore(
      filename, password: _passCtrl.text.trim());
    setState(() => _actioning = false);
    if (!mounted) return;
    final ok = r['ok'] as bool? ?? false;
    _showSnack(ok
        ? '✅ تم الاستعادة — ${(r["restored"] as List?)?.length ?? 0} ملف'
        : '❌ ${(r["errors"] as List?)?.first ?? "خطأ"}');
  }

  Future<void> _delete(String filename) async {
    final confirm = await _confirmDialog('حذف النسخة', 'سيتم حذف هذه النسخة نهائياً');
    if (confirm != true) return;
    final ok = await BackupService.instance.deleteBackup(filename);
    if (!mounted) return;
    _showSnack(ok ? '✅ تم الحذف' : '❌ فشل الحذف');
  }

  Future<void> _export(String format) async {
    setState(() => _actioning = true);
    ExportResult? r;
    switch (format) {
      case 'json':   r = await BackupService.instance.exportJson(); break;
      case 'csv':    r = await BackupService.instance.exportCsv(); break;
      case 'report': r = await BackupService.instance.exportReport(); break;
      case 'all':    r = await BackupService.instance.exportAll(); break;
    }
    setState(() => _actioning = false);
    if (!mounted) return;
    if (r?.ok == true) {
      _showSnack('✅ تم التصدير — ${r!.filename} (${r.sizeKb}KB)');
    } else {
      _showSnack('❌ فشل التصدير');
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Tajawal')),
      backgroundColor: const Color(0xFF0D1A2A),
      behavior: SnackBarBehavior.floating,
    ));
  }

  Future<bool?> _confirmDialog(String title, String body) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0D1520),
        title: Text(title, style: const TextStyle(
          color: Colors.white, fontFamily: 'Tajawal')),
        content: Text(body, style: const TextStyle(
          color: Colors.white70, fontFamily: 'Tajawal')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء', style: TextStyle(fontFamily: 'Tajawal'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تأكيد',
              style: TextStyle(color: Colors.orange, fontFamily: 'Tajawal'))),
        ],
      ),
    );
  }
}


// ── Backup Tab ────────────────────────────────────
class _BackupTab extends StatelessWidget {
  final Color accent;
  final BackupService svc;
  final TextEditingController passCtrl;
  final bool showPass, incImages, actioning;
  final VoidCallback onTogglePass, onToggleImages, onCreateBackup;
  const _BackupTab({
    required this.accent, required this.svc, required this.passCtrl,
    required this.showPass, required this.incImages, required this.actioning,
    required this.onTogglePass, required this.onToggleImages,
    required this.onCreateBackup,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Password
        _Label('🔐 كلمة مرور (اختياري)', accent),
        const SizedBox(height: 6),
        TextField(
          controller: passCtrl,
          obscureText: !showPass,
          style: const TextStyle(color: Colors.white, fontFamily: 'Tajawal'),
          decoration: InputDecoration(
            hintText: 'اتركه فارغاً بدون تشفير',
            hintStyle: const TextStyle(color: Colors.white30, fontFamily: 'Tajawal'),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white12)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white12)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: accent)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            suffixIcon: IconButton(
              icon: Icon(showPass ? Icons.visibility_off : Icons.visibility,
                color: Colors.white38, size: 18),
              onPressed: onTogglePass,
            ),
          ),
        ),

        const SizedBox(height: 14),

        // Include images toggle
        _ToggleRow('🖼️ تضمين الصور المولّدة', incImages, accent, onToggleImages),

        const SizedBox(height: 6),
        Text('الصور قد تزيد حجم النسخة بشكل كبير',
          style: const TextStyle(color: Colors.white30,
            fontSize: 11, fontFamily: 'Tajawal')),

        const SizedBox(height: 20),

        // Create button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: actioning ? null : onCreateBackup,
            icon: actioning
                ? const SizedBox(width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Icon(Icons.backup_rounded, size: 18),
            label: Text(actioning ? 'جاري الإنشاء...' : '💾 إنشاء نسخة احتياطية',
              style: const TextStyle(fontFamily: 'Tajawal',
                fontWeight: FontWeight.w800, fontSize: 14)),
            style: ElevatedButton.styleFrom(
              backgroundColor: accent,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),

        const SizedBox(height: 24),

        // What gets backed up
        _Label('📦 ما الذي يتم حفظه؟', accent),
        const SizedBox(height: 10),
        ...['💬 كل المحادثات', '🔔 التذكيرات والملاحظات',
            '🎙️ الاجتماعات والملخصات', '👤 ملفك الشخصي',
            '🤖 بيانات تدريب الـ LoRA'].map((item) =>
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              Icon(Icons.check_circle_rounded, color: accent, size: 14),
              const SizedBox(width: 8),
              Text(item, style: const TextStyle(
                color: Colors.white60, fontSize: 13, fontFamily: 'Tajawal')),
            ]),
          )),

        const SizedBox(height: 30),
      ]),
    );
  }
}


// ── Restore Tab ───────────────────────────────────
class _RestoreTab extends StatelessWidget {
  final Color accent;
  final BackupService svc;
  final bool actioning;
  final Function(String) onRestore, onValidate, onDelete;
  const _RestoreTab({required this.accent, required this.svc,
    required this.actioning, required this.onRestore,
    required this.onValidate, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    if (svc.loading) {
      return Center(child: CircularProgressIndicator(color: accent));
    }
    if (svc.backups.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.cloud_off_rounded, size: 48, color: Colors.white12),
          const SizedBox(height: 12),
          const Text('لا توجد نسخ احتياطية بعد',
            style: TextStyle(color: Colors.white30, fontFamily: 'Tajawal', fontSize: 14)),
        ]),
      );
    }

    return RefreshIndicator(
      color: accent,
      onRefresh: svc.loadBackups,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: svc.backups.length,
        itemBuilder: (ctx, i) {
          final b = svc.backups[i];
          return _BackupCard(
            item: b, accent: accent, actioning: actioning,
            onRestore:  () => onRestore(b.filename),
            onValidate: () => onValidate(b.filename),
            onDelete:   () => onDelete(b.filename),
          );
        },
      ),
    );
  }
}


// ── Export Tab ────────────────────────────────────
class _ExportTab extends StatelessWidget {
  final Color accent;
  final BackupService svc;
  final bool actioning;
  final Function(String) onExport;
  const _ExportTab({required this.accent, required this.svc,
    required this.actioning, required this.onExport});

  @override
  Widget build(BuildContext context) {
    final exports = [
      {'icon': '📄', 'title': 'JSON كامل',
       'desc': 'كل البيانات بصيغة JSON', 'fmt': 'json'},
      {'icon': '📊', 'title': 'CSV',
       'desc': 'محادثات + اجتماعات + تذكيرات', 'fmt': 'csv'},
      {'icon': '📋', 'title': 'تقرير HTML',
       'desc': 'تقرير منسّق قابل للطباعة', 'fmt': 'report'},
      {'icon': '📦', 'title': 'تصدير شامل',
       'desc': 'ZIP يحتوي كل الصيغ', 'fmt': 'all'},
    ];

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      children: [
        const SizedBox(height: 4),
        ...exports.map((e) => _ExportCard(
          icon:      e['icon']!,
          title:     e['title']!,
          desc:      e['desc']!,
          accent:    accent,
          loading:   actioning,
          onTap:     () => onExport(e['fmt']!),
        )),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('📁 مكان الملفات المصدّرة',
              style: TextStyle(color: accent, fontWeight: FontWeight.w700,
                fontFamily: 'Tajawal', fontSize: 13)),
            const SizedBox(height: 6),
            const Text('agent/backup/exports/',
              style: TextStyle(color: Colors.white38, fontSize: 12,
                fontFamily: 'monospace')),
          ]),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


// ── Sub-widgets ───────────────────────────────────
class _BackupCard extends StatelessWidget {
  final BackupItem item;
  final Color accent;
  final bool actioning;
  final VoidCallback onRestore, onValidate, onDelete;
  const _BackupCard({required this.item, required this.accent,
    required this.actioning, required this.onRestore,
    required this.onValidate, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1228),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.07)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(item.encrypted ? Icons.lock_rounded : Icons.lock_open_rounded,
            color: item.encrypted ? Colors.orange : Colors.white38, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(item.filename, style: const TextStyle(
              color: Colors.white70, fontSize: 12, fontFamily: 'monospace'),
              overflow: TextOverflow.ellipsis),
          ),
          Text('${item.sizeKb}KB', style: const TextStyle(
            color: Colors.white38, fontSize: 11, fontFamily: 'Tajawal')),
        ]),
        const SizedBox(height: 6),
        Text(item.ts, style: const TextStyle(
          color: Colors.white38, fontSize: 11, fontFamily: 'Tajawal')),
        const SizedBox(height: 10),
        Row(children: [
          _ActionBtn('✅ تحقق', accent.withOpacity(0.7), onValidate, actioning),
          const SizedBox(width: 8),
          _ActionBtn('🔄 استعادة', accent, onRestore, actioning),
          const Spacer(),
          GestureDetector(
            onTap: actioning ? null : onDelete,
            child: const Icon(Icons.delete_outline_rounded,
              color: Colors.red, size: 18)),
        ]),
      ]),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  final bool loading;
  const _ActionBtn(this.label, this.color, this.onTap, this.loading);
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: loading ? null : onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: color,
        fontFamily: 'Tajawal', fontWeight: FontWeight.w700)),
    ),
  );
}

class _ExportCard extends StatelessWidget {
  final String icon, title, desc;
  final Color accent;
  final bool loading;
  final VoidCallback onTap;
  const _ExportCard({required this.icon, required this.title,
    required this.desc, required this.accent,
    required this.loading, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: loading ? null : onTap,
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1228),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accent.withOpacity(0.15)),
      ),
      child: Row(children: [
        Text(icon, style: const TextStyle(fontSize: 28)),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white,
              fontWeight: FontWeight.w700, fontFamily: 'Tajawal', fontSize: 14)),
            const SizedBox(height: 3),
            Text(desc, style: const TextStyle(color: Colors.white38,
              fontSize: 11, fontFamily: 'Tajawal')),
          ]),
        ),
        loading
            ? SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: accent))
            : Icon(Icons.chevron_right_rounded, color: accent.withOpacity(0.5)),
      ]),
    ),
  );
}

Widget _Label(String text, Color accent) => Text(text,
  style: TextStyle(color: accent, fontSize: 12,
    fontWeight: FontWeight.w700, fontFamily: 'Tajawal'));

Widget _ToggleRow(String label, bool value, Color accent, VoidCallback onTap) =>
  GestureDetector(
    onTap: onTap,
    child: Row(children: [
      Switch(value: value, onChanged: (_) => onTap(),
        activeColor: accent),
      const SizedBox(width: 8),
      Text(label, style: const TextStyle(color: Colors.white70,
        fontSize: 13, fontFamily: 'Tajawal')),
    ]),
  );
