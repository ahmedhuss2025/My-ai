// lib/models/app_state.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/database_service.dart';

// ── Sentiment Colors ──────────────────────────────
const _sentColors = [
  Color(0xFF00FF9D), // متحمس
  Color(0xFF00C8FF), // هادئ
  Color(0xFFFF6B35), // مشغول
  Color(0xFF9D4EDD), // متعب
  Color(0xFFFF3860), // متوتر
];
const _sentLabels = ['متحمس', 'هادئ', 'مشغول', 'متعب', 'متوتر'];

// ════════════════════════════════════════════════
// NEURAL PREDICTION
// ════════════════════════════════════════════════
class NeuralPrediction {
  final List<String> behaviorLabels;
  final int patternIndex;
  final double patternConfidence;
  final int sentimentIndex;
  final String sentimentLabel;
  final double sentimentConfidence;
  final DateTime timestamp;

  const NeuralPrediction({
    this.behaviorLabels      = const [],
    this.patternIndex        = 8,
    this.patternConfidence   = 0.5,
    this.sentimentIndex      = 1,
    this.sentimentLabel      = 'هادئ',
    this.sentimentConfidence = 0.7,
    required this.timestamp,
  });

  Color get color => _sentColors[sentimentIndex.clamp(0, _sentColors.length - 1)];

  static NeuralPrediction get fresh => NeuralPrediction(timestamp: DateTime.now());
}

// ════════════════════════════════════════════════
// MESSAGE
// ════════════════════════════════════════════════
enum MessageStatus { sending, sent, error }

class Message {
  final String id;
  final String content;
  final bool isUser;
  final DateTime timestamp;
  final NeuralPrediction? prediction;
  final MessageStatus status;
  // Phase 10 — Multi-Agent metadata
  final String       agentMode;    // "single" | "parallel" | "fallback"
  final List<String> agentsUsed;

  const Message({
    required this.id,
    required this.content,
    required this.isUser,
    required this.timestamp,
    this.prediction,
    this.status     = MessageStatus.sent,
    this.agentMode  = 'single',
    this.agentsUsed = const [],
  });

  Message copyWith({MessageStatus? status}) => Message(
    id: id, content: content, isUser: isUser,
    timestamp: timestamp, prediction: prediction,
    status:     status ?? this.status,
    agentMode:  agentMode,
    agentsUsed: agentsUsed,
  );
}

// ════════════════════════════════════════════════
// APP STATE — ChangeNotifier
// ════════════════════════════════════════════════
class AppState extends ChangeNotifier {

  // ── Theme ─────────────────────────────────────
  ThemeMode _themeMode = ThemeMode.dark;
  Color _accentColor   = const Color(0xFF00C8FF);

  ThemeMode get themeMode  => _themeMode;
  Color     get accentColor => _accentColor;

  // ── Messages ──────────────────────────────────
  final List<Message> _messages = [];
  List<Message> get messages => List.unmodifiable(_messages);

  // ── Neural ────────────────────────────────────
  NeuralPrediction _lastPrediction = NeuralPrediction.fresh;
  NeuralPrediction get lastPrediction => _lastPrediction;

  // ── UI State ──────────────────────────────────
  bool _isThinking = false;
  bool get isThinking => _isThinking;

  // ── Stats (from SQLite) ───────────────────────
  int _todayMessages  = 0;
  int _goalsCompleted = 0;
  int _goalsTotal     = 0;
  int _streakDays     = 0;

  int get todayMessages  => _todayMessages;
  int get goalsCompleted => _goalsCompleted;
  int get goalsTotal     => _goalsTotal;
  int get streakDays     => _streakDays;

  // ── Init ──────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final themeIdx  = prefs.getInt('theme_mode')    ?? 0;
    final accentVal = prefs.getInt('accent_color')  ?? 0xFF00C8FF;
    _themeMode   = ThemeMode.values[themeIdx.clamp(0, 2)];
    _accentColor = Color(accentVal);

    // Load real stats from SQLite
    await loadStats();

    notifyListeners();
  }

  Future<void> loadStats() async {
    final stats = await DatabaseService.instance.getTodayStats();
    _todayMessages  = stats['messages']    ?? 0;
    _goalsCompleted = stats['tasks_done']  ?? 0;
    _goalsTotal     = stats['tasks_total'] ?? 0;
    _streakDays     = stats['streak']      ?? 0;
    notifyListeners();
  }

  Future<void> setGoals({required int done, required int total}) async {
    _goalsCompleted = done;
    _goalsTotal     = total;
    await DatabaseService.instance.updateTasks(done: done, total: total);
    notifyListeners();
  }

  // ── Theme setters ─────────────────────────────
  Future<void> setTheme(ThemeMode mode) async {
    _themeMode = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_mode', mode.index);
    notifyListeners();
  }

  Future<void> setAccent(Color color) async {
    _accentColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('accent_color', color.value);
    notifyListeners();
  }

  // ── Message ops ───────────────────────────────
  void addMessage(Message msg) {
    _messages.add(msg);
    if (msg.isUser) {
      _todayMessages++;
      // Refresh from DB async (don't block UI)
      DatabaseService.instance.getTodayStats().then((stats) {
        _todayMessages = stats['messages'] ?? _todayMessages;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  void setThinking(bool v) {
    _isThinking = v;
    notifyListeners();
  }

  void updatePrediction(NeuralPrediction p) {
    _lastPrediction = p;
    notifyListeners();
  }

  void clearMessages() {
    _messages.clear();
    _todayMessages = 0;
    notifyListeners();
  }
}
