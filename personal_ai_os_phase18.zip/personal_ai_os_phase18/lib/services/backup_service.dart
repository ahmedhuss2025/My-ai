// lib/services/backup_service.dart — Phase 14
// ══════════════════════════════════════════════════
// Backup & Restore & Export — Flutter side
// يتواصل مع Python agent عبر HTTP
// ══════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

// ── Models ────────────────────────────────────────
class BackupItem {
  final String filename;
  final double sizeKb;
  final String ts;
  final bool   encrypted;

  const BackupItem({
    required this.filename,
    required this.sizeKb,
    required this.ts,
    required this.encrypted,
  });

  factory BackupItem.fromJson(Map<String, dynamic> j) => BackupItem(
    filename:  j['filename']  as String? ?? '',
    sizeKb:    (j['size_kb'] as num?)?.toDouble() ?? 0,
    ts:        j['ts']        as String? ?? '',
    encrypted: j['encrypted'] as bool?   ?? false,
  );
}

class BackupStats {
  final int    count;
  final double totalSizeKb;
  final String latest;
  const BackupStats({this.count=0, this.totalSizeKb=0, this.latest=''});
  factory BackupStats.fromJson(Map<String, dynamic> j) => BackupStats(
    count:       j['count']          as int?    ?? 0,
    totalSizeKb: (j['total_size_kb'] as num?)?.toDouble() ?? 0,
    latest:      j['latest']         as String? ?? '',
  );
}

class ExportResult {
  final bool   ok;
  final String format;
  final String filename;
  final double sizeKb;
  final String error;
  const ExportResult({
    required this.ok, required this.format,
    required this.filename, required this.sizeKb, this.error = '',
  });
  factory ExportResult.fromJson(Map<String, dynamic> j) => ExportResult(
    ok:       j['ok']       as bool?   ?? false,
    format:   j['format']   as String? ?? '',
    filename: j['filename'] as String? ?? '',
    sizeKb:   (j['size_kb'] as num?)?.toDouble() ?? 0,
    error:    j['error']    as String? ?? '',
  );
}

// ── Service ───────────────────────────────────────
class BackupService extends ChangeNotifier {
  static final BackupService instance = BackupService._();
  BackupService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 60);

  bool           _loading  = false;
  String         _error    = '';
  List<BackupItem> _backups = [];
  BackupStats    _stats    = const BackupStats();

  bool             get loading => _loading;
  String           get error   => _error;
  List<BackupItem> get backups => _backups;
  BackupStats      get stats   => _stats;

  // ── Load list ─────────────────────────────────
  Future<void> loadBackups() async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http
          .get(Uri.parse('$_base/backups'))
          .timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final j    = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        final list = (j['backups'] as List?) ?? [];
        _backups   = list.map((e) => BackupItem.fromJson(e as Map<String, dynamic>)).toList();
        _stats     = j['stats'] != null
            ? BackupStats.fromJson(j['stats'] as Map<String, dynamic>)
            : const BackupStats();
      }
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
  }

  // ── Create backup ─────────────────────────────
  Future<Map<String, dynamic>?> createBackup({
    String password      = '',
    bool includeImages   = false,
    String label         = '',
  }) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http.post(
        Uri.parse('$_base/backup/create'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'password':       password,
          'include_images': includeImages,
          'label':          label,
        }),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) {
          await loadBackups();
          _loading = false; notifyListeners();
          return j;
        }
        _error = j['error'] as String? ?? 'فشل الـ backup';
      }
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
    return null;
  }

  // ── Validate ──────────────────────────────────
  Future<Map<String, dynamic>> validateBackup(
      String filename, {String password = ''}) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/backup/validate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'filename': filename, 'password': password}),
      ).timeout(const Duration(seconds: 20));
      if (r.statusCode == 200) {
        return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      }
    } catch (e) { return {'ok': false, 'errors': [e.toString()]}; }
    return {'ok': false, 'errors': ['Server error']};
  }

  // ── Restore ───────────────────────────────────
  Future<Map<String, dynamic>> restore(
      String filename, {String password = '', bool dryRun = false}) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http.post(
        Uri.parse('$_base/backup/restore'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'filename': filename,
          'password': password,
          'dry_run':  dryRun,
        }),
      ).timeout(_timeout);
      _loading = false; notifyListeners();
      if (r.statusCode == 200) {
        return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      }
    } catch (e) {
      _error = e.toString();
      _loading = false; notifyListeners();
    }
    return {'ok': false, 'errors': [_error]};
  }

  // ── Delete ────────────────────────────────────
  Future<bool> deleteBackup(String filename) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/backup/delete'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'filename': filename}),
      ).timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        await loadBackups();
        return true;
      }
    } catch (_) {}
    return false;
  }

  // ── Export ────────────────────────────────────
  Future<ExportResult?> exportJson({bool includeImages = false}) async {
    return _doExport('/export/json', {'include_images': includeImages});
  }

  Future<ExportResult?> exportCsv() async {
    return _doExport('/export/csv', {});
  }

  Future<ExportResult?> exportReport({String lang = 'ar'}) async {
    return _doExport('/export/report', {'lang': lang});
  }

  Future<ExportResult?> exportAll() async {
    return _doExport('/export/all', {});
  }

  Future<ExportResult?> _doExport(String endpoint, Map body) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http.post(
        Uri.parse('$_base$endpoint'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode(body),
      ).timeout(_timeout);
      _loading = false; notifyListeners();
      if (r.statusCode == 200) {
        return ExportResult.fromJson(
          jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>);
      }
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
    return null;
  }
}
