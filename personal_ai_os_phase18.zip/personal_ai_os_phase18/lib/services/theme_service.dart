// lib/services/theme_service.dart — Phase 15
// ══════════════════════════════════════════════════
// Theme + Language + Accessibility Service
// يحفظ كل الإعدادات في SharedPreferences
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../l10n/app_localizations.dart';

class ThemeService extends ChangeNotifier {
  static final ThemeService instance = ThemeService._();
  ThemeService._();

  // ── State ─────────────────────────────────────
  AppThemeId _themeId      = AppThemeId.cyberpunk;
  ThemeMode  _themeMode    = ThemeMode.dark;
  Locale     _locale       = const Locale('ar', 'SA');
  double     _fontScale    = 1.0;      // 0.8 → 1.4
  bool       _highContrast = false;
  bool       _reduceMotion = false;

  // ── Getters ───────────────────────────────────
  AppThemeId  get themeId       => _themeId;
  ThemeMode   get themeMode     => _themeMode;
  Locale      get locale        => _locale;
  double      get fontScale     => _fontScale;
  bool        get highContrast  => _highContrast;
  bool        get reduceMotion  => _reduceMotion;

  AppThemeData get themeData =>
      kThemes[_themeId] ?? kThemes[AppThemeId.cyberpunk]!;

  bool get isDark {
    switch (_themeMode) {
      case ThemeMode.dark:   return true;
      case ThemeMode.light:  return false;
      case ThemeMode.system:
        // Runtime check not possible in service — default dark
        return true;
    }
  }

  // Built ThemeData for MaterialApp
  ThemeData get darkTheme  => AppThemeBuilder.build(
    theme: themeData, isDark: true,
    fontScale: _fontScale, highContrast: _highContrast);

  ThemeData get lightTheme => AppThemeBuilder.build(
    theme: themeData, isDark: false,
    fontScale: _fontScale, highContrast: _highContrast);

  // Duration for animations (respects reduceMotion)
  Duration animDuration(Duration normal) =>
      _reduceMotion ? Duration.zero : normal;

  // ── Init ──────────────────────────────────────
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _themeId      = AppThemeId.values[
        (prefs.getInt('theme_id') ?? 0).clamp(0, AppThemeId.values.length - 1)];
    _themeMode    = ThemeMode.values[
        (prefs.getInt('theme_mode') ?? 0).clamp(0, 2)];
    final langCode= prefs.getString('locale_lang') ?? 'ar';
    final country = prefs.getString('locale_country') ?? 'SA';
    _locale       = Locale(langCode, country);
    _fontScale    = (prefs.getDouble('font_scale') ?? 1.0).clamp(0.8, 1.4);
    _highContrast = prefs.getBool('high_contrast') ?? false;
    _reduceMotion = prefs.getBool('reduce_motion')  ?? false;

    _syncAppColors();
    notifyListeners();
  }

  // ── Setters ───────────────────────────────────
  Future<void> setThemeId(AppThemeId id) async {
    _themeId = id;
    _syncAppColors();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_id', id.index);
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    _syncAppColors();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_mode', mode.index);
  }

  Future<void> setLocale(Locale locale) async {
    _locale = locale;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale_lang',    locale.languageCode);
    await prefs.setString('locale_country', locale.countryCode ?? '');
  }

  Future<void> setFontScale(double scale) async {
    _fontScale = scale.clamp(0.8, 1.4);
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('font_scale', _fontScale);
  }

  Future<void> setHighContrast(bool v) async {
    _highContrast = v;
    _syncAppColors();
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('high_contrast', v);
  }

  Future<void> setReduceMotion(bool v) async {
    _reduceMotion = v;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('reduce_motion', v);
  }

  // ── Sync AppColors static class ───────────────
  void _syncAppColors() {
    AppColors.update(themeData, isDark);
  }
}
