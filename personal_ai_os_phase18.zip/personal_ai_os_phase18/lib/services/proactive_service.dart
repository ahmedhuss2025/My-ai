// lib/services/proactive_service.dart — Phase 13
// ══════════════════════════════════════════════════
// Proactive AI Suggestions
//   • يجيب suggestions من /proactive كل 15 دقيقة
//   • يعرضها كـ floating banner في الـ UI
//   • يبعتها للـ widget عبر WidgetService
// ══════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'widget_service.dart';

// ── Model ─────────────────────────────────────────
class Suggestion {
  final String type;
  final String title;
  final String body;
  final String action;
  final int    priority;
  final String ts;

  const Suggestion({
    required this.type,
    required this.title,
    required this.body,
    this.action   = '',
    this.priority = 2,
    this.ts       = '',
  });

  factory Suggestion.fromJson(Map<String, dynamic> j) => Suggestion(
    type:     j['type']     as String? ?? 'tip',
    title:    j['title']    as String? ?? '',
    body:     j['body']     as String? ?? '',
    action:   j['action']   as String? ?? '',
    priority: j['priority'] as int?    ?? 2,
    ts:       j['ts']       as String? ?? '',
  );

  String get emoji {
    switch (type) {
      case 'reminder': return '🔔';
      case 'habit':    return '⚡';
      case 'summary':  return '📝';
      default:         return '💡';
    }
  }
}

// ── Service ───────────────────────────────────────
class ProactiveService extends ChangeNotifier {
  static final ProactiveService instance = ProactiveService._();
  ProactiveService._();

  static const _base = 'http://localhost:7070';

  List<Suggestion> _suggestions = [];
  Suggestion?      _active;       // currently shown banner
  Timer?           _timer;
  bool             _loading = false;

  List<Suggestion> get suggestions => _suggestions;
  Suggestion?      get active      => _active;
  bool             get hasActive   => _active != null;

  // ── Start polling ─────────────────────────────
  void init() {
    _fetchSuggestions();
    _timer = Timer.periodic(const Duration(minutes: 15), (_) {
      _fetchSuggestions();
    });
  }

  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ── Fetch from agent ──────────────────────────
  Future<void> _fetchSuggestions() async {
    if (_loading) return;
    _loading = true;
    try {
      final r = await http
          .get(Uri.parse('$_base/proactive'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        final j    = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        final list = (j['suggestions'] as List?) ?? [];
        _suggestions = list
            .map((e) => Suggestion.fromJson(e as Map<String, dynamic>))
            .toList();
        // Show highest priority suggestion as active banner
        if (_suggestions.isNotEmpty && _active == null) {
          _active = _suggestions.first;
          // Auto-dismiss after 8 seconds
          Future.delayed(const Duration(seconds: 8), dismissActive);
        }
        // Tell widget to refresh
        WidgetService.instance.triggerUpdate();
        notifyListeners();
      }
    } catch (_) {}
    _loading = false;
  }

  // ── Manual refresh ────────────────────────────
  Future<void> refresh() => _fetchSuggestions();

  // ── Dismiss active banner ─────────────────────
  void dismissActive() {
    _active = null;
    notifyListeners();
  }

  // ── Show specific suggestion ──────────────────
  void showSuggestion(Suggestion s) {
    _active = s;
    notifyListeners();
    Future.delayed(const Duration(seconds: 10), dismissActive);
  }
}
