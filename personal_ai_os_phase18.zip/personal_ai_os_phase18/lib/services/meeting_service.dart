// lib/services/meeting_service.dart — Phase 12
// ══════════════════════════════════════════════════
// تسجيل وتلخيص الاجتماعات
// الـ STT بيتم عبر speech_to_text (موجود من Phase 5)
// الـ transcript بيُرسَل للـ Python للتلخيص
// ══════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:speech_to_text/speech_to_text.dart' as stt;

// ── Models ────────────────────────────────────────
class Meeting {
  final String       id;
  final String       title;
  final List<String> attendees;
  final String       language;
  final String       transcript;
  final String       summary;
  final List<String> actionItems;
  final List<String> keywords;
  final int          durationS;
  final String       createdAt;

  const Meeting({
    required this.id,
    required this.title,
    this.attendees   = const [],
    this.language    = 'ar',
    this.transcript  = '',
    this.summary     = '',
    this.actionItems = const [],
    this.keywords    = const [],
    this.durationS   = 0,
    this.createdAt   = '',
  });

  factory Meeting.fromJson(Map<String, dynamic> j) => Meeting(
    id:          j['id']          as String? ?? '',
    title:       j['title']       as String? ?? 'اجتماع',
    attendees:   (j['attendees']  as List?)?.cast<String>() ?? [],
    language:    j['language']    as String? ?? 'ar',
    transcript:  j['transcript']  as String? ?? '',
    summary:     j['summary']     as String? ?? '',
    actionItems: (j['action_items'] as List?)?.cast<String>() ?? [],
    keywords:    (j['keywords']   as List?)?.cast<String>() ?? [],
    durationS:   j['duration_s']  as int?    ?? 0,
    createdAt:   j['created_at']  as String? ?? '',
  );

  bool get hasSummary  => summary.isNotEmpty;
  bool get hasTranscript => transcript.isNotEmpty;
  String get durationLabel {
    final m = durationS ~/ 60;
    final s = durationS % 60;
    return m > 0 ? '${m}د ${s}ث' : '${s}ث';
  }
}

class MeetingStats {
  final int    total;
  final int    summarized;
  final double totalDurationMin;
  final double avgDurationMin;

  const MeetingStats({
    this.total = 0, this.summarized = 0,
    this.totalDurationMin = 0, this.avgDurationMin = 0,
  });

  factory MeetingStats.fromJson(Map<String, dynamic> j) => MeetingStats(
    total:            j['total']             as int?    ?? 0,
    summarized:       j['summarized']        as int?    ?? 0,
    totalDurationMin: (j['total_duration_min'] as num?)?.toDouble() ?? 0,
    avgDurationMin:   (j['avg_duration_min']   as num?)?.toDouble() ?? 0,
  );
}

// ── Service ───────────────────────────────────────
class MeetingService extends ChangeNotifier {
  static final MeetingService instance = MeetingService._();
  MeetingService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 30);

  // Recording state
  final _stt          = stt.SpeechToText();
  bool  _sttReady     = false;
  bool  _recording    = false;
  String _activeMeetingId = '';
  final StringBuffer _transcriptBuf = StringBuffer();
  final Stopwatch    _stopwatch      = Stopwatch();

  // Data state
  bool          _loading  = false;
  String        _error    = '';
  List<Meeting> _meetings = [];
  MeetingStats  _stats    = const MeetingStats();

  // Getters
  bool          get loading         => _loading;
  String        get error           => _error;
  List<Meeting> get meetings        => _meetings;
  MeetingStats  get stats           => _stats;
  bool          get isRecording     => _recording;
  String        get liveTranscript  => _transcriptBuf.toString();
  int           get elapsedSeconds  => _stopwatch.elapsed.inSeconds;

  // ── Init STT ───────────────────────────────────
  Future<bool> initStt() async {
    if (_sttReady) return true;
    _sttReady = await _stt.initialize(
      onError: (e) => _error = e.errorMsg,
    );
    return _sttReady;
  }

  // ── Start recording ────────────────────────────
  Future<String?> startRecording({
    required String title,
    List<String> attendees = const [],
    String language = 'ar',
  }) async {
    if (_recording) return null;

    // 1. Create meeting in DB
    final m_id = await _createMeeting(title, attendees, language);
    if (m_id == null) return null;

    _activeMeetingId = m_id;
    _transcriptBuf.clear();
    _stopwatch
      ..reset()
      ..start();

    // 2. Start STT
    final ready = await initStt();
    if (ready) {
      await _stt.listen(
        localeId: language == 'ar' ? 'ar_SA' : 'en_US',
        onResult: (r) {
          if (r.finalResult) {
            _transcriptBuf.write('${r.recognizedWords} ');
            notifyListeners();
          }
        },
        listenMode: stt.ListenMode.dictation,
        pauseFor:   const Duration(seconds: 3),
      );
    }

    _recording = true;
    notifyListeners();
    return m_id;
  }

  // ── Stop recording ─────────────────────────────
  Future<Meeting?> stopRecording() async {
    if (!_recording) return null;
    _recording = false;
    _stopwatch.stop();
    await _stt.stop();

    final transcript = _transcriptBuf.toString().trim();
    final durationS  = _stopwatch.elapsed.inSeconds;
    final m_id       = _activeMeetingId;

    // Save transcript
    await _saveTranscript(m_id, transcript, durationS);

    // Auto-summarize
    final result = await summarize(m_id);

    await loadMeetings();
    notifyListeners();
    return result;
  }

  // ── Summarize ──────────────────────────────────
  Future<Meeting?> summarize(String meetingId) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/meeting/summarize'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({'meeting_id': meetingId}),
      ).timeout(_timeout);

      if (r.statusCode == 200) {
        return await getMeeting(meetingId);
      }
    } catch (_) {}
    return null;
  }

  // ── Load list ──────────────────────────────────
  Future<void> loadMeetings() async {
    _loading = true; notifyListeners();
    try {
      final r = await http
          .get(Uri.parse('$_base/meetings'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        final j    = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        final list = (j['meetings'] as List?) ?? [];
        _meetings  = list.map((e) => Meeting.fromJson(e as Map<String, dynamic>)).toList();
        _stats     = j['stats'] != null
            ? MeetingStats.fromJson(j['stats'] as Map<String, dynamic>)
            : const MeetingStats();
      }
    } catch (_) {}
    _loading = false;
    notifyListeners();
  }

  // ── Get single ─────────────────────────────────
  Future<Meeting?> getMeeting(String meetingId) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/meeting/get'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'meeting_id': meetingId}),
      ).timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        return Meeting.fromJson(j);
      }
    } catch (_) {}
    return null;
  }

  // ── Delete ─────────────────────────────────────
  Future<bool> deleteMeeting(String meetingId) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/meeting/delete'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'meeting_id': meetingId}),
      ).timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        await loadMeetings();
        return true;
      }
    } catch (_) {}
    return false;
  }

  // ── Private helpers ────────────────────────────
  Future<String?> _createMeeting(
      String title, List<String> attendees, String language) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/meeting/create'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'title': title, 'attendees': attendees, 'language': language,
        }),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        return j['meeting_id'] as String?;
      }
    } catch (_) {}
    return null;
  }

  Future<void> _saveTranscript(
      String meetingId, String transcript, int durationS) async {
    try {
      await http.post(
        Uri.parse('$_base/meeting/transcript'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'meeting_id': meetingId,
          'transcript': transcript,
          'duration_s': durationS,
        }),
      ).timeout(_timeout);
    } catch (_) {}
  }
}
