// lib/services/analytics_service.dart — Phase 17
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AnalyticsReport {
  final Map<String, dynamic> today;
  final List<Map<String, dynamic>> week;
  final Map<String, dynamic> totals;
  final Map<String, int>     heatmap;
  final Map<String, int>     features;
  const AnalyticsReport({
    this.today    = const {},
    this.week     = const [],
    this.totals   = const {},
    this.heatmap  = const {},
    this.features = const {},
  });
  factory AnalyticsReport.fromJson(Map<String, dynamic> j) => AnalyticsReport(
    today:    j['today']    as Map<String, dynamic>? ?? {},
    week:     (j['week']    as List? ?? []).map((e) => e as Map<String, dynamic>).toList(),
    totals:   j['totals']   as Map<String, dynamic>? ?? {},
    heatmap:  (j['heatmap'] as Map<String, dynamic>? ?? {}).map(
              (k, v) => MapEntry(k, (v as num).toInt())),
    features: (j['features'] as Map<String, dynamic>? ?? {}).map(
              (k, v) => MapEntry(k, (v as num).toInt())),
  );
}

class AnalyticsService extends ChangeNotifier {
  static final AnalyticsService instance = AnalyticsService._();
  AnalyticsService._();

  static const _base = 'http://localhost:7070';

  AnalyticsReport      _report   = const AnalyticsReport();
  List<Map<String, dynamic>> _insights = [];
  bool  _loading = false;

  AnalyticsReport      get report   => _report;
  List<Map<String, dynamic>> get insights => _insights;
  bool  get loading => _loading;

  Future<void> loadReport() async {
    _loading = true; notifyListeners();
    try {
      final futures = await Future.wait([
        http.get(Uri.parse('$_base/analytics/report'))
            .timeout(const Duration(seconds: 8)),
        http.get(Uri.parse('$_base/analytics/insights'))
            .timeout(const Duration(seconds: 8)),
      ]);
      if (futures[0].statusCode == 200) {
        _report = AnalyticsReport.fromJson(
          jsonDecode(utf8.decode(futures[0].bodyBytes)) as Map<String, dynamic>);
      }
      if (futures[1].statusCode == 200) {
        final j = jsonDecode(utf8.decode(futures[1].bodyBytes)) as Map<String, dynamic>;
        _insights = (j['insights'] as List? ?? [])
            .map((e) => e as Map<String, dynamic>).toList();
      }
    } catch (_) {}
    _loading = false; notifyListeners();
  }

  Future<void> track(String type, {String subtype='', double value=1, Map? meta}) async {
    try {
      await http.post(Uri.parse('$_base/analytics/track'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'type': type, 'subtype': subtype,
                          'value': value, 'meta': meta ?? {}}))
          .timeout(const Duration(seconds: 3));
    } catch (_) {}
  }

  // Convenience trackers
  void trackChat()    => track('chat');
  void trackVoice()   => track('voice');
  void trackMeeting() => track('meeting');
  void trackImage()   => track('image');
  void trackReminder({bool done = false}) =>
      track(done ? 'reminder_done' : 'reminder_create');
}
