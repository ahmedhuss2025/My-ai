// lib/services/voice_service.dart
// ══════════════════════════════════════════════════
// Voice Service — Phase 5
// STT: speech_to_text  (محلي على الفون)
// TTS: flutter_tts     (عربي)
// ══════════════════════════════════════════════════
import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class VoiceService extends ChangeNotifier {
  static final VoiceService instance = VoiceService._();
  VoiceService._();

  // ── STT ───────────────────────────────────────
  final _stt = SpeechToText();
  bool _sttReady    = false;
  bool _isListening = false;
  String _partialText = '';

  // ── TTS ───────────────────────────────────────
  final _tts = FlutterTts();
  bool _isSpeaking  = false;
  double _speechRate   = 0.45;   // 0.0 – 1.0
  double _speechPitch  = 1.0;
  double _speechVolume = 1.0;
  bool _ttsEnabled  = true;

  // ── Getters ───────────────────────────────────
  bool get isListening  => _isListening;
  bool get isSpeaking   => _isSpeaking;
  bool get sttReady     => _sttReady;
  bool get ttsEnabled   => _ttsEnabled;
  String get partialText => _partialText;

  // ══════════════════════════════════════════════
  // INIT
  // ══════════════════════════════════════════════
  Future<void> init() async {
    await _initSTT();
    await _initTTS();
    await _loadPrefs();
  }

  Future<void> _initSTT() async {
    _sttReady = await _stt.initialize(
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          _isListening = false;
          _partialText = '';
          notifyListeners();
        }
      },
      onError: (error) {
        debugPrint('[STT] error: ${error.errorMsg}');
        _isListening = false;
        notifyListeners();
      },
    );
    debugPrint('[STT] ready: $_sttReady');
  }

  Future<void> _initTTS() async {
    await _tts.setLanguage('ar-EG');          // عربي مصري أولاً
    await _tts.setSpeechRate(_speechRate);
    await _tts.setPitch(_speechPitch);
    await _tts.setVolume(_speechVolume);

    // Android: استخدم أحسن engine متاح
    final engines = await _tts.getEngines;
    debugPrint('[TTS] engines: $engines');

    _tts.setStartHandler(()  { _isSpeaking = true;  notifyListeners(); });
    _tts.setCompletionHandler(() { _isSpeaking = false; notifyListeners(); });
    _tts.setErrorHandler((_)  { _isSpeaking = false; notifyListeners(); });

    debugPrint('[TTS] initialized');
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _ttsEnabled  = prefs.getBool('voice_enabled') ?? true;
    _speechRate  = prefs.getDouble('speech_speed') ?? 0.45;
    await _tts.setSpeechRate(_speechRate);
    notifyListeners();
  }

  // ══════════════════════════════════════════════
  // STT — الاستماع
  // ══════════════════════════════════════════════

  /// ابدأ الاستماع — يستدعي [onResult] لما ينتهي
  Future<void> startListening({
    required void Function(String text) onResult,
    void Function(String partial)? onPartial,
  }) async {
    if (!_sttReady || _isListening) return;

    _isListening = true;
    _partialText = '';
    notifyListeners();

    await _stt.listen(
      localeId: 'ar_EG',
      listenFor: const Duration(seconds: 15),
      pauseFor:  const Duration(seconds: 3),
      onResult: (SpeechRecognitionResult result) {
        _partialText = result.recognizedWords;
        onPartial?.call(_partialText);
        notifyListeners();

        if (result.finalResult && _partialText.isNotEmpty) {
          _isListening = false;
          _partialText = '';
          notifyListeners();
          onResult(_partialText.isEmpty ? result.recognizedWords : _partialText);
        }
      },
      cancelOnError: true,
      partialResults: true,
    );
  }

  Future<void> stopListening() async {
    if (!_isListening) return;
    await _stt.stop();
    _isListening = false;
    _partialText = '';
    notifyListeners();
  }

  // ══════════════════════════════════════════════
  // TTS — الكلام
  // ══════════════════════════════════════════════

  Future<void> speak(String text) async {
    if (!_ttsEnabled || text.isEmpty) return;
    if (_isSpeaking) await stop();

    // نظّف الـ text من emojis وعلامات markdown
    final clean = _cleanForTTS(text);
    if (clean.isEmpty) return;

    await _tts.speak(clean);
  }

  Future<void> stop() async {
    await _tts.stop();
    _isSpeaking = false;
    notifyListeners();
  }

  // ── Settings ──────────────────────────────────

  Future<void> setRate(double rate) async {
    _speechRate = rate.clamp(0.1, 1.0);
    await _tts.setSpeechRate(_speechRate);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('speech_speed', _speechRate);
    notifyListeners();
  }

  Future<void> setEnabled(bool v) async {
    _ttsEnabled = v;
    if (!v) await stop();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('voice_enabled', v);
    notifyListeners();
  }

  // ── Helpers ───────────────────────────────────

  String _cleanForTTS(String text) {
    return text
        .replaceAll(RegExp(r'[\u{1F300}-\u{1FAFF}]', unicode: true), '') // emojis
        .replaceAll(RegExp(r'[*_`#]'), '')       // markdown
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceAll('→', 'الى')
        .replaceAll('←', 'من')
        .trim();
  }

  // ── Available locales ─────────────────────────
  Future<List<String>> availableArabicLocales() async {
    final locales = await _stt.locales();
    return locales
        .where((l) => l.localeId.startsWith('ar'))
        .map((l) => '${l.name} (${l.localeId})')
        .toList();
  }
}
