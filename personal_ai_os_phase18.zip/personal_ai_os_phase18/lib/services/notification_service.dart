// lib/services/notification_service.dart — Phase 16
// ══════════════════════════════════════════════════
// Flutter Notification Service
//   • يجلب التذكيرات من /reminders
//   • CRUD: create / update / delete / done / snooze
//   • يستقبل push من /notify
//   • يُظهر SnackBar + badge للتذكيرات الـ pending
// ══════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

// ── Models ────────────────────────────────────────
class Reminder {
  final String  id;
  final String  label;
  final String  time;
  final String? date;
  final String  repeat;
  final int     preAlert;
  final String  priority;
  final List<String> tags;
  final String  note;
  final bool    done;
  final String? snoozedTo;
  final String  createdAt;

  const Reminder({
    required this.id,
    required this.label,
    required this.time,
    this.date,
    this.repeat      = 'none',
    this.preAlert    = 10,
    this.priority    = 'normal',
    this.tags        = const [],
    this.note        = '',
    this.done        = false,
    this.snoozedTo,
    required this.createdAt,
  });

  factory Reminder.fromJson(Map<String, dynamic> j) => Reminder(
    id:        j['id']         as String? ?? '',
    label:     j['label']      as String? ?? '',
    time:      j['time']       as String? ?? '09:00',
    date:      j['date']       as String?,
    repeat:    j['repeat']     as String? ?? 'none',
    preAlert:  j['pre_alert']  as int?    ?? 10,
    priority:  j['priority']   as String? ?? 'normal',
    tags:      List<String>.from(j['tags']  as List? ?? []),
    note:      j['note']       as String? ?? '',
    done:      (j['done']      as int?    ?? 0) == 1,
    snoozedTo: j['snoozed_to'] as String?,
    createdAt: j['created_at'] as String? ?? '',
  );

  String get emoji {
    switch (priority) {
      case 'urgent': return '🚨';
      case 'high':   return '🔴';
      case 'low':    return '💬';
      default:       return '🔔';
    }
  }

  String get repeatLabel {
    switch (repeat) {
      case 'daily':    return 'يومياً';
      case 'weekly':   return 'أسبوعياً';
      case 'weekdays': return 'أيام العمل';
      case 'weekend':  return 'نهاية الأسبوع';
      case 'custom':   return 'مخصص';
      default:         return '';
    }
  }
}

class NotifStats {
  final int total, pending, fired, urgent;
  const NotifStats({this.total=0, this.pending=0, this.fired=0, this.urgent=0});
  factory NotifStats.fromJson(Map<String, dynamic> j) => NotifStats(
    total:   j['total']   as int? ?? 0,
    pending: j['pending'] as int? ?? 0,
    fired:   j['fired']   as int? ?? 0,
    urgent:  j['urgent']  as int? ?? 0,
  );
}


// ── Service ───────────────────────────────────────
class NotificationService extends ChangeNotifier {
  static final NotificationService instance = NotificationService._();
  NotificationService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 15);

  bool           _loading   = false;
  String         _error     = '';
  List<Reminder> _reminders = [];
  NotifStats     _stats     = const NotifStats();
  Timer?         _pollTimer;

  bool           get loading   => _loading;
  String         get error     => _error;
  List<Reminder> get reminders => _reminders;
  NotifStats     get stats     => _stats;

  List<Reminder> get pending =>
      _reminders.where((r) => !r.done).toList();

  List<Reminder> get urgent =>
      _reminders.where((r) => r.priority == 'urgent' && !r.done).toList();

  // ── Init ──────────────────────────────────────
  void init() {
    loadReminders();
    // Poll every 2 minutes
    _pollTimer = Timer.periodic(const Duration(minutes: 2), (_) {
      loadReminders();
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  // ── Load ──────────────────────────────────────
  Future<void> loadReminders({bool includeDone = false}) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http
          .get(Uri.parse('$_base/reminders?done=${includeDone ? 1 : 0}'))
          .timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final j    = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        final list = (j['reminders'] as List?) ?? [];
        _reminders = list.map((e) =>
          Reminder.fromJson(e as Map<String, dynamic>)).toList();
        if (j['stats'] != null) {
          _stats = NotifStats.fromJson(j['stats'] as Map<String, dynamic>);
        }
      }
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
  }

  // ── Create ────────────────────────────────────
  Future<String?> createReminder({
    required String label,
    required String time,
    String? date,
    String  repeat   = 'none',
    int     preAlert = 10,
    String  priority = 'normal',
    List<String> tags = const [],
    String  note     = '',
  }) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/reminder/create'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'label': label, 'time': time, 'date': date,
          'repeat': repeat, 'pre_alert': preAlert,
          'priority': priority, 'tags': tags, 'note': note,
        }),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) {
          await loadReminders();
          return j['id'] as String?;
        }
      }
    } catch (e) { _error = e.toString(); }
    notifyListeners();
    return null;
  }

  // ── Mark Done ─────────────────────────────────
  Future<bool> markDone(String id) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/reminder/done'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        await loadReminders();
        return true;
      }
    } catch (e) { _error = e.toString(); }
    notifyListeners();
    return false;
  }

  // ── Snooze ────────────────────────────────────
  Future<bool> snooze(String id, {int minutes = 10}) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/reminder/snooze'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id, 'minutes': minutes}),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        await loadReminders();
        return true;
      }
    } catch (e) { _error = e.toString(); }
    return false;
  }

  // ── Delete ────────────────────────────────────
  Future<bool> delete(String id) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/reminder/delete'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': id}),
      ).timeout(_timeout);
      if (r.statusCode == 200) {
        await loadReminders();
        return true;
      }
    } catch (e) { _error = e.toString(); }
    return false;
  }

  // ── Send test notification ─────────────────────
  Future<bool> sendTest({String? title, String? body}) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/alerts/test'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'title': title ?? '🔔 تنبيه تجريبي',
          'body':  body  ?? 'يعمل نظام التنبيهات بشكل صحيح!',
        }),
      ).timeout(_timeout);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }
}
