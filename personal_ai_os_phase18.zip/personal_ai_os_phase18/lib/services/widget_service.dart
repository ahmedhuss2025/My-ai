// lib/services/widget_service.dart — Phase 13
// ══════════════════════════════════════════════════
// Flutter side of the Home Screen Widget
//   • يستلم deeplinks من الـ widget (WIDGET_SCREEN)
//   • يطلب من Android يحدّث الـ widget بعد كل action
//   • يوفر WidgetNavigator لـ main_shell
// ══════════════════════════════════════════════════
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

// ── Widget deep-link screen names ─────────────────
enum WidgetScreen { chat, voice, meeting, none }

class WidgetService extends ChangeNotifier {
  static final WidgetService instance = WidgetService._();
  WidgetService._();

  static const _channel = MethodChannel('personal_ai_os/widget');

  WidgetScreen _pendingScreen = WidgetScreen.none;
  WidgetScreen get pendingScreen => _pendingScreen;

  // ── Init: listen for deeplinks from Android ────
  void init() {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'openScreen') {
        final screen = call.arguments as String? ?? '';
        _pendingScreen = _parseScreen(screen);
        notifyListeners();
      }
    });
  }

  // ── Consume pending deeplink ───────────────────
  WidgetScreen consumePending() {
    final s = _pendingScreen;
    _pendingScreen = WidgetScreen.none;
    return s;
  }

  // ── Ask Android to refresh widget data ─────────
  Future<void> triggerUpdate() async {
    try {
      await _channel.invokeMethod('updateWidget');
    } catch (_) {}
  }

  // ── Get widget prefs from Android ──────────────
  Future<Map<String, dynamic>> getWidgetData() async {
    try {
      final result = await _channel.invokeMethod<Map>('getWidgetData');
      return Map<String, dynamic>.from(result ?? {});
    } catch (_) {
      return {};
    }
  }

  WidgetScreen _parseScreen(String s) {
    switch (s) {
      case 'chat':    return WidgetScreen.chat;
      case 'voice':   return WidgetScreen.voice;
      case 'meeting': return WidgetScreen.meeting;
      default:        return WidgetScreen.none;
    }
  }
}
