// lib/services/agent_service.dart
// ══════════════════════════════════════════════════
// Flutter ←→ Python Agent
//
// طريقتين للتواصل:
//   1. HTTP  → Python Agent server (port 7070)
//   2. Platform Channel → GemmaEngine.kt (fallback)
//
// الـ Python Agent بيشتغل كـ background service
// ويستمع على localhost:7070
// ══════════════════════════════════════════════════
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../models/app_state.dart';
import 'database_service.dart';
import 'offline_service.dart';   // Phase 11

class AgentService {
  static final AgentService instance = AgentService._();
  AgentService._();

  // ── Config ────────────────────────────────────
  static const _agentUrl    = 'http://localhost:7070';
  static const _timeout     = Duration(seconds: 15);

  // Platform Channel fallback (GemmaEngine.kt)
  static const _gemmaChannel = MethodChannel('personal_ai_os/gemma');

  bool _agentReachable = false;
  bool _checked         = false;
  DateTime? _lastCheck;
  static const _checkTTL = Duration(seconds: 30);

  // ── Backend info ──────────────────────────────
  String  backendName   = '🟡 جاري الاتصال...';
  bool    gemmaOnline   = false;

  // ── Health check ──────────────────────────────
  Future<bool> checkAgent() async {
    // إعادة الفحص كل 30 ثانية
    final now = DateTime.now();
    if (_checked &&
        _lastCheck != null &&
        now.difference(_lastCheck!) < _checkTTL) {
      return _agentReachable;
    }
    try {
      final r = await http
          .get(Uri.parse('$_agentUrl/health'))
          .timeout(_timeout);
      _agentReachable = r.statusCode == 200;
      if (_agentReachable) {
        final data      = jsonDecode(r.body) as Map<String, dynamic>;
        backendName     = data['backend'] as String? ?? 'Agent';
        gemmaOnline     = data['gemma_online'] as bool? ?? false;
      }
    } catch (_) {
      _agentReachable = false;
    }
    _checked   = true;
    _lastCheck = now;
    return _agentReachable;
  }

  // يستدعيه لما الـ settings service يتغير
  void resetCache() {
    _checked    = false;
    _lastCheck  = null;
  }

  // ── Main chat ─────────────────────────────────
  Future<AgentResponse> chat(String userText) async {
    final available = await checkAgent();

    if (available) {
      return _chatHttp(userText);
    } else {
      return _chatPlatformChannel(userText);
    }
  }

  // ── Phase 10: Multi-Agent ─────────────────────
  /// يوجّه للـ orchestrator — يرجّع AgentResponse مع agentMode
  Future<AgentResponse> multiAgent(String text, {String context = ''}) async {
    final available = await checkAgent();
    if (!available) return chat(text);   // fallback

    try {
      final r = await http
          .post(
            Uri.parse('$_agentUrl/multi_agent'),
            headers: {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'message': text, 'context': context}),
          )
          .timeout(_timeout);

      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        return AgentResponse(
          text:        j['text']  as String? ?? '',
          agentMode:   j['mode']  as String? ?? 'single',
          agentsUsed:  (j['agents_used'] as List?)?.cast<String>() ?? [],
        );
      }
    } catch (_) {}
    return chat(text);
  }

  /// تصنيف الـ query بدون تشغيل (للـ UI)
  Future<Map<String, double>> classify(String text) async {
    try {
      final r = await http
          .post(
            Uri.parse('$_agentUrl/classify'),
            headers: {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'message': text}),
          )
          .timeout(const Duration(seconds: 3));

      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        final scores = j['scores'] as Map<String, dynamic>? ?? {};
        return scores.map((k, v) => MapEntry(k, (v as num).toDouble()));
      }
    } catch (_) {}
    return {};
  }

  // ── HTTP path (Python Agent) ──────────────────
  Future<AgentResponse> _chatHttp(String text) async {
    try {
      final r = await http
          .post(
            Uri.parse('$_agentUrl/chat'),
            headers: {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'message': text}),
          )
          .timeout(_timeout);

      if (r.statusCode == 200) {
        final data = jsonDecode(utf8.decode(r.bodyBytes));
        // Phase 11 — notify offline service we're online
        OfflineService.instance.refresh();
        return AgentResponse(
          text:          data['response'] as String? ?? '',
          toolsUsed:     List<String>.from(data['tools_used'] ?? []),
          sentiment:     data['sentiment'] as int? ?? 1,
          behaviors:     List<String>.from(data['behaviors'] ?? []),
          reminderSaved: data['reminder_id'] as String?,
          noteSaved:     data['note_id'] as String?,
          shouldSpeak:   data['should_speak'] as bool? ?? false,
        );
      }
    } catch (e) {
      // Agent مش شغال
      _agentReachable = false;
      _checked = false;

      // Phase 11 — enqueue for later if it's an important request
      final offline = OfflineService.instance;
      final isImportant = text.contains('ذكرني') || text.contains('احفظ') ||
                          text.contains('remind') || text.contains('save');
      if (isImportant) {
        await offline.enqueue('chat', {'message': text}, priority: 1);
        return AgentResponse(
          text: '📴 أنت offline دلوقتي.\n'
                '✅ حفظت طلبك وهتنفّذه لما الإنترنت يرجع.\n\n'
                '💬 "$text"',
          agentMode: 'queued',
        );
      }
    }
    return _chatPlatformChannel(text);
  }

  // ── Platform Channel path (GemmaEngine.kt) ───
  Future<AgentResponse> _chatPlatformChannel(String text) async {
    try {
      final result = await _gemmaChannel.invokeMethod<String>(
        'generate',
        {'prompt': _buildPrompt(text), 'maxTokens': 512, 'temperature': 0.3},
      );

      if (result != null && result.isNotEmpty) {
        return AgentResponse(text: result);
      }
    } on PlatformException {
      // Gemma مش محمّل → smart fallback
    }
    return _smartFallback(text);
  }

  // ── Smart fallback (offline rules) ───────────
  AgentResponse _smartFallback(String text) {
    final t = text.toLowerCase();

    if (_has(t, ['صباح', 'good morning'])) {
      return AgentResponse(
        text: '☀️ صباح النور!\nإيه أول حاجة تبدأ بيها النهارده؟',
        sentiment: 0,
      );
    }
    if (_has(t, ['ذكرني', 'تذكير', 'remind'])) {
      return AgentResponse(
        text: '🔔 تمام! بس محتاج منك:\n• الوقت (مثال: 3 العصر)\n• الموضوع (مثال: اجتماع العميل)',
        behaviors: ['يريد تذكير'],
      );
    }
    if (_has(t, ['ابحث', 'دور', 'search', 'سعر'])) {
      return AgentResponse(
        text: '🔍 بابحث...\n\nالـ Agent Server مش شغال دلوقتي.\nشغّل: python agent/server.py',
        behaviors: ['يريد بحث'],
      );
    }
    if (_has(t, ['احسب', 'calculate'])) {
      return AgentResponse(
        text: '🧮 الـ Agent Server مش شغال.\nشغّل: python agent/server.py\nوكمّل الحساب هناك.',
      );
    }
    if (_has(t, ['إحصائيات', 'stats', 'إنتاجية'])) {
      return AgentResponse(
        text: '📊 جاري جلب الإحصائيات...',
        behaviors: ['يريد تقرير'],
      );
    }
    if (_has(t, ['شكراً', 'شكرا', 'thanks'])) {
      return AgentResponse(text: '💙 العفو دايماً!', sentiment: 0);
    }

    return AgentResponse(
      text: '🤖 فاهمك!\nقولي أكتر وهساعدك.\n\n💡 لأحسن تجربة شغّل:\npython agent/server.py',
    );
  }

  // ── Handle side effects ───────────────────────
  // بعد رد الـ Agent، بيحفظ الـ side effects في SQLite
  Future<void> handleSideEffects(AgentResponse resp) async {
    final db = DatabaseService.instance;

    if (resp.reminderSaved != null) {
      // الـ Agent حفظ تذكير → نمرره لـ SQLite
      // (الـ agent بيرجع reminder_id إشارة إنه خلص)
    }
    if (resp.noteSaved != null) {
      // نفس الفكرة مع الـ notes
    }
  }

  // ── Prompt for Gemma ──────────────────────────
  String _buildPrompt(String text) {
    return '<start_of_turn>user\n$text<end_of_turn>\n<start_of_turn>model\n';
  }

  bool _has(String text, List<String> kw) => kw.any((w) => text.contains(w));
}

// ══════════════════════════════════════════════════
// AGENT RESPONSE MODEL
// ══════════════════════════════════════════════════
class AgentResponse {
  final String text;
  final List<String> toolsUsed;
  final int sentiment;
  final List<String> behaviors;
  final String? reminderSaved;
  final String? noteSaved;
  final bool shouldSpeak;
  // Phase 10 — Multi-Agent
  final String       agentMode;    // "single" | "parallel" | "fallback"
  final List<String> agentsUsed;

  const AgentResponse({
    required this.text,
    this.toolsUsed    = const [],
    this.sentiment    = 1,
    this.behaviors    = const [],
    this.reminderSaved,
    this.noteSaved,
    this.shouldSpeak  = false,
    this.agentMode    = 'single',
    this.agentsUsed   = const [],
  });

  // تحويل لـ NeuralPrediction للـ UI
  NeuralPrediction toPrediction() => NeuralPrediction(
    sentimentIndex:  sentiment,
    sentimentLabel:  ['متحمس','هادئ','مشغول','متعب','متوتر']
                       .elementAtOrNull(sentiment) ?? 'هادئ',
    behaviorLabels:  behaviors,
    timestamp:       DateTime.now(),
  );
}
