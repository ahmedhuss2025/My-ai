// lib/services/screen_service.dart — Phase 7
// ══════════════════════════════════════════════════
// Screen Intelligence Service
// يتواصل مع AIAccessibilityService.kt عبر Platform Channel
// ══════════════════════════════════════════════════
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

class ScreenService extends ChangeNotifier {
  static final ScreenService instance = ScreenService._();
  ScreenService._();

  static const _ch = MethodChannel('personal_ai_os/screen');

  bool   _accessibilityEnabled = false;
  Map<String, String>? _currentContext;

  bool   get accessibilityEnabled => _accessibilityEnabled;
  Map<String, String>? get currentContext => _currentContext;

  // ── Init — يفحص الـ permission ────────────────
  Future<void> init() async {
    await checkAccessibility();
  }

  // ── Check if accessibility is on ──────────────
  Future<bool> checkAccessibility() async {
    try {
      final enabled = await _ch.invokeMethod<bool>('isAccessibilityEnabled') ?? false;
      _accessibilityEnabled = enabled;
      notifyListeners();
      return enabled;
    } catch (_) {
      _accessibilityEnabled = false;
      return false;
    }
  }

  // ── Open accessibility settings ────────────────
  Future<void> requestPermission() async {
    try {
      await _ch.invokeMethod('requestAccessibilityPermission');
    } catch (_) {}
  }

  // ── Get current screen context ─────────────────
  Future<Map<String, String>?> getScreenContext() async {
    try {
      final result = await _ch.invokeMethod<Map>('getScreenContext');
      if (result == null) return null;
      _currentContext = result.map((k, v) => MapEntry(k.toString(), v.toString()));
      notifyListeners();
      return _currentContext;
    } catch (_) {
      return null;
    }
  }

  // ── Show suggestion on overlay ─────────────────
  Future<void> showSuggestion(String text, {String appName = 'AI'}) async {
    try {
      await _ch.invokeMethod('showSuggestion', {
        'text':    text,
        'appName': appName,
      });
    } catch (_) {}
  }

  // ── Hide overlay ───────────────────────────────
  Future<void> hideOverlay() async {
    try {
      await _ch.invokeMethod('hideOverlay');
    } catch (_) {}
  }
}
