// lib/services/ai_service.dart — Phase 10
// ══════════════════════════════════════════════════
// الواجهة الرئيسية للـ Chat
// Phase 10: يستخدم Multi-Agent Orchestrator
// ══════════════════════════════════════════════════
import 'package:uuid/uuid.dart';
import '../models/app_state.dart';
import 'agent_service.dart';
import 'database_service.dart';
import 'voice_service.dart';

class AIService {
  static final AIService instance = AIService._();
  AIService._();

  final _uuid = const Uuid();

  // ── Smart routing — Phase 10 ──────────────────
  Future<Message> chat(String text, AppState state) async {
    final response = await _route(text);

    final prediction = response.toPrediction();
    state.updatePrediction(prediction);

    final msg = Message(
      id:         _uuid.v4(),
      content:    response.text,
      isUser:     false,
      timestamp:  DateTime.now(),
      prediction: prediction,
      agentMode:  response.agentMode,
      agentsUsed: response.agentsUsed,
    );

    await DatabaseService.instance.insertMessage(msg);
    await AgentService.instance.handleSideEffects(response);

    if (response.shouldSpeak) {
      VoiceService.instance.speak(response.text);
    }
    return msg;
  }

  Future<AgentResponse> _route(String text) async {
    final svc = AgentService.instance;
    try {
      final scores = await svc.classify(text);
      if (scores.isNotEmpty) {
        final maxScore = scores.values.reduce((a, b) => a > b ? a : b);
        if (maxScore >= 0.50) {
          return svc.multiAgent(text);
        }
      }
    } catch (_) {}
    return svc.chat(text);
  }

  Future<List<Message>> loadHistory({int limit = 50}) async {
    return DatabaseService.instance.loadRecentMessages(limit: limit);
  }

  Future<Message> saveUserMessage(String text) async {
    final msg = Message(
      id:        _uuid.v4(),
      content:   text,
      isUser:    true,
      timestamp: DateTime.now(),
    );
    await DatabaseService.instance.insertMessage(msg);
    return msg;
  }

  Future<String> getStatus() async {
    final online = await AgentService.instance.checkAgent();
    return online ? '🟢 Agent Online' : '🟡 Offline Mode';
  }
}
