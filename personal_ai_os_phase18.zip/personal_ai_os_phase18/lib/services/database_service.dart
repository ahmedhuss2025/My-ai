// lib/services/database_service.dart
// ══════════════════════════════════════════════════
// SQLite — كل بيانات الـ App
// Messages + Notes + Reminders + Stats
// AES-256 في الإنتاج (دلوقتي plain SQLite)
// ══════════════════════════════════════════════════
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/app_state.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._();
  DatabaseService._();

  Database? _db;

  Future<Database> get db async {
    _db ??= await _open();
    return _db!;
  }

  // ── Open / Create ─────────────────────────────
  Future<Database> _open() async {
    final dbPath = join(await getDatabasesPath(), 'personal_ai.db');
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Messages table
    await db.execute('''
      CREATE TABLE messages (
        id          TEXT PRIMARY KEY,
        content     TEXT NOT NULL,
        is_user     INTEGER NOT NULL,
        timestamp   TEXT NOT NULL,
        sentiment   INTEGER DEFAULT 1,
        behaviors   TEXT DEFAULT '',
        status      TEXT DEFAULT 'sent'
      )
    ''');

    // Notes table
    await db.execute('''
      CREATE TABLE notes (
        id        TEXT PRIMARY KEY,
        title     TEXT NOT NULL,
        content   TEXT NOT NULL,
        tags      TEXT DEFAULT '',
        created   TEXT NOT NULL,
        updated   TEXT NOT NULL
      )
    ''');

    // Reminders table
    await db.execute('''
      CREATE TABLE reminders (
        id          TEXT PRIMARY KEY,
        label       TEXT NOT NULL,
        time        TEXT NOT NULL,
        pre_alert   INTEGER DEFAULT 10,
        is_done     INTEGER DEFAULT 0,
        created     TEXT NOT NULL
      )
    ''');

    // Stats table (one row per day)
    await db.execute('''
      CREATE TABLE daily_stats (
        date          TEXT PRIMARY KEY,
        messages      INTEGER DEFAULT 0,
        tasks_done    INTEGER DEFAULT 0,
        tasks_total   INTEGER DEFAULT 0,
        streak_days   INTEGER DEFAULT 0
      )
    ''');
  }

  // ══════════════════════════════════════════════
  // MESSAGES
  // ══════════════════════════════════════════════

  Future<void> insertMessage(Message msg) async {
    final d = await db;
    await d.insert(
      'messages',
      {
        'id':        msg.id,
        'content':   msg.content,
        'is_user':   msg.isUser ? 1 : 0,
        'timestamp': msg.timestamp.toIso8601String(),
        'sentiment': msg.prediction?.sentimentIndex ?? 1,
        'behaviors': msg.prediction?.behaviorLabels.join(',') ?? '',
        'status':    msg.status.name,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    // bump today's message count
    await _bumpStat('messages');
  }

  Future<List<Message>> loadRecentMessages({int limit = 50}) async {
    final d = await db;
    final rows = await d.query(
      'messages',
      orderBy: 'timestamp DESC',
      limit: limit,
    );
    return rows.reversed.map(_rowToMessage).toList();
  }

  Future<void> clearMessages() async {
    final d = await db;
    await d.delete('messages');
  }

  Message _rowToMessage(Map<String, dynamic> row) {
    final behaviors = (row['behaviors'] as String)
        .split(',')
        .where((s) => s.isNotEmpty)
        .toList();
    return Message(
      id:        row['id'] as String,
      content:   row['content'] as String,
      isUser:    (row['is_user'] as int) == 1,
      timestamp: DateTime.parse(row['timestamp'] as String),
      prediction: NeuralPrediction(
        sentimentIndex: row['sentiment'] as int,
        sentimentLabel: _sentLabel(row['sentiment'] as int),
        behaviorLabels: behaviors,
        timestamp: DateTime.parse(row['timestamp'] as String),
      ),
      status: MessageStatus.values.firstWhere(
        (s) => s.name == row['status'],
        orElse: () => MessageStatus.sent,
      ),
    );
  }

  String _sentLabel(int i) =>
      ['متحمس', 'هادئ', 'مشغول', 'متعب', 'متوتر'].elementAtOrNull(i) ?? 'هادئ';

  // ══════════════════════════════════════════════
  // NOTES
  // ══════════════════════════════════════════════

  Future<String> insertNote(String title, String content, {String tags = ''}) async {
    final d   = await db;
    final id  = 'NOTE_${DateTime.now().millisecondsSinceEpoch}';
    final now = DateTime.now().toIso8601String();
    await d.insert('notes', {
      'id': id, 'title': title, 'content': content,
      'tags': tags, 'created': now, 'updated': now,
    });
    return id;
  }

  Future<List<Map<String, dynamic>>> loadNotes() async {
    final d = await db;
    return d.query('notes', orderBy: 'updated DESC');
  }

  // ══════════════════════════════════════════════
  // REMINDERS
  // ══════════════════════════════════════════════

  Future<String> insertReminder(String label, String time, {int preAlert = 10}) async {
    final d  = await db;
    final id = 'REM_${DateTime.now().millisecondsSinceEpoch}';
    await d.insert('reminders', {
      'id': id, 'label': label, 'time': time,
      'pre_alert': preAlert, 'is_done': 0,
      'created': DateTime.now().toIso8601String(),
    });
    return id;
  }

  Future<List<Map<String, dynamic>>> loadPendingReminders() async {
    final d = await db;
    return d.query('reminders',
      where: 'is_done = 0',
      orderBy: 'time ASC',
    );
  }

  Future<void> markReminderDone(String id) async {
    final d = await db;
    await d.update('reminders', {'is_done': 1}, where: 'id = ?', whereArgs: [id]);
  }

  // ══════════════════════════════════════════════
  // STATS
  // ══════════════════════════════════════════════

  Future<void> _bumpStat(String column) async {
    final d   = await db;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    await d.execute('''
      INSERT INTO daily_stats (date, $column)
      VALUES (?, 1)
      ON CONFLICT(date) DO UPDATE SET $column = $column + 1
    ''', [today]);
  }

  Future<Map<String, int>> getTodayStats() async {
    final d     = await db;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final rows  = await d.query('daily_stats', where: 'date = ?', whereArgs: [today]);
    if (rows.isEmpty) return {'messages': 0, 'tasks_done': 0, 'tasks_total': 0, 'streak': 0};
    final row = rows.first;
    return {
      'messages':    row['messages']    as int? ?? 0,
      'tasks_done':  row['tasks_done']  as int? ?? 0,
      'tasks_total': row['tasks_total'] as int? ?? 0,
      'streak':      row['streak_days'] as int? ?? 0,
    };
  }

  Future<void> updateTasks({required int done, required int total}) async {
    final d     = await db;
    final today = DateTime.now().toIso8601String().substring(0, 10);
    await d.execute('''
      INSERT INTO daily_stats (date, tasks_done, tasks_total)
      VALUES (?, ?, ?)
      ON CONFLICT(date) DO UPDATE SET tasks_done = ?, tasks_total = ?
    ''', [today, done, total, done, total]);
  }
}
