// lib/services/ambient_service.dart — Phase 9
// ══════════════════════════════════════════════════
// يجيب الـ insights والـ profile من Python server
// ويخزّنهم محلياً للـ Dashboard
// ══════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

// ── Insight card model ────────────────────────────
class InsightCard {
  final String icon;
  final String title;
  final String subtitle;
  final String color;

  const InsightCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
  });

  factory InsightCard.fromJson(Map<String, dynamic> j) => InsightCard(
    icon:     j['icon']     as String? ?? '💡',
    title:    j['title']    as String? ?? '',
    subtitle: j['subtitle'] as String? ?? '',
    color:    j['color']    as String? ?? 'cyan',
  );
}

// ── User profile summary ──────────────────────────
class UserProfileSummary {
  final String name;
  final int    wakeHour;
  final int    sleepHour;
  final List<int>    peakHours;
  final List<String> topTopics;
  final List<String> topApps;
  final bool   prefersShort;
  final bool   morningPerson;
  final int    streakRecord;
  final double completionRate;
  final String context;   // مكثّف للـ agent

  const UserProfileSummary({
    this.name          = '',
    this.wakeHour      = 7,
    this.sleepHour     = 23,
    this.peakHours     = const [],
    this.topTopics     = const [],
    this.topApps       = const [],
    this.prefersShort  = true,
    this.morningPerson = true,
    this.streakRecord  = 0,
    this.completionRate = 0.0,
    this.context       = '',
  });

  factory UserProfileSummary.fromJson(Map<String, dynamic> j) {
    final sleep   = j['sleep']   as Map? ?? {};
    final prefs   = j['inferred_prefs'] as Map? ?? {};
    final peak    = j['peak_hours'] as Map? ?? {};
    final prod    = j['productivity'] as Map? ?? {};
    final conv    = j['conversation'] as Map? ?? {};

    return UserProfileSummary(
      name:           j['name']  as String? ?? '',
      wakeHour:       sleep['usual_wake_hour']  as int? ?? 7,
      sleepHour:      sleep['usual_sleep_hour'] as int? ?? 23,
      peakHours:      (peak['most_active'] as List?)?.cast<int>() ?? [],
      topTopics:      (conv['favorite_topics'] as List?)?.cast<String>() ?? [],
      topApps:        ((j['top_apps'] as List?) ?? [])
                          .map((a) => (a as Map)['name']?.toString() ?? '')
                          .where((s) => s.isNotEmpty)
                          .take(5)
                          .toList(),
      prefersShort:   prefs['prefers_short']  as bool? ?? true,
      morningPerson:  prefs['morning_person'] as bool? ?? true,
      streakRecord:   prod['streak_record']   as int?  ?? 0,
      completionRate: (prod['completion_rate'] as num?)?.toDouble() ?? 0.0,
    );
  }
}


// ── Service ───────────────────────────────────────
class AmbientService extends ChangeNotifier {
  static final AmbientService instance = AmbientService._();
  AmbientService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 5);

  List<InsightCard>   _cards   = [];
  UserProfileSummary? _profile;
  String              _ctx     = '';
  bool                _loading = false;
  DateTime?           _lastFetch;

  List<InsightCard>   get cards   => _cards;
  UserProfileSummary? get profile => _profile;
  String              get context => _ctx;
  bool                get loading => _loading;
  bool                get hasData => _cards.isNotEmpty || _profile != null;

  // ── Fetch insights (max once per 5 min) ──────────
  Future<void> fetchInsights({bool force = false}) async {
    if (_loading) return;
    if (!force && _lastFetch != null &&
        DateTime.now().difference(_lastFetch!) < const Duration(minutes: 5)) return;

    _loading = true;
    notifyListeners();

    try {
      final r = await http
          .get(Uri.parse('$_base/insights'))
          .timeout(_timeout);

      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;

        final rawCards = (j['cards'] as List?) ?? [];
        _cards  = rawCards.map((c) => InsightCard.fromJson(c as Map<String, dynamic>)).toList();
        _ctx    = j['profile'] as String? ?? '';
        _lastFetch = DateTime.now();
      }
    } catch (_) {
      // server offline — show cached
    }

    _loading = false;
    notifyListeners();
  }

  // ── Fetch profile ─────────────────────────────────
  Future<void> fetchProfile() async {
    try {
      final r = await http
          .get(Uri.parse('$_base/profile'))
          .timeout(_timeout);

      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        _profile = UserProfileSummary.fromJson(j);
        notifyListeners();
      }
    } catch (_) {}
  }

  // ── Trigger analysis ──────────────────────────────
  Future<bool> triggerAnalysis() async {
    try {
      final r = await http
          .post(
            Uri.parse('$_base/ambient/analyze'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({}),
          )
          .timeout(_timeout);
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Init ──────────────────────────────────────────
  Future<void> init() async {
    await fetchInsights();
    await fetchProfile();
  }
}
