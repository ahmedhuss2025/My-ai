// lib/services/image_service.dart — Phase 12
// ══════════════════════════════════════════════════
// توليد وتعديل الصور عبر Python Agent
// ══════════════════════════════════════════════════
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

// ── Models ────────────────────────────────────────
class GeneratedImage {
  final String imageId;
  final String filename;
  final String base64;
  final String provider;
  final String prompt;
  final double sizeKb;
  final String ts;

  const GeneratedImage({
    required this.imageId,
    required this.filename,
    required this.base64,
    required this.provider,
    required this.prompt,
    required this.sizeKb,
    required this.ts,
  });

  factory GeneratedImage.fromJson(Map<String, dynamic> j) => GeneratedImage(
    imageId:  j['image_id']  as String? ?? '',
    filename: j['filename']  as String? ?? '',
    base64:   j['base64']    as String? ?? '',
    provider: j['provider']  as String? ?? '',
    prompt:   j['prompt']    as String? ?? '',
    sizeKb:   (j['size_kb']  as num?)?.toDouble() ?? 0,
    ts:       j['ts']        as String? ?? '',
  );

  Uint8List get bytes => base64Decode(base64);
}

class ImageItem {
  final String filename;
  final double sizeKb;
  final String ts;
  const ImageItem({required this.filename, required this.sizeKb, required this.ts});

  factory ImageItem.fromJson(Map<String, dynamic> j) => ImageItem(
    filename: j['filename'] as String? ?? '',
    sizeKb:   (j['size_kb'] as num?)?.toDouble() ?? 0,
    ts:       j['ts']       as String? ?? '',
  );
}

// ── Service ───────────────────────────────────────
class ImageService extends ChangeNotifier {
  static final ImageService instance = ImageService._();
  ImageService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 45);

  bool                  _loading = false;
  String                _error   = '';
  List<ImageItem>       _gallery = [];
  GeneratedImage?       _last;

  bool              get loading => _loading;
  String            get error   => _error;
  List<ImageItem>   get gallery => _gallery;
  GeneratedImage?   get last    => _last;

  // ── Generate ───────────────────────────────────
  Future<GeneratedImage?> generate({
    required String prompt,
    String style    = 'realistic',
    String size     = '512x512',
    String negative = '',
  }) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http.post(
        Uri.parse('$_base/image/generate'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'prompt': prompt, 'style': style,
          'size': size, 'negative': negative,
        }),
      ).timeout(_timeout);

      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) {
          _last    = GeneratedImage.fromJson(j);
          _loading = false;
          notifyListeners();
          await loadGallery();
          return _last;
        }
        _error = j['error'] as String? ?? 'خطأ غير معروف';
      }
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
    return null;
  }

  // ── Edit ───────────────────────────────────────
  Future<GeneratedImage?> edit({
    required String filename,
    required String operation,
    Map<String, dynamic> params = const {},
  }) async {
    _loading = true; _error = ''; notifyListeners();
    try {
      final r = await http.post(
        Uri.parse('$_base/image/edit'),
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'filename': filename, 'operation': operation, 'params': params,
        }),
      ).timeout(_timeout);

      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) {
          _last = GeneratedImage.fromJson(j);
          _loading = false;
          notifyListeners();
          await loadGallery();
          return _last;
        }
        _error = j['error'] as String? ?? 'خطأ في التعديل';
      }
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
    return null;
  }

  // ── Load gallery ───────────────────────────────
  Future<void> loadGallery() async {
    try {
      final r = await http
          .get(Uri.parse('$_base/images'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        final j    = jsonDecode(r.body) as Map<String, dynamic>;
        final list = (j['images'] as List?) ?? [];
        _gallery   = list.map((e) => ImageItem.fromJson(e as Map<String, dynamic>)).toList();
        notifyListeners();
      }
    } catch (_) {}
  }

  // ── Get image bytes ────────────────────────────
  Future<Uint8List?> getImageBytes(String filename) async {
    try {
      final r = await http.post(
        Uri.parse('$_base/image/get'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'filename': filename}),
      ).timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        final b64 = j['base64'] as String?;
        if (b64 != null) return base64Decode(b64);
      }
    } catch (_) {}
    return null;
  }
}
