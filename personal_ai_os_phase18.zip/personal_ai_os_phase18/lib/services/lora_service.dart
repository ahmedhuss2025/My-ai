// lib/services/lora_service.dart — Phase 8
// ══════════════════════════════════════════════════
// يتواصل مع Python server لـ LoRA training
// ══════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

enum LoraState { idle, exporting, training, merging, done, error, unavailable }

class LoraStatus {
  final LoraState state;
  final int       progress;   // 0–100
  final String    message;
  final int       samples;
  final int       stepsDone;
  final int       stepsTotal;
  final String    modelPath;
  final String    updatedAt;
  final String    error;

  const LoraStatus({
    this.state      = LoraState.idle,
    this.progress   = 0,
    this.message    = '',
    this.samples    = 0,
    this.stepsDone  = 0,
    this.stepsTotal = 0,
    this.modelPath  = '',
    this.updatedAt  = '',
    this.error      = '',
  });

  factory LoraStatus.fromJson(Map<String, dynamic> j) {
    final stateStr = j['state'] as String? ?? 'idle';
    final state = switch (stateStr) {
      'exporting'   => LoraState.exporting,
      'training'    => LoraState.training,
      'merging'     => LoraState.merging,
      'done'        => LoraState.done,
      'error'       => LoraState.error,
      'unavailable' => LoraState.unavailable,
      _             => LoraState.idle,
    };
    return LoraStatus(
      state      : state,
      progress   : j['progress']    as int?    ?? 0,
      message    : j['message']     as String? ?? '',
      samples    : j['samples']     as int?    ?? 0,
      stepsDone  : j['steps_done']  as int?    ?? 0,
      stepsTotal : j['steps_total'] as int?    ?? 0,
      modelPath  : j['model_path']  as String? ?? '',
      updatedAt  : j['updated_at']  as String? ?? '',
      error      : j['error']       as String? ?? '',
    );
  }

  String get stateLabel => switch (state) {
    LoraState.idle        => 'جاهز',
    LoraState.exporting   => '⏳ جاري التصدير...',
    LoraState.training    => '🧠 جاري التدريب...',
    LoraState.merging     => '🔀 جاري الدمج...',
    LoraState.done        => '✅ اكتمل',
    LoraState.error       => '❌ خطأ',
    LoraState.unavailable => '⚠️ غير متاح',
  };

  bool get isActive => state == LoraState.exporting ||
                       state == LoraState.training   ||
                       state == LoraState.merging;
}


class LoraService extends ChangeNotifier {
  static final LoraService instance = LoraService._();
  LoraService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 5);

  LoraStatus _status = const LoraStatus();
  Timer?     _pollTimer;

  LoraStatus get status => _status;

  // ── Poll status every 3s when active ──────────
  void startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _fetchStatus());
    _fetchStatus();
  }

  void stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  Future<void> _fetchStatus() async {
    try {
      final r = await http
          .get(Uri.parse('$_base/lora/status'))
          .timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        _status = LoraStatus.fromJson(j);
        notifyListeners();

        // إيقاف الـ polling لو انتهى
        if (!_status.isActive) stopPolling();
      }
    } catch (_) {
      // server offline — keep polling
    }
  }

  // ── Trigger export ─────────────────────────────
  Future<bool> exportData() async {
    try {
      final r = await http
          .post(
            Uri.parse('$_base/lora/export'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({}),
          )
          .timeout(_timeout);
      if (r.statusCode == 200) {
        startPolling();
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  // ── Trigger training ───────────────────────────
  Future<bool> startTraining() async {
    try {
      final r = await http
          .post(
            Uri.parse('$_base/lora/start'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({}),
          )
          .timeout(_timeout);
      if (r.statusCode == 200) {
        startPolling();
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  // ── Reset ──────────────────────────────────────
  Future<void> reset() async {
    try {
      await http
          .post(Uri.parse('$_base/lora/reset'))
          .timeout(_timeout);
    } catch (_) {}
    await _fetchStatus();
  }
}
