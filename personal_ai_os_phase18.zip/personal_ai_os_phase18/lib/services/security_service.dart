// lib/services/security_service.dart — Phase 17
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

enum LockState { setupNeeded, locked, unlocked }

class SecurityStatus {
  final LockState state;
  final bool      hasPin;
  final bool      lockEnabled;
  final bool      biometricEnabled;
  final int       timeoutMinutes;
  final int       failedAttempts;
  final int       encryptedMsgs;

  const SecurityStatus({
    this.state           = LockState.setupNeeded,
    this.hasPin          = false,
    this.lockEnabled     = false,
    this.biometricEnabled= false,
    this.timeoutMinutes  = 5,
    this.failedAttempts  = 0,
    this.encryptedMsgs   = 0,
  });

  factory SecurityStatus.fromJson(Map<String, dynamic> j) {
    final stateStr = j['state'] as String? ?? 'setup_needed';
    final state = switch (stateStr) {
      'unlocked' => LockState.unlocked,
      'locked'   => LockState.locked,
      _          => LockState.setupNeeded,
    };
    return SecurityStatus(
      state:            state,
      hasPin:           j['has_pin']          as bool? ?? false,
      lockEnabled:      j['lock_enabled']     as bool? ?? false,
      biometricEnabled: j['biometric_enabled']as bool? ?? false,
      timeoutMinutes:   j['timeout_minutes']  as int?  ?? 5,
      failedAttempts:   j['failed_attempts']  as int?  ?? 0,
      encryptedMsgs:    j['encrypted_msgs']   as int?  ?? 0,
    );
  }
}

class SecurityService extends ChangeNotifier {
  static final SecurityService instance = SecurityService._();
  SecurityService._();

  static const _base    = 'http://localhost:7070';
  static const _timeout = Duration(seconds: 10);
  static const _bioChannel = MethodChannel('personal_ai_os/biometric');

  SecurityStatus _status = const SecurityStatus();
  bool           _loading= false;
  String         _error  = '';

  SecurityStatus get status  => _status;
  bool           get loading => _loading;
  bool           get isLocked =>
    _status.state == LockState.locked ||
    _status.state == LockState.setupNeeded;

  Future<void> loadStatus() async {
    _loading = true; notifyListeners();
    try {
      final r = await http.get(Uri.parse('$_base/security/status'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        _status = SecurityStatus.fromJson(
          jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>);
      }
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
  }

  Future<Map<String, dynamic>> setupPin(String pin) async {
    try {
      final r = await http.post(Uri.parse('$_base/security/setup_pin'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'pin': pin})).timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) await loadStatus();
        return j;
      }
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
    return {'ok': false};
  }

  Future<Map<String, dynamic>> unlock(String pin) async {
    try {
      final r = await http.post(Uri.parse('$_base/security/unlock'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'pin': pin})).timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
        if (j['ok'] == true) await loadStatus();
        return j;
      }
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
    return {'ok': false};
  }

  Future<void> lock() async {
    try {
      await http.post(Uri.parse('$_base/security/lock'),
        headers: {'Content-Type': 'application/json'},
        body: '{}').timeout(_timeout);
      await loadStatus();
    } catch (_) {}
  }

  Future<Map<String, dynamic>> changePin(String oldPin, String newPin) async {
    try {
      final r = await http.post(Uri.parse('$_base/security/change_pin'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'old_pin': oldPin, 'new_pin': newPin})).timeout(_timeout);
      if (r.statusCode == 200) {
        return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      }
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
    return {'ok': false};
  }

  Future<bool> configure({int? timeoutMinutes, bool? biometricEnabled, bool? lockEnabled}) async {
    final body = <String, dynamic>{};
    if (timeoutMinutes  != null) body['timeout_minutes']   = timeoutMinutes;
    if (biometricEnabled!= null) body['biometric_enabled'] = biometricEnabled;
    if (lockEnabled     != null) body['lock_enabled']      = lockEnabled;
    try {
      final r = await http.post(Uri.parse('$_base/security/configure'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body)).timeout(_timeout);
      if (r.statusCode == 200) { await loadStatus(); return true; }
    } catch (_) {}
    return false;
  }

  // Biometric via MethodChannel → Android BiometricManager
  Future<bool> authenticateBiometric() async {
    try {
      final result = await _bioChannel.invokeMethod<bool>('authenticate');
      if (result == true) { await loadStatus(); return true; }
    } catch (_) {}
    return false;
  }

  void keepAlive() {
    http.post(Uri.parse('$_base/analytics/keepalive'),
      headers: {'Content-Type': 'application/json'},
      body: '{}').catchError((_) => http.Response('', 200));
  }
}
