// lib/services/offline_service.dart — Phase 11
// ══════════════════════════════════════════════════
// يراقب الـ connectivity ويدير الـ queue
// يتواصل مع Python server + Android native
// ══════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ── Models ────────────────────────────────────────
class QueueStats {
  final int pending;
  final int retrying;
  final int done;
  final int failed;
  final int total;

  const QueueStats({
    this.pending  = 0,
    this.retrying = 0,
    this.done     = 0,
    this.failed   = 0,
    this.total    = 0,
  });

  factory QueueStats.fromJson(Map<String, dynamic> j) => QueueStats(
    pending:  j['pending']  as int? ?? 0,
    retrying: j['retrying'] as int? ?? 0,
    done:     j['done']     as int? ?? 0,
    failed:   j['failed']   as int? ?? 0,
    total:    j['total']    as int? ?? 0,
  );

  bool get hasPending => pending + retrying > 0;
}

class SyncStatus {
  final bool       online;
  final int        pendingCount;
  final int        syncedTotal;
  final String     lastSync;
  final QueueStats queueStats;

  const SyncStatus({
    this.online       = false,
    this.pendingCount = 0,
    this.syncedTotal  = 0,
    this.lastSync     = '',
    this.queueStats   = const QueueStats(),
  });

  factory SyncStatus.fromJson(Map<String, dynamic> j) => SyncStatus(
    online:       j['online']        as bool?   ?? false,
    pendingCount: j['pending_count'] as int?    ?? 0,
    syncedTotal:  j['synced_total']  as int?    ?? 0,
    lastSync:     j['last_sync']     as String? ?? '',
    queueStats:   j['queue_stats'] != null
        ? QueueStats.fromJson(j['queue_stats'] as Map<String, dynamic>)
        : const QueueStats(),
  );

  String get statusLabel {
    if (!online) return '📴 Offline';
    if (pendingCount > 0) return '🔄 Syncing ($pendingCount)';
    return '🌐 Online';
  }

  String get statusEmoji {
    if (!online) return '📴';
    if (pendingCount > 0) return '🔄';
    return '🟢';
  }
}


// ── Service ───────────────────────────────────────
class OfflineService extends ChangeNotifier {
  static final OfflineService instance = OfflineService._();
  OfflineService._();

  static const _base         = 'http://localhost:7070';
  static const _timeout      = Duration(seconds: 4);
  static const _netChannel   = MethodChannel('personal_ai_os/network');

  SyncStatus _status    = const SyncStatus();
  bool       _checking  = false;
  Timer?     _pollTimer;

  SyncStatus get status      => _status;
  bool       get isOnline    => _status.online;
  bool       get hasPending  => _status.pendingCount > 0;

  // ── Init ──────────────────────────────────────────
  Future<void> init() async {
    await refresh();
    _startPolling();
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 15), (_) => refresh());
  }

  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  // ── Refresh status ────────────────────────────────
  Future<void> refresh() async {
    if (_checking) return;
    _checking = true;

    // 1. Check Android native connectivity
    bool nativeOnline = false;
    try {
      nativeOnline = await _netChannel.invokeMethod<bool>('isOnline') ?? false;
    } catch (_) {
      // channel not available — check via HTTP
    }

    // 2. Fetch sync status from Python server
    try {
      final r = await http
          .get(Uri.parse('$_base/sync/status'))
          .timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        _status = SyncStatus.fromJson({
          ...j,
          'online': nativeOnline || (j['online'] as bool? ?? false),
        });
        notifyListeners();
        _checking = false;
        return;
      }
    } catch (_) {}

    // 3. Fallback — server offline, use native check
    _status = SyncStatus(online: nativeOnline);
    _checking = false;
    notifyListeners();
  }

  // ── Enqueue offline request ───────────────────────
  Future<String?> enqueue(String endpoint, Map<String, dynamic> payload,
      {int priority = 2}) async {
    try {
      final r = await http
          .post(
            Uri.parse('$_base/queue/enqueue'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'endpoint': endpoint,
              'payload':  payload,
              'priority': priority,
            }),
          )
          .timeout(_timeout);
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        refresh();
        return j['id'] as String?;
      }
    } catch (_) {}
    return null;
  }

  // ── Retry failed ─────────────────────────────────
  Future<void> retryFailed() async {
    try {
      await http
          .post(Uri.parse('$_base/sync/retry'))
          .timeout(_timeout);
      await refresh();
    } catch (_) {}
  }

  // ── Ping test ─────────────────────────────────────
  Future<bool> pingTest() async {
    try {
      return await _netChannel.invokeMethod<bool>('pingTest') ?? false;
    } catch (_) {
      // Fallback: try to reach health endpoint
      try {
        final r = await http
            .get(Uri.parse('$_base/health'))
            .timeout(const Duration(seconds: 3));
        return r.statusCode == 200;
      } catch (_) {
        return false;
      }
    }
  }
}
