// lib/l10n/app_localizations.dart — Phase 15
// ══════════════════════════════════════════════════
// i18n بدون flutter_localizations dependency ثقيل
// يدعم: العربية + الإنجليزية
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';

// ── String keys ───────────────────────────────────
class S {
  final Locale locale;
  S(this.locale);

  static S of(BuildContext context) =>
      Localizations.of<S>(context, S) ?? S(const Locale('ar'));

  static const LocalizationsDelegate<S> delegate = _AppLocalizationsDelegate();

  bool get isArabic => locale.languageCode == 'ar';
  bool get isRtl    => locale.languageCode == 'ar' || locale.languageCode == 'he';

  // ── Navigation ────────────────────────────────
  String get chat        => isArabic ? 'المحادثة'  : 'Chat';
  String get dashboard   => isArabic ? 'لوحة التحكم' : 'Dashboard';
  String get images      => isArabic ? 'الصور'     : 'Images';
  String get meetings    => isArabic ? 'الاجتماعات' : 'Meetings';
  String get settings    => isArabic ? 'الإعدادات' : 'Settings';
  String get backup      => isArabic ? 'النسخ الاحتياطي' : 'Backup';

  // ── Common ────────────────────────────────────
  String get save        => isArabic ? 'حفظ'       : 'Save';
  String get cancel      => isArabic ? 'إلغاء'     : 'Cancel';
  String get confirm     => isArabic ? 'تأكيد'     : 'Confirm';
  String get delete      => isArabic ? 'حذف'       : 'Delete';
  String get edit        => isArabic ? 'تعديل'     : 'Edit';
  String get close       => isArabic ? 'إغلاق'     : 'Close';
  String get loading     => isArabic ? 'جاري التحميل...' : 'Loading...';
  String get retry       => isArabic ? 'إعادة المحاولة' : 'Retry';
  String get yes         => isArabic ? 'نعم'       : 'Yes';
  String get no          => isArabic ? 'لا'        : 'No';
  String get ok          => isArabic ? 'حسناً'     : 'OK';
  String get error       => isArabic ? 'خطأ'       : 'Error';
  String get success     => isArabic ? 'تم بنجاح'  : 'Success';
  String get refresh     => isArabic ? 'تحديث'     : 'Refresh';
  String get search      => isArabic ? 'بحث'       : 'Search';
  String get send        => isArabic ? 'إرسال'     : 'Send';
  String get copy        => isArabic ? 'نسخ'       : 'Copy';
  String get share       => isArabic ? 'مشاركة'    : 'Share';

  // ── Chat ──────────────────────────────────────
  String get typeMessage => isArabic ? 'اكتب رسالتك...' : 'Type a message...';
  String get thinking    => isArabic ? 'يفكر...'    : 'Thinking...';
  String get newChat     => isArabic ? 'محادثة جديدة' : 'New Chat';
  String get clearChat   => isArabic ? 'مسح المحادثة' : 'Clear Chat';
  String get voiceInput  => isArabic ? 'الإدخال الصوتي' : 'Voice Input';

  // ── Meetings ──────────────────────────────────
  String get newMeeting      => isArabic ? 'اجتماع جديد'   : 'New Meeting';
  String get startRecording  => isArabic ? 'ابدأ التسجيل'  : 'Start Recording';
  String get stopRecording   => isArabic ? 'أوقف التسجيل'  : 'Stop Recording';
  String get summarize       => isArabic ? 'تلخيص'         : 'Summarize';
  String get actionItems     => isArabic ? 'المهام'         : 'Action Items';
  String get keywords        => isArabic ? 'الكلمات المفتاحية' : 'Keywords';
  String get attendees       => isArabic ? 'المشاركون'     : 'Attendees';
  String get duration        => isArabic ? 'المدة'          : 'Duration';
  String get transcript      => isArabic ? 'النص'           : 'Transcript';

  // ── Images ────────────────────────────────────
  String get generate    => isArabic ? 'توليد'       : 'Generate';
  String get gallery     => isArabic ? 'المعرض'      : 'Gallery';
  String get prompt      => isArabic ? 'الوصف'       : 'Prompt';
  String get style       => isArabic ? 'النمط'       : 'Style';

  // ── Settings ──────────────────────────────────
  String get appearance     => isArabic ? 'المظهر'         : 'Appearance';
  String get language       => isArabic ? 'اللغة'          : 'Language';
  String get theme          => isArabic ? 'الثيم'          : 'Theme';
  String get darkMode       => isArabic ? 'الوضع الداكن'   : 'Dark Mode';
  String get lightMode      => isArabic ? 'الوضع الفاتح'   : 'Light Mode';
  String get systemMode     => isArabic ? 'تلقائي'         : 'System';
  String get accentColor    => isArabic ? 'لون التمييز'    : 'Accent Color';
  String get fontSize       => isArabic ? 'حجم الخط'       : 'Font Size';
  String get accessibility  => isArabic ? 'إمكانية الوصول' : 'Accessibility';
  String get highContrast   => isArabic ? 'تباين عالٍ'     : 'High Contrast';
  String get reduceMotion   => isArabic ? 'تقليل الحركة'   : 'Reduce Motion';
  String get arabic         => isArabic ? 'العربية'        : 'Arabic';
  String get english        => isArabic ? 'الإنجليزية'     : 'English';

  // ── Backup ────────────────────────────────────
  String get createBackup   => isArabic ? 'إنشاء نسخة'     : 'Create Backup';
  String get restoreBackup  => isArabic ? 'استعادة نسخة'   : 'Restore Backup';
  String get exportData     => isArabic ? 'تصدير البيانات' : 'Export Data';
  String get encrypted      => isArabic ? 'مشفّر'           : 'Encrypted';
  String get password       => isArabic ? 'كلمة المرور'    : 'Password';

  // ── Proactive ─────────────────────────────────
  String get suggestion     => isArabic ? 'اقتراح'         : 'Suggestion';
  String get reminder       => isArabic ? 'تذكير'          : 'Reminder';

  // ── Offline ───────────────────────────────────
  String get offline        => isArabic ? 'غير متصل'       : 'Offline';
  String get online         => isArabic ? 'متصل'           : 'Online';
  String get syncing        => isArabic ? 'جاري المزامنة'  : 'Syncing';

  // ── Onboarding ────────────────────────────────
  String get getStarted     => isArabic ? 'ابدأ الآن'      : 'Get Started';
  String get welcome        => isArabic ? 'مرحباً'          : 'Welcome';
  String get yourAiAssistant => isArabic
      ? 'مساعدك الذكي الشخصي'
      : 'Your Personal AI Assistant';
}

// ── Delegate ──────────────────────────────────────
class _AppLocalizationsDelegate extends LocalizationsDelegate<S> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      ['ar', 'en'].contains(locale.languageCode);

  @override
  Future<S> load(Locale locale) async => S(locale);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

// ── Supported locales ─────────────────────────────
const kSupportedLocales = [
  Locale('ar', 'SA'),
  Locale('en', 'US'),
];
