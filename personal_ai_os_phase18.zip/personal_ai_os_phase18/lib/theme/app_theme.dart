// lib/theme/app_theme.dart — Phase 15
// ══════════════════════════════════════════════════
// نظام الـ Themes الكامل
//
// 5 ثيمات:
//   cyberpunk  (default) — أزرق + أخضر neon على خلفية داكنة
//   ocean      — ألوان البحر + تدرجات الأزرق
//   sunset     — برتقالي + وردي دافئ
//   forest     — أخضر طبيعي + بيج
//   minimal    — أبيض وأسود فقط
//
// يدعم: Dark + Light + System
// يدعم: High Contrast
// يدعم: Font Scale
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';

// ══════════════════════════════════════════════════
// THEME DEFINITIONS
// ══════════════════════════════════════════════════
enum AppThemeId { cyberpunk, ocean, sunset, forest, minimal }

class AppThemeData {
  final AppThemeId id;
  final String     name;
  final String     nameAr;
  final String     emoji;
  final Color      accent;
  final Color      accentSecondary;
  final Color      darkBg;
  final Color      darkSurface;
  final Color      darkCard;
  final Color      lightBg;
  final Color      lightSurface;
  final Color      lightCard;

  const AppThemeData({
    required this.id,
    required this.name,
    required this.nameAr,
    required this.emoji,
    required this.accent,
    required this.accentSecondary,
    required this.darkBg,
    required this.darkSurface,
    required this.darkCard,
    required this.lightBg,
    required this.lightSurface,
    required this.lightCard,
  });
}

const Map<AppThemeId, AppThemeData> kThemes = {
  AppThemeId.cyberpunk: AppThemeData(
    id:              AppThemeId.cyberpunk,
    name:            'Cyberpunk',
    nameAr:          'سايبر بانك',
    emoji:           '⚡',
    accent:          Color(0xFF00C8FF),
    accentSecondary: Color(0xFF00FF9D),
    darkBg:          Color(0xFF080E1A),
    darkSurface:     Color(0xFF0D1520),
    darkCard:        Color(0xFF0A1228),
    lightBg:         Color(0xFFF0F4FF),
    lightSurface:    Color(0xFFFFFFFF),
    lightCard:       Color(0xFFE8EEFF),
  ),
  AppThemeId.ocean: AppThemeData(
    id:              AppThemeId.ocean,
    name:            'Ocean',
    nameAr:          'المحيط',
    emoji:           '🌊',
    accent:          Color(0xFF0EA5E9),
    accentSecondary: Color(0xFF38BDF8),
    darkBg:          Color(0xFF03101A),
    darkSurface:     Color(0xFF071C2E),
    darkCard:        Color(0xFF0A2340),
    lightBg:         Color(0xFFEFF8FF),
    lightSurface:    Color(0xFFFFFFFF),
    lightCard:       Color(0xFFDCF0FF),
  ),
  AppThemeId.sunset: AppThemeData(
    id:              AppThemeId.sunset,
    name:            'Sunset',
    nameAr:          'الغروب',
    emoji:           '🌅',
    accent:          Color(0xFFFF6B35),
    accentSecondary: Color(0xFFFF9F1C),
    darkBg:          Color(0xFF160A08),
    darkSurface:     Color(0xFF201010),
    darkCard:        Color(0xFF2A1510),
    lightBg:         Color(0xFFFFF5EF),
    lightSurface:    Color(0xFFFFFFFF),
    lightCard:       Color(0xFFFFE8DA),
  ),
  AppThemeId.forest: AppThemeData(
    id:              AppThemeId.forest,
    name:            'Forest',
    nameAr:          'الغابة',
    emoji:           '🌿',
    accent:          Color(0xFF22C55E),
    accentSecondary: Color(0xFF86EFAC),
    darkBg:          Color(0xFF050E0A),
    darkSurface:     Color(0xFF0A1A10),
    darkCard:        Color(0xFF0F2018),
    lightBg:         Color(0xFFF0FDF4),
    lightSurface:    Color(0xFFFFFFFF),
    lightCard:       Color(0xFFDCFCE7),
  ),
  AppThemeId.minimal: AppThemeData(
    id:              AppThemeId.minimal,
    name:            'Minimal',
    nameAr:          'بسيط',
    emoji:           '◼',
    accent:          Color(0xFFE2E8F0),
    accentSecondary: Color(0xFF94A3B8),
    darkBg:          Color(0xFF0A0A0A),
    darkSurface:     Color(0xFF141414),
    darkCard:        Color(0xFF1E1E1E),
    lightBg:         Color(0xFFF8FAFC),
    lightSurface:    Color(0xFFFFFFFF),
    lightCard:       Color(0xFFF1F5F9),
  ),
};


// ══════════════════════════════════════════════════
// AppColors — resolved at runtime based on current theme
// ══════════════════════════════════════════════════
class AppColors {
  AppColors._();

  static AppThemeData _current = kThemes[AppThemeId.cyberpunk]!;
  static bool         _isDark  = true;

  static void update(AppThemeData theme, bool isDark) {
    _current = theme;
    _isDark  = isDark;
  }

  // ── Dynamic colors ─────────────────────────────
  static Color get accent          => _current.accent;
  static Color get accentSecondary => _current.accentSecondary;
  static Color get bg              => _isDark ? _current.darkBg      : _current.lightBg;
  static Color get surface         => _isDark ? _current.darkSurface : _current.lightSurface;
  static Color get card            => _isDark ? _current.darkCard    : _current.lightCard;

  // ── Semantic ───────────────────────────────────
  static Color get text            => _isDark ? Colors.white         : const Color(0xFF1A1A2E);
  static Color get textMuted       => _isDark ? Colors.white60       : const Color(0xFF64748B);
  static Color get textFaint       => _isDark ? Colors.white24       : const Color(0xFFCBD5E1);
  static Color get border          => _isDark ? Colors.white.withOpacity(0.08)
                                              : const Color(0xFFE2E8F0);
  static Color get iconMuted       => _isDark ? Colors.white38       : const Color(0xFF94A3B8);
  static Color get error           => const Color(0xFFEF4444);
  static Color get success         => const Color(0xFF22C55E);
  static Color get warning         => const Color(0xFFF59E0B);

  // ── Static fallbacks (for files that import before service init) ──
  static const Color darkBg      = Color(0xFF080E1A);
  static const Color darkSurface = Color(0xFF0D1520);
  static const Color lightBg     = Color(0xFFF0F4FF);
  static const Color lightSurface= Color(0xFFFFFFFF);
}


// ══════════════════════════════════════════════════
// ThemeData builder
// ══════════════════════════════════════════════════
class AppThemeBuilder {

  static ThemeData build({
    required AppThemeData theme,
    required bool         isDark,
    required double       fontScale,
    required bool         highContrast,
  }) {
    final bg      = isDark ? theme.darkBg      : theme.lightBg;
    final surface = isDark ? theme.darkSurface : theme.lightSurface;
    final card    = isDark ? theme.darkCard    : theme.lightCard;
    final onBg    = isDark ? Colors.white      : const Color(0xFF1A1A2E);

    // High contrast overrides
    final accent  = highContrast
        ? (isDark ? Colors.white : Colors.black)
        : theme.accent;

    final base = isDark ? ThemeData.dark() : ThemeData.light();

    return base.copyWith(
      useMaterial3:    true,
      brightness:      isDark ? Brightness.dark : Brightness.light,

      scaffoldBackgroundColor: bg,
      canvasColor:             bg,
      cardColor:               card,

      colorScheme: ColorScheme(
        brightness:       isDark ? Brightness.dark : Brightness.light,
        primary:          accent,
        onPrimary:        isDark ? Colors.black : Colors.white,
        secondary:        theme.accentSecondary,
        onSecondary:      isDark ? Colors.black : Colors.white,
        surface:          surface,
        onSurface:        onBg,
        error:            const Color(0xFFEF4444),
        onError:          Colors.white,
        background:       bg,
        onBackground:     onBg,
      ),

      textTheme: _buildTextTheme(onBg, fontScale),
      iconTheme: IconThemeData(color: onBg.withOpacity(0.7), size: 22 * fontScale),

      appBarTheme: AppBarTheme(
        backgroundColor:  bg,
        foregroundColor:  onBg,
        elevation:        0,
        centerTitle:      false,
        titleTextStyle: TextStyle(
          color: onBg, fontSize: 18 * fontScale,
          fontWeight: FontWeight.w800, fontFamily: 'Tajawal',
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accent,
          foregroundColor: isDark ? Colors.black : Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: TextStyle(
            fontFamily: 'Tajawal', fontWeight: FontWeight.w700,
            fontSize: 14 * fontScale,
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: onBg.withOpacity(0.1)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: onBg.withOpacity(0.1)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accent),
        ),
        hintStyle: TextStyle(color: onBg.withOpacity(0.3), fontFamily: 'Tajawal'),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),

      switchTheme: SwitchThemeData(
        thumbColor: MaterialStateProperty.resolveWith(
          (s) => s.contains(MaterialState.selected) ? accent : null),
        trackColor: MaterialStateProperty.resolveWith(
          (s) => s.contains(MaterialState.selected)
              ? accent.withOpacity(0.3) : null),
      ),

      dividerTheme: DividerThemeData(
        color: onBg.withOpacity(0.08), thickness: 1),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: surface,
        contentTextStyle: TextStyle(
          color: onBg, fontFamily: 'Tajawal', fontSize: 13 * fontScale),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  static TextTheme _buildTextTheme(Color base, double scale) {
    T s<T extends TextStyle>(double size, FontWeight w) =>
      TextStyle(
        color: base,
        fontFamily: 'Tajawal',
        fontSize: size * scale,
        fontWeight: w,
      ) as T;

    return TextTheme(
      displayLarge:  s(32, FontWeight.w900),
      displayMedium: s(28, FontWeight.w800),
      displaySmall:  s(24, FontWeight.w700),
      headlineLarge: s(22, FontWeight.w700),
      headlineMedium:s(18, FontWeight.w700),
      headlineSmall: s(16, FontWeight.w600),
      titleLarge:    s(16, FontWeight.w700),
      titleMedium:   s(14, FontWeight.w600),
      titleSmall:    s(12, FontWeight.w600),
      bodyLarge:     s(16, FontWeight.w400),
      bodyMedium:    s(14, FontWeight.w400),
      bodySmall:     s(12, FontWeight.w400),
      labelLarge:    s(14, FontWeight.w600),
      labelMedium:   s(12, FontWeight.w500),
      labelSmall:    s(10, FontWeight.w500),
    );
  }
}
