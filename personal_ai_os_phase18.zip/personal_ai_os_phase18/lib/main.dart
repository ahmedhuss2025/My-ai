// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/app_state.dart';
import 'services/voice_service.dart';
import 'services/screen_service.dart';
import 'services/lora_service.dart';
import 'services/ambient_service.dart';
import 'services/offline_service.dart';
import 'services/image_service.dart';
import 'services/meeting_service.dart';
import 'services/widget_service.dart';    // Phase 13
import 'services/proactive_service.dart'; // Phase 13
import 'services/backup_service.dart';    // Phase 14
import 'services/theme_service.dart';     // Phase 15
import 'services/notification_service.dart'; // Phase 16
import 'services/security_service.dart';     // Phase 17
import 'services/analytics_service.dart';    // Phase 17
import 'l10n/app_localizations.dart';     // Phase 15
import 'screens/onboarding_screen.dart';
import 'screens/main_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.transparent,
  ));

  final prefs = await SharedPreferences.getInstance();
  final done  = prefs.getBool('onboarding_done') ?? false;

  final appState      = AppState();
  final voiceService  = VoiceService.instance;
  final screenService = ScreenService.instance;
  await appState.init();
  // Phase 9 — init ambient in background
  AmbientService.instance.init();
  // Phase 11 — init offline monitor
  OfflineService.instance.init();
  // Phase 12 — init creative services
  ImageService.instance.loadGallery();
  MeetingService.instance.initStt();
  // Phase 13 — init widget + proactive
  WidgetService.instance.init();
  ProactiveService.instance.init();
  // Phase 15 — init theme + i18n
  await ThemeService.instance.init();
  // Phase 16 — init notifications
  NotificationService.instance.init();
  // Phase 17 — init security + analytics
  SecurityService.instance.loadStatus();
  AnalyticsService.instance.loadReport();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: appState),
        ChangeNotifierProvider<VoiceService>.value(value: voiceService),
        ChangeNotifierProvider<ScreenService>.value(value: screenService),
        ChangeNotifierProvider<LoraService>.value(value: LoraService.instance),
        ChangeNotifierProvider<AmbientService>.value(value: AmbientService.instance),
        ChangeNotifierProvider<OfflineService>.value(value: OfflineService.instance),
        ChangeNotifierProvider<ImageService>.value(value: ImageService.instance),
        ChangeNotifierProvider<MeetingService>.value(value: MeetingService.instance),
        ChangeNotifierProvider<ProactiveService>.value(value: ProactiveService.instance),
        ChangeNotifierProvider<WidgetService>.value(value: WidgetService.instance),
        ChangeNotifierProvider<BackupService>.value(value: BackupService.instance),
        ChangeNotifierProvider<ThemeService>.value(value: ThemeService.instance), // Phase 15
        ChangeNotifierProvider<NotificationService>.value(value: NotificationService.instance), // Phase 16
        ChangeNotifierProvider<SecurityService>.value(value: SecurityService.instance),   // Phase 17
        ChangeNotifierProvider<AnalyticsService>.value(value: AnalyticsService.instance), // Phase 17
      ],
      child: PersonalAIApp(showOnboarding: !done),
    ),
  );
}

class PersonalAIApp extends StatelessWidget {
  final bool showOnboarding;
  const PersonalAIApp({super.key, required this.showOnboarding});

  @override
  Widget build(BuildContext context) {
    final ts = context.watch<ThemeService>();

    return MaterialApp(
      title: 'Personal AI OS',
      debugShowCheckedModeBanner: false,

      // ── Phase 15: Theme ──────────────────────
      themeMode:  ts.themeMode,
      theme:      ts.lightTheme,
      darkTheme:  ts.darkTheme,

      // ── Phase 15: i18n ───────────────────────
      locale:             ts.locale,
      supportedLocales:   kSupportedLocales,
      localizationsDelegates: const [
        S.delegate,
        DefaultMaterialLocalizations.delegate,
        DefaultWidgetsLocalizations.delegate,
      ],

      // RTL support
      builder: (ctx, child) {
        final isRtl = ts.locale.languageCode == 'ar';
        return Directionality(
          textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
          child: child!,
        );
      },

      home: showOnboarding ? const OnboardingScreen() : const MainShell(),
    );
  }
}
