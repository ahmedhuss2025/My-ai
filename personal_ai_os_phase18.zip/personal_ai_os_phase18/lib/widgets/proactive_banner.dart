// lib/widgets/proactive_banner.dart — Phase 13
// ══════════════════════════════════════════════════
// Animated suggestion banner يظهر من أعلى الشاشة
// يندمج مع main_shell فوق الـ PageView
// ══════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/proactive_service.dart';
import '../models/app_state.dart';

class ProactiveBanner extends StatefulWidget {
  const ProactiveBanner({super.key});
  @override
  State<ProactiveBanner> createState() => _ProactiveBannerState();
}

class _ProactiveBannerState extends State<ProactiveBanner>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset>   _slide;
  late Animation<double>   _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _slide = Tween<Offset>(
      begin: const Offset(0, -1),
      end:   Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final proactive = context.watch<ProactiveService>();
    final accent    = context.watch<AppState>().accentColor;
    final s         = proactive.active;

    if (s == null) {
      if (_ctrl.isCompleted) _ctrl.reverse();
      return const SizedBox.shrink();
    }

    _ctrl.forward();

    return SlideTransition(
      position: _slide,
      child: FadeTransition(
        opacity: _fade,
        child: _BannerCard(suggestion: s, accent: accent,
          onDismiss: proactive.dismissActive),
      ),
    );
  }
}


class _BannerCard extends StatelessWidget {
  final Suggestion   suggestion;
  final Color        accent;
  final VoidCallback onDismiss;
  const _BannerCard({required this.suggestion, required this.accent,
    required this.onDismiss});

  @override
  Widget build(BuildContext context) {
    // Priority colors
    final color = suggestion.priority == 1
        ? const Color(0xFFFF6B35)   // high — orange
        : suggestion.priority == 3
            ? const Color(0xFF4A9EFF)   // low — blue
            : accent;                   // normal — accent

    return GestureDetector(
      onTap: _handleAction(context),
      onVerticalDragEnd: (d) {
        if (d.primaryVelocity != null && d.primaryVelocity! < 0) onDismiss();
      },
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 0),
        padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
        decoration: BoxDecoration(
          color: const Color(0xFF0D1520),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.4), width: 1.2),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.15),
              blurRadius: 12, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(children: [
          // Emoji
          Text(suggestion.emoji,
            style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 10),

          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  suggestion.title,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Tajawal',
                  ),
                ),
                if (suggestion.body.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    suggestion.body,
                    textDirection: TextDirection.rtl,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 11,
                      fontFamily: 'Tajawal',
                      height: 1.3,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),

          // Dismiss button
          GestureDetector(
            onTap: onDismiss,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.close_rounded,
                color: Colors.white38, size: 14),
            ),
          ),
        ]),
      ),
    );
  }

  VoidCallback _handleAction(BuildContext context) => () {
    onDismiss();
    // Route based on action string
    final action = suggestion.action;
    if (action.contains('chat') || action.contains('open_chat')) {
      // Switch to chat tab — index 0
      DefaultTabController.of(context)?.animateTo(0);
    } else if (action.contains('meeting')) {
      DefaultTabController.of(context)?.animateTo(3);
    } else if (action.contains('summary')) {
      DefaultTabController.of(context)?.animateTo(3);
    }
  };
}
