// lib/widgets/neural_bar.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';

class NeuralBar extends StatelessWidget {
  const NeuralBar({super.key});

  @override
  Widget build(BuildContext context) {
    final state  = context.watch<AppState>();
    final accent = state.accentColor;
    final pred   = state.lastPrediction;

    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
        ),
      ),
      child: Row(
        children: [
          // Sentiment chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: pred.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: pred.color.withOpacity(0.25)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 5, height: 5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, color: pred.color),
                ),
                const SizedBox(width: 5),
                Text(pred.sentimentLabel,
                  style: TextStyle(
                    fontSize: 11, color: pred.color,
                    fontWeight: FontWeight.w700, fontFamily: 'Tajawal',
                  )),
              ],
            ),
          ),
          const SizedBox(width: 8),

          // Behavior labels
          Expanded(
            child: pred.behaviorLabels.isEmpty
              ? Text('المساعد جاهز',
                  style: TextStyle(fontSize: 11, color: accent.withOpacity(0.5),
                    fontFamily: 'Tajawal'))
              : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: pred.behaviorLabels.map((lbl) => Container(
                      margin: const EdgeInsets.only(left: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: accent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(lbl, style: TextStyle(
                        fontSize: 10, color: accent.withOpacity(0.7),
                        fontFamily: 'Tajawal',
                      )),
                    )).toList(),
                  ),
                ),
          ),

          // Neural icon
          Icon(Icons.psychology_rounded, size: 15, color: accent.withOpacity(0.4)),
        ],
      ),
    );
  }
}
