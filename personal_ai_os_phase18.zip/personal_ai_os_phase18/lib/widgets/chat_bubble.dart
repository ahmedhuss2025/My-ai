// lib/widgets/chat_bubble.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/app_state.dart';

class ChatBubble extends StatelessWidget {
  final Message message;
  final Color accent;
  const ChatBubble({super.key, required this.message, required this.accent});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isUser = message.isUser;

    return GestureDetector(
      onLongPress: () {
        Clipboard.setData(ClipboardData(text: message.content));
        HapticFeedback.mediumImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('نُسخت الرسالة',
              style: TextStyle(fontFamily: 'Tajawal')),
            duration: const Duration(seconds: 1),
            behavior: SnackBarBehavior.floating,
            backgroundColor: accent.withOpacity(0.9),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Agent avatar
            if (!isUser) ...[
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [accent, const Color(0xFF00E5CC)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                ),
                child: const Icon(Icons.auto_awesome_rounded,
                  color: Colors.white, size: 13),
              ),
              const SizedBox(width: 6),
            ],

            // Bubble
            Flexible(
              child: Column(
                crossAxisAlignment: isUser
                    ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.72),
                    decoration: BoxDecoration(
                      gradient: isUser
                          ? LinearGradient(
                              colors: [accent, const Color(0xFF00E5CC)],
                              begin: Alignment.topLeft, end: Alignment.bottomRight,
                            )
                          : null,
                      color: isUser ? null : (isDark
                          ? const Color(0xFF0A1228)
                          : Colors.white),
                      borderRadius: BorderRadius.only(
                        topLeft:     const Radius.circular(16),
                        topRight:    const Radius.circular(16),
                        bottomLeft:  Radius.circular(isUser ? 16 : 4),
                        bottomRight: Radius.circular(isUser ? 4 : 16),
                      ),
                      border: isUser ? null : Border.all(
                        color: Colors.white.withOpacity(0.07)),
                      boxShadow: [
                        BoxShadow(
                          color: isUser
                              ? accent.withOpacity(0.2)
                              : Colors.black.withOpacity(0.15),
                          blurRadius: 8, offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      message.content,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.5,
                        color: isUser ? Colors.white
                            : (isDark ? Colors.white87 : Colors.black87),
                        fontFamily: 'Tajawal',
                      ),
                    ),
                  ),

                  // Timestamp
                  Padding(
                    padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Agent mode badge — Phase 10
                        if (!isUser && message.agentMode != 'single' && message.agentMode.isNotEmpty) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: accent.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: accent.withOpacity(0.3)),
                            ),
                            child: Text(
                              message.agentMode == 'parallel'
                                  ? '⚡ ${message.agentsUsed.length} agents'
                                  : message.agentsUsed.isNotEmpty
                                      ? message.agentsUsed.first
                                      : 'AI',
                              style: TextStyle(fontSize: 8, color: accent,
                                fontWeight: FontWeight.w700, fontFamily: 'monospace'),
                            ),
                          ),
                          const SizedBox(width: 4),
                        ],
                        // Sentiment if AI message
                        if (!isUser && message.prediction != null) ...[
                          Text(
                            message.prediction!.sentimentLabel,
                            style: TextStyle(
                              fontSize: 9,
                              color: message.prediction!.color.withOpacity(0.7),
                              fontFamily: 'Tajawal',
                            ),
                          ),
                          const SizedBox(width: 4),
                          Container(width: 3, height: 3,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.2))),
                          const SizedBox(width: 4),
                        ],
                        Text(
                          _formatTime(message.timestamp),
                          style: TextStyle(
                            fontSize: 9,
                            color: Colors.white.withOpacity(0.25),
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            if (isUser) const SizedBox(width: 34), // balance with avatar width
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    return '${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
  }
}
